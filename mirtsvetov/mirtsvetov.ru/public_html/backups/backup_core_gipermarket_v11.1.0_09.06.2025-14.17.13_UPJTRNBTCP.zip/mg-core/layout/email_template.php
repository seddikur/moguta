<?php
/**
 * Доступна переменная $content, в которой доступно содержание всего письма.
 */
?>
<div style="width:700px;background:#fff;font-family:Verdana, Arial, Helvetica, sans-serif;font-size:12px;margin:0;padding:15px;border: 2px solid #EDEDED;">
	<?php echo $content; ?>
</div>
