<?php 
define('REAL_DOCUMENT_ROOT', __DIR__);
Error_Reporting(E_ERROR | E_PARSE);


include REAL_DOCUMENT_ROOT."/mg-core/index-start.php";