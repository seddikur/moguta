
DROP TABLE IF EXISTS `mg_setting`;

CREATE TABLE `mg_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `option` varchar(191) NOT NULL,
  `value` longtext,
  `active` varchar(1) NOT NULL DEFAULT 'N',
  `name` varchar(249) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `option` (`option`),
  KEY `option_2` (`option`)
) ENGINE=InnoDB AUTO_INCREMENT=314 DEFAULT CHARSET=utf8mb4;


INSERT INTO `mg_setting` VALUES
("1","sitename","localhost","Y","SITE_NAME"),
("2","adminEmail","tech@belka.one","Y","EMAIL_ADMIN"),
("3","templateName","moguta","Y","SITE_TEMPLATE"),
("4","countСatalogProduct","6","Y","CATALOG_COUNT_PAGE"),
("5","currency","руб.","Y","SETTING_CURRENCY"),
("6","staticMenu","true","N","SETTING_STATICMENU"),
("7","orderMessage","Оформлен заказ № #ORDER# на сайте #SITE#","Y","TPL_EMAIL_ORDER"),
("8","downtime","true","N","DOWNTIME_SITE"),
("9","downtime1C","false","N","CLOSE_SITE_FOR_1C"),
("10","currentVersion","{\"dateActivateKey\":\"2023-10-29 11:33:38\",\"edition\":\"giper\",\"notifications\":[],\"last\":\"v11.0.11\",\"final\":\"v8.11.2\",\"disc\":\"\\u041e\\u0431\\u043d\\u043e\\u0432\\u043b\\u0435\\u043d\\u0438\\u0435 \\u0434\\u0432\\u0438\\u0436\\u043a\\u0430, \\u043f\\u043e\\u0434\\u0440\\u043e\\u0431\\u043d\\u0435\\u0435 \\u0432 \\u0431\\u043b\\u043e\\u0433\\u0435 https:\\/\\/moguta.ru\\/blog\\/istoriya-versiy\\/reliz-moguta-cms-11-0-0 . \\u0412\\u0430\\u0436\\u043d\\u043e! \\u0415\\u0441\\u043b\\u0438, \\u043f\\u043e\\u0441\\u043b\\u0435 \\u043e\\u0431\\u043d\\u043e\\u0432\\u043b\\u0435\\u043d\\u0438\\u044f, \\u0432\\u044b \\u0445\\u043e\\u0442\\u0438\\u0442\\u0435 \\u043f\\u0435\\u0440\\u0435\\u0439\\u0442\\u0438 \\u043d\\u0430 PHP8, \\u043d\\u0435\\u043e\\u0431\\u0445\\u043e\\u0434\\u0438\\u043c\\u043e, \\u0442\\u0430\\u043a\\u0436\\u0435, \\u043e\\u0431\\u043d\\u043e\\u0432\\u0438\\u0442\\u044c \\u0448\\u0430\\u0431\\u043b\\u043e\\u043d \\u0438 \\u043f\\u043b\\u0430\\u0433\\u0438\\u043d\\u044b!\",\"author\":null}","N","INFO_CUR_VERSION"),
("11","timeLastUpdata","cIRCfebuaINCiePudSZOyLLWOnSGLiONSa","N","LASTTIME_UPDATE"),
("12","title"," Лучший магазин | Moguta.CMS","N","SETTING_PAGE_TITLE"),
("13","countPrintRowsProduct","20","Y","ADMIN_COUNT_PROD"),
("14","languageLocale","ru_RU","N","ADMIN_LANG_LOCALE"),
("15","countPrintRowsPage","10","Y","ADMIN_COUNT_PAGE"),
("16","themeColor","green-theme","N","ADMIN_THEM_COLOR"),
("17","themeBackground","bg_7.png","N","ADMIN_THEM_BG"),
("18","countPrintRowsOrder","20","N","ADMIN_COUNT_ORDER"),
("19","countPrintRowsUser","30","N","ADMIN_COUNT_USER"),
("20","licenceKey","9986a88009acd1578cf2cb8243e5dc2d","N","LICENCE_KEY"),
("21","mainPageIsCatalog","true","Y","SETTING_CAT_ON_INDEX"),
("22","countNewProduct","5","Y","COUNT_NEW_PROD"),
("23","countRecomProduct","5","Y","COUNT_RECOM_PROD"),
("24","countSaleProduct","5","Y","COUNT_SALE_PROD"),
("25","actionInCatalog","true","Y","VIEW_OR_BUY"),
("26","printProdNullRem","true","Y","PRINT_PROD_NULL_REM"),
("27","printRemInfo","true","Y","PRINT_REM_INFO"),
("28","printCount","true","Y","PRINT_COUNT"),
("29","printCode","true","Y","PRINT_CODE"),
("30","printUnits","true","Y","PRINT_UNITS"),
("31","printBuy","true","Y","PRINT_BUY"),
("32","printCost","true","Y","PRINT_COST"),
("33","heightPreview","348","Y","PREVIEW_HEIGHT"),
("34","widthPreview","540","Y","PREVIEW_WIDTH"),
("35","heightSmallPreview","200","Y","PREVIEW_HEIGHT_2"),
("36","widthSmallPreview","300","Y","PREVIEW_WIDTH_2"),
("37","categoryIconHeight","100","Y","CAT_ICON_HEIGHT"),
("38","categoryIconWidth","100","Y","CAT_ICON_WIDTH"),
("39","waterMark","false","Y","WATERMARK"),
("40","waterMarkPosition","center","Y","WATERMARKPOSITION"),
("41","widgetCode","<!-- В это поле необходимо прописать код счетчика посещаемости Вашего сайта. Например, Яндекс.Метрика или Google analytics -->","Y","WIDGETCODE"),
("42","metaConfirmation","<!-- В это поле необходимо прописать код подтверждения Вашего сайта. Например, Яндекс.Метрика или Google analytics -->","Y","META_TAGS_CONFIRMATION"),
("43","noReplyEmail","noreply@sitename.ru","Y","NOREPLY_EMAIL"),
("44","smtp","false","Y","SMTP"),
("45","smtpHost","","Y","SMTP_HOST"),
("46","smtpLogin","","Y","SMTP_LOGIN"),
("47","smtpPass","","Y","SMTP_PASS"),
("48","smtpPort","","Y","SMTP_PORT"),
("49","shopPhone","8 (555) 555-55-55","Y","SHOP_PHONE"),
("50","shopAddress","г. Москва, ул. Тверская, 1. ","Y","SHOP_ADDERSS"),
("51","shopName","Интернет-магазин","Y","SHOP_NAME"),
("52","shopLogo","/uploads/logo.svg","Y","SHOP_LOGO"),
("53","phoneMask","+7 (###) ### ##-##,+380 (##) ### ##-##,+375 (##) ### ##-##","Y","PHONE_MASK"),
("54","printStrProp","false","Y","PROP_STR_PRINT"),
("55","noneSupportOldTemplate","false","Y","OLD_TEMPLATE"),
("56","printCompareButton","true","Y","BUTTON_COMPARE"),
("57","currencyShopIso","RUR","Y","CUR_SHOP_ISO"),
("58","cacheObject","true","Y","CACHE_OBJECT"),
("59","cacheMode","FILE","Y","CACHE_MODE"),
("60","cacheTime","86400","Y","CACHE_TIME"),
("61","cacheHost","","Y","CACHE_HOST"),
("62","cachePort","","Y","CACHE_PORT"),
("63","priceFormat","1 234,56","Y","PRICE_FORMAT"),
("64","horizontMenu","false","Y","HORIZONT_MENU"),
("65","buttonBuyName","Купить","Y","BUTTON_BUY_NAME"),
("66","buttonCompareName","Сравнить","Y","BUTTON_COMPARE_NAME"),
("67","randomProdBlock","false","Y","RANDOM_PROD_BLOCK"),
("68","buttonMoreName","Подробнее","Y","BUTTON_MORE_NAME"),
("69","compareCategory","true","Y","COMPARE_CATEGORY"),
("70","colorScheme","1","Y","COLOR_SCHEME"),
("71","useCaptcha","","Y","USE_CAPTCHA"),
("72","autoRegister","true","Y","AUTO_REGISTER"),
("73","printFilterResult","true","Y","FILTER_RESULT"),
("74","dateActivateKey","2023-10-29 11:33:38","N",""),
("75","propertyOrder","a:20:{s:7:\"nameyur\";s:6:\"ООО\";s:6:\"adress\";s:48:\"г.Москва ул. Тверская, дом 1\";s:5:\"email\";s:0:\"\";s:3:\"inn\";s:10:\"8805614058\";s:3:\"kpp\";s:9:\"980501000\";s:4:\"ogrn\";s:13:\"7137847078193\";s:4:\"bank\";s:16:\"Сбербанк\";s:3:\"bik\";s:9:\"041012721\";s:2:\"ks\";s:20:\"40702810032030000834\";s:2:\"rs\";s:20:\"30101810600000000957\";s:7:\"general\";s:48:\"Михаил Васильевич Могутов\";s:4:\"sing\";s:0:\"\";s:5:\"stamp\";s:0:\"\";s:3:\"nds\";s:2:\"18\";s:8:\"usedsing\";s:4:\"true\";s:8:\"currency\";s:34:\"рубль,рубля,рублей\";s:12:\"order_status\";s:1:\"0\";s:19:\"default_date_filter\";s:7:\"default\";s:15:\"downloadInvoice\";s:1:\"1\";s:19:\"paymentAfterConfirm\";s:5:\"false\";}","N","PROPERTY_OPRDER"),
("76","enabledSiteEditor","false","N",""),
("77","lockAuthorization","false","Y","LOCK_AUTH"),
("78","orderNumber","true","Y","ORDER_NUMBER"),
("79","popupCart","true","Y","POPUP_CART"),
("80","catalogIndex","false","Y","CATALOG_INDEX"),
("81","productInSubcat","true","Y","PRODUCT_IN_SUBCAT"),
("82","copyrightMoguta","true","Y","COPYRIGHT_MOGUTA"),
("83","copyrightMogutaLink","","Y","COPYRIGHT_MOGUTA_LINK"),
("84","picturesCategory","true","Y","PICTURES_CATEGORY"),
("85","noImageStub","/uploads/no-img.jpg","Y","NO_IMAGE_STUB"),
("86","backgroundSite","","Y","BACKGROUND_SITE"),
("87","backgroundColorSite","","Y","BACKGROUND_COLOR_SITE"),
("88","backgroundTextureSite","","Y","BACKGROUND_TEXTURE_SITE"),
("89","backgroundSiteLikeTexture","false","Y","BACKGROUND_SITE_LIKE_TEXTURE"),
("90","fontSite","","Y","FONT_SITE"),
("91","cacheCssJs","false","Y","CACHE_CSS_JS"),
("92","categoryImgWidth","200","Y","CATEGORY_IMG_WIDTH"),
("93","categoryImgHeight","200","Y","CATEGORY_IMG_HEIGHT"),
("94","propImgWidth","50","Y","PROP_IMG_WIDTH"),
("95","propImgHeight","50","Y","PROP_IMG_HEIGHT"),
("96","favicon","favicon.ico","Y","FAVICON"),
("97","connectZoom","true","Y","CONNECT_ZOOM"),
("98","filterSort","price_course|asc","Y","FILTER_SORT"),
("99","shortLink","false","Y","SHORT_LINK"),
("100","imageResizeType","PROPORTIONAL","Y","IMAGE_RESIZE_TYPE");
INSERT INTO `mg_setting` VALUES
("101","imageSaveQuality","75","Y","IMAGE_SAVE_QUALITY"),
("102","duplicateDesc","false","Y","DUPLICATE_DESC"),
("103","excludeUrl","","Y","EXCLUDE_SITEMAP"),
("104","autoGeneration","false","Y","AUTO_GENERATION"),
("105","generateEvery","2","Y","GENERATE_EVERY"),
("106","consentData","false","Y","CONSENT_DATA"),
("107","showCountInCat","true","Y","SHOW_COUNT_IN_CAT"),
("108","nameOfLinkyml","getyml","N","NAME_OF_LINKYML"),
("109","clearCatalog1C","false","Y","CLEAR_1C_CATALOG"),
("110","fileLimit1C","10000000","Y","FILE_LIMIT_1C"),
("111","ordersPerTransfer1c","1000","Y","ORDERS_PER_TRANSFER_1C"),
("112","weightPropertyName1c","Вес","Y","WEIGHT_NAME_1C"),
("113","multiplicityPropertyName1c","Кратность","Y","MULTIPLICITY_NAME_1C"),
("114","oldPriceName1c","","Y","OLD_PRICE_NAME_1C"),
("115","retailPriceName1c","","Y","RETAIL_PRICE_NAME_1C"),
("116","showSortFieldAdmin","false","Y","SHOW_SORT_FIELD_ADMIN"),
("117","filterSortVariant","price_course|asc","Y","FILTER_SORT_VARIANT"),
("118","productsOutOfStockToEnd","false","Y","PRODUCTS_OUT_OF_STOCK_TO_THE_END"),
("119","showVariantNull","true","Y","SHOW_VARIANT_NULL"),
("120","confirmRegistration","true","Y","CONFIRM_REGISTRATION"),
("121","cachePrefix","","Y","CACHE_PREFIX"),
("122","usePhoneMask","true","Y","USE_PHONE_MASK"),
("123","smtpSsl","false","Y","SMTP_SSL"),
("124","sessionToDB","false","Y","SAVE_SESSION_TO_DB"),
("125","sessionLifeTime","1440","Y","SESSION_LIVE_TIME"),
("126","sessionAutoUpdate","true","Y","SESSION_AUTO_UPDATE"),
("127","showCodeInCatalog","false","Y","SHOW_CODE_IN_CATALOG"),
("128","openGraph","true","Y","OPEN_GRAPH"),
("129","openGraphLogoPath","","Y","OPEN_GRAPH_LOGO_PATH"),
("130","dublinCore","true","Y","DUBLIN_CORE"),
("131","printSameProdNullRem","true","Y","PRINT_SAME_PROD_NULL_REM"),
("132","landingName","lp-moguta","N","LANDING_NAME"),
("133","colorSchemeLanding","none","N","COLOR_SCHEME_LANDING"),
("134","printQuantityInMini","false","Y","SHOW_QUANTITY"),
("135","printCurrencySelector","false","Y","CURRENCY_SELECTOR"),
("136","interface","a:7:{s:9:\"colorMain\";s:7:\"#2773eb\";s:9:\"colorLink\";s:7:\"#1585cf\";s:9:\"colorSave\";s:7:\"#4caf50\";s:11:\"colorBorder\";s:7:\"#e6e6e6\";s:14:\"colorSecondary\";s:7:\"#ebebeb\";s:8:\"adminBar\";s:7:\"#f0f1f3\";s:17:\"adminBarFontColor\";s:7:\"#000000\";}","Y","INTERFACE_SETTING"),
("137","filterCountProp","3","Y","FILTER_COUNT_PROP"),
("138","filterMode","true","Y","FILTER_MODE"),
("139","filterCountShow","5","Y","FILTER_COUNT_SHOW"),
("140","filterSubcategory","false","Y","FILTER_SUBCATGORY"),
("141","printVariantsInMini","false","Y","SHOW_VARIANT_MINI"),
("142","useReCaptcha","false","Y","USE_RECAPTCHA"),
("143","invisibleReCaptcha","false","Y","INVISIBLE_RECAPTCHA"),
("144","reCaptchaKey","","Y","RECAPTCHA_KEY"),
("145","reCaptchaSecret","","Y","RECAPTCHA_SECRET"),
("146","timeWork","09:00 - 19:00,10:00 - 17:00","Y","TIME_WORK"),
("147","useSeoRewrites","false","Y","SEO_REWRITES"),
("148","useSeoRedirects","false","Y","SEO_REDIRECTS"),
("149","showMainImgVar","false","Y","SHOW_MAIN_IMG_VAR"),
("150","loginAttempt","5","Y","LOGIN_ATTEMPT"),
("151","prefixOrder","M-010","Y","PREFIX_ORDER"),
("152","captchaOrder","false","Y","CAPTCHA_ORDER"),
("153","deliveryZero","true","Y","DELIVERY_ZERO"),
("154","outputMargin","true","Y","OUTPUT_MARGIN"),
("155","prefixCode","CN","Y","PREFIX_CODE"),
("156","maxUploadImgWidth","1500","Y","MAX_UPLOAD_IMAGE_WIDTH"),
("157","maxUploadImgHeight","1500","Y","MAX_UPLOAD_IMAGE_HEIGHT"),
("158","searchType","like","Y","SEARCH_TYPE"),
("159","searchSphinxHost","localhost","Y","SEARCH_SPHINX_HOST"),
("160","searchSphinxPort","9312","Y","SEARCH_SPHINX_PORT"),
("161","checkAdminIp","false","Y","CHECK_ADMIN_IP"),
("162","printSeo","all","Y","PRINT_SEO"),
("163","catalogProp","0","Y","CATALOG_PROP"),
("164","printAgreement","true","Y","PRINT_AGREEMENT"),
("165","currencyShort","a:6:{s:3:\\\"RUR\\\";s:7:\\\"руб.\\\";s:3:\\\"UAH\\\";s:7:\\\"грн.\\\";s:3:\\\"USD\\\";s:1:\\\"$\\\";s:3:\\\"EUR\\\";s:3:\\\"€\\\";s:3:\\\"KZT\\\";s:10:\\\"тенге\\\";s:3:\\\"UZS\\\";s:6:\\\"сум\\\";}","Y","CUR_SHOP_SHORT"),
("166","useElectroLink","false","Y","USE_ELECTRO_LINK"),
("167","useMultiplicity","false","Y","USE_MULTIPLICITY"),
("168","currencyActive","a:5:{i:0;s:3:\"UAH\";i:1;s:3:\"USD\";i:2;s:3:\"EUR\";i:3;s:3:\"KZT\";i:4;s:3:\"UZS\";}","Y",""),
("169","closeSite","false","Y","CLOSE_SITE_1C"),
("170","catalogPreCalcProduct","old","Y","CATALOG_PRE_CALC_PRODUCT"),
("171","printSpecFilterBlock","true","Y","FILTER_PRINT_SPEC"),
("172","disabledPropFilter","false","Y","DISABLED_PROP_FILTER"),
("173","enableDeliveryCur","false","Y","ENABLE_DELIVERY_CUR"),
("174","addDateToImg","true","Y","ADD_DATE_TO_IMG"),
("175","variantToSize1c","false","Y","VARIANT_TO_SIZE_1C"),
("176","skipRootCat1C","false","Y","SKIP_ROOT_CAT_1C"),
("177","sphinxLimit","20","Y","SPHINX_LIMIT"),
("178","filterCatalogMain","false","Y","FILTER_CATALOG_MAIN"),
("179","importColorSize","size","Y","IMPORT_COLOR_SIZE"),
("180","sizeName1c","Размер","Y","SIZE_NAME_1C"),
("181","colorName1c","Цвет","Y","COLOR_NAME_1C"),
("182","sizeMapMod","COLOR","Y","SIZE_MAP_MOD"),
("183","modParamInVarName","true","Y","MOD_PARAM_IN_VAR_NAME"),
("184","orderOwners","false","Y","ORDER_OWNERS"),
("185","ownerRotation","false","Y","OWNER_ROTATION"),
("186","ownerRotationCurrent","","Y","OWNER_ROTATION_CURRENT"),
("187","ownerList","","Y","OWNER_LIST"),
("188","ownerRemember","false","Y","OWNER_REMBER"),
("189","ownerRememberPhone","false","Y","OWNER_REMBER_PHONE"),
("190","ownerRememberEmail","false","Y","OWNER_REMBER_EMAIL"),
("191","ownerRememberDays","14","Y","OWNER_REMBER_DAYS"),
("192","convertCountToHR","2:последний товар,5:скоро закончится,15:мало,100:много","Y","CONVERT_COUNT_TO_HR"),
("193","blockEntity","false","Y","BLOCK_ENTITY"),
("194","useFavorites","true","Y","USE_FAVORITES"),
("195","countPrintRowsBrand","10","Y",""),
("196","varHashProduct","true","Y","VAR_HASH_PRODUCT"),
("197","useSearchEngineInfo","false","Y","USE_SEARCH_ENGINE_INFO"),
("198","timezone","noChange","Y","TIMEZONE"),
("199","recalcWholesale","true","Y","RECALC_WHOLESALE"),
("200","recalcForeignCurrencyOldPrice","true","Y","RECALCT_FOREIGN_CURRENCY_OLD_PRICE");
INSERT INTO `mg_setting` VALUES
("201","printOneColor","false","Y","PRINT_ONE_COLOR"),
("202","updateStringProp1C","false","Y","UPDATE_STRING_PROP_1C"),
("203","weightUnit1C","kg","Y","WEIGHT_UNIT_1C"),
("204","writeLog1C","false","Y","WRITE_LOG_1C"),
("205","writeFiles1C","false","Y","WRITE_FILES_1C"),
("206","writeFullName1C","false","Y","WRITE_FULL_NAME_1C"),
("207","activityCategory1C","true","Y","ACTIVITY_CATEGORY_1C"),
("208","notUpdate1C","a:14:{s:8:\"1c_title\";s:4:\"true\";s:7:\"1c_code\";s:4:\"true\";s:6:\"1c_url\";s:4:\"true\";s:9:\"1c_weight\";s:4:\"true\";s:8:\"1c_count\";s:4:\"true\";s:14:\"1c_description\";s:4:\"true\";s:12:\"1c_image_url\";s:4:\"true\";s:13:\"1c_meta_title\";s:4:\"true\";s:16:\"1c_meta_keywords\";s:4:\"true\";s:12:\"1c_meta_desc\";s:5:\"false\";s:11:\"1c_activity\";s:4:\"true\";s:12:\"1c_old_price\";s:4:\"true\";s:9:\"1c_cat_id\";s:4:\"true\";s:15:\"1c_multiplicity\";s:5:\"false\";}","y","update_1c"),
("209","notUpdateCat1C","a:4:{s:11:\"cat1c_title\";s:4:\"true\";s:9:\"cat1c_url\";s:4:\"true\";s:12:\"cat1c_parent\";s:4:\"true\";s:18:\"cat1c_html_content\";s:5:\"false\";}","Y","UPDATE_CAT_1C"),
("210","listMatch1C","a:7:{i:0;s:27:\"не подтвержден\";i:1;s:27:\"ожидает оплаты\";i:2;s:14:\"оплачен\";i:3;s:19:\"в доставке\";i:4;s:14:\"отменен\";i:5;s:16:\"выполнен\";i:6;s:21:\"в обработке\";}","Y","UPDATE_STATUS_1C"),
("211","product404","false","Y",""),
("212","product404Sitemap","false","Y",""),
("213","productFilterPriceSliderStep","10","Y","PRODUCT_FILTER_PRICE_SLIDER_STEP"),
("214","catalogColumns","a:6:{i:0;s:6:\"number\";i:1;s:8:\"category\";i:2;s:3:\"img\";i:3;s:5:\"title\";i:4;s:5:\"price\";i:5;s:5:\"count\";}","Y",""),
("215","orderColumns","a:9:{i:0;s:2:\"id\";i:1;s:6:\"number\";i:2;s:4:\"date\";i:3;s:3:\"fio\";i:4;s:5:\"email\";i:5;s:4:\"summ\";i:6;s:5:\"deliv\";i:7;s:7:\"payment\";i:8;s:6:\"status\";}","Y",""),
("216","userColumns","a:5:{i:0;s:5:\"email\";i:1;s:6:\"status\";i:2;s:5:\"group\";i:3;s:8:\"register\";i:4;s:8:\"personal\";}","Y",""),
("217","useNameParts","false","Y","ORDER_NAME_PARTS"),
("218","searchInDefaultLang","true","Y","SEARCH_IN_DEFAULT_LANG"),
("219","backupBeforeUpdate","true","Y","BACKUP_BEFORE_UPDATE"),
("220","mailsBlackList","","Y","MAILS_BLACK_LIST"),
("221","rememberLogins","true","Y","REMEMBER_LOGINS"),
("222","rememberLoginsDays","180","Y","REMEMBER_LOGINS_DAYS"),
("223","loginBlockTime","15","Y","LOGIN_BLOCK_TIME"),
("224","printMultiLangSelector","true","Y",""),
("225","imageResizeRetina","false","Y","IMAGE_RESIZE_RETINA"),
("226","timeWorkDays","Пн-Пт:,Сб-Вс:","Y","TIME_WORK_DAYS"),
("227","logger","false","Y","LOGGER"),
("228","hitsFlag","true","Y","HITSFLAG"),
("229","introFlag","[\"main\"]","Y","INTRO_FLAG"),
("230","useAbsolutePath","true","Y","USE_ABSOLUTE_PATH"),
("231","productSitemapLocale","true","Y","PRODUCT_SITEMAP_LOCALE"),
("232","sitetheme","","Y","SITE_TEME"),
("233","siteThemeVariants","a:41:{i:0;s:26:\"Одежда и обувь\";i:1;s:55:\"Электроника и бытовая техника\";i:2;s:42:\"Косметика и парфюмерия\";i:3;s:53:\"Специализированные магазины\";i:4;s:64:\"Товары для ремонта и строительства\";i:5;s:46:\"Автозапчасти и транспорт\";i:6;s:34:\"Красота и здоровье\";i:7;s:30:\"Товары для детей\";i:8;s:28:\"Товары для дома\";i:9;s:46:\"Товары для сада и огорода\";i:10;s:32:\"Товары для спорта\";i:11;s:29:\"Доставка цветов\";i:12;s:54:\"Товары для хобби и творчества\";i:13;s:58:\"Смартфоны, планшеты, аксессуары\";i:14;s:49:\"Продукты питания и напитки\";i:15;s:43:\"Универсальные магазины\";i:16;s:30:\"Товары для офиса\";i:17;s:36:\"Товары для животных\";i:18;s:18:\"Чай и кофе\";i:19;s:28:\"Табак и кальяны\";i:20;s:28:\"Рыбалка и охота\";i:21;s:34:\"Свет и светильники\";i:22;s:32:\"Сантехника и вода\";i:23;s:44:\"Радиотехника и запчасти\";i:24;s:34:\"Товары для бизнеса\";i:25;s:12:\"Мебель\";i:26;s:32:\"Еда, пицца и роллы\";i:27;s:56:\"Производство и промышленность\";i:28;s:36:\"Товары для взрослых\";i:29;s:58:\"Видеонаблюдение и безопасность\";i:30;s:10:\"Сумки\";i:31;s:12:\"Услуги\";i:32;s:30:\"Софт и программы\";i:33;s:47:\"Ювелирные магазины и часы\";i:34;s:10:\"Двери\";i:35;s:10:\"Книги\";i:36;s:34:\"Подарки и сувениры\";i:37;s:34:\"Упаковки и коробки\";i:38;s:62:\"Средства для борьбы с вредителями\";i:39;s:31:\"Постельное белье\";i:40;s:12:\"Другое\";}","N","SITE_TEME_VARIANTS"),
("234","useDefaultSettings","false","N",""),
("235","backupSettingsFile","","N",""),
("236","ordersPerPageForUser","10","Y","ORDER_USER_COUNT"),
("237","useTemplatePlugins","1","Y","USE_TEMPLATE_PLUGINS"),
("238","thumbsProduct","false","Y","THUMBS_PRODUCT"),
("239","exifRotate","false","Y","EXIF_ROTATE"),
("240","metaLangContent","zxx","Y","META_LANG_CONTENT"),
("241","useSeoCanonical","false","Y","SEO_CANONICAL"),
("242","confirmRegistrationEmail","true","Y","CONFIRM_REGISTRATION_EMAIL"),
("243","confirmRegistrationPhone","false","Y","CONFIRM_REGISTRATION_PHONE"),
("244","confirmRegistrationPhoneType","sms","Y","CONFIRM_REGISTRATION_PHONE_TYPE"),
("245","storages_settings","a:3:{s:12:\"writeOffProc\";s:1:\"1\";s:28:\"storagesAlgorithmWithoutMain\";s:0:\"\";s:11:\"mainStorage\";s:0:\"\";}","N","STORAGES_SETTINGS"),
("246","useOneStorage","false","N","USE_ONE_STORAGE"),
("247","genMetaLang","true","Y","GEN_META_LANG"),
("248","catalog_meta_title","Купить {titeCategory} в Москве","N","CATALOG_META_TITLE"),
("249","catalog_meta_description","{cat_desc,160}","N","CATALOG_META_DESC"),
("250","catalog_meta_keywords","{meta_keywords}","N","CATALOG_META_KEYW"),
("251","product_meta_title","Купить {title} в Москве","N","PRODUCT_META_TITLE"),
("252","product_meta_description","Акция! {title} за {price} {currency} купить в Москве. {description,100}","N","PRODUCT_META_DESC"),
("253","product_meta_keywords","{%title}","N","PRODUCT_META_KEYW"),
("254","page_meta_title","{title}","N","PAGE_META_TITLE"),
("255","page_meta_description","{html_content,160}","N","PAGE_META_DESC"),
("256","page_meta_keywords","{meta_keywords}","N","PAGE_META_KEYW"),
("257","useWebpImg","false","Y","USE_WEBP_IMAGES"),
("258","currencyRate","a:6:{s:3:\\\"RUR\\\";d:1;s:3:\\\"UAH\\\";d:2.03990999999999989000798450433649122714996337890625;s:3:\\\"USD\\\";d:56.62780000000000057980287238024175167083740234375;s:3:\\\"EUR\\\";d:70.4959000000000060026650317013263702392578125;s:3:\\\"KZT\\\";d:0.1756999999999999950706097706643049605190753936767578125;s:3:\\\"UZS\\\";d:0.00692599999999999986488585790311844903044402599334716796875;}","Y","CUR_SHOP_RATE"),
("259","1c_unit_item","Килограмм:кг,Метр:м,Квадратный метр:м2,Кубический метр:м3,Штука:шт.,Литр:л","Y","1C_UNIT_ITEM"),
("260","showStoragesRecalculate","false","Y",""),
("261","orderFormFields","a:14:{s:5:\"email\";a:4:{s:6:\"active\";s:1:\"1\";s:4:\"sort\";s:1:\"1\";s:8:\"required\";s:1:\"1\";s:13:\"conditionType\";s:6:\"always\";}s:5:\"phone\";a:6:{s:6:\"active\";s:1:\"1\";s:4:\"sort\";s:1:\"2\";s:8:\"required\";s:1:\"1\";s:13:\"conditionType\";s:6:\"always\";s:10:\"conditions\";N;s:4:\"type\";s:5:\"input\";}s:3:\"fio\";a:4:{s:6:\"active\";s:1:\"1\";s:4:\"sort\";s:1:\"3\";s:8:\"required\";s:1:\"0\";s:13:\"conditionType\";s:6:\"always\";}s:7:\"address\";a:6:{s:6:\"active\";s:1:\"1\";s:4:\"sort\";s:1:\"4\";s:8:\"required\";s:1:\"0\";s:13:\"conditionType\";s:5:\"ifAll\";s:10:\"conditions\";a:1:{i:0;a:2:{s:4:\"type\";s:8:\"delivery\";s:5:\"value\";a:3:{i:0;s:1:\"0\";i:1;s:1:\"1\";i:2;s:1:\"2\";}}}s:4:\"type\";s:5:\"input\";}s:4:\"info\";a:5:{s:6:\"active\";s:1:\"1\";s:4:\"sort\";s:1:\"5\";s:8:\"required\";s:1:\"0\";s:13:\"conditionType\";s:6:\"always\";s:10:\"conditions\";N;}s:8:\"customer\";a:4:{s:6:\"active\";s:1:\"1\";s:4:\"sort\";s:1:\"6\";s:8:\"required\";s:1:\"0\";s:13:\"conditionType\";s:6:\"always\";}s:16:\"yur_info_nameyur\";a:5:{s:6:\"active\";s:1:\"1\";s:4:\"sort\";s:1:\"7\";s:8:\"required\";s:1:\"0\";s:13:\"conditionType\";s:5:\"ifAll\";s:10:\"conditions\";a:1:{i:0;a:4:{s:4:\"type\";s:10:\"orderField\";s:9:\"fieldName\";s:8:\"customer\";s:9:\"fieldType\";s:6:\"select\";s:5:\"value\";a:1:{i:0;s:3:\"yur\";}}}}s:15:\"yur_info_adress\";a:5:{s:6:\"active\";s:1:\"1\";s:4:\"sort\";s:1:\"8\";s:8:\"required\";s:1:\"0\";s:13:\"conditionType\";s:5:\"ifAll\";s:10:\"conditions\";a:1:{i:0;a:4:{s:4:\"type\";s:10:\"orderField\";s:9:\"fieldName\";s:8:\"customer\";s:9:\"fieldType\";s:6:\"select\";s:5:\"value\";a:1:{i:0;s:3:\"yur\";}}}}s:12:\"yur_info_inn\";a:5:{s:6:\"active\";s:1:\"1\";s:4:\"sort\";s:1:\"9\";s:8:\"required\";s:1:\"0\";s:13:\"conditionType\";s:5:\"ifAll\";s:10:\"conditions\";a:1:{i:0;a:4:{s:4:\"type\";s:10:\"orderField\";s:9:\"fieldName\";s:8:\"customer\";s:9:\"fieldType\";s:6:\"select\";s:5:\"value\";a:1:{i:0;s:3:\"yur\";}}}}s:12:\"yur_info_kpp\";a:5:{s:6:\"active\";s:1:\"1\";s:4:\"sort\";s:2:\"10\";s:8:\"required\";s:1:\"0\";s:13:\"conditionType\";s:5:\"ifAll\";s:10:\"conditions\";a:1:{i:0;a:4:{s:4:\"type\";s:10:\"orderField\";s:9:\"fieldName\";s:8:\"customer\";s:9:\"fieldType\";s:6:\"select\";s:5:\"value\";a:1:{i:0;s:3:\"yur\";}}}}s:13:\"yur_info_bank\";a:5:{s:6:\"active\";s:1:\"1\";s:4:\"sort\";s:2:\"11\";s:8:\"required\";s:1:\"0\";s:13:\"conditionType\";s:5:\"ifAll\";s:10:\"conditions\";a:1:{i:0;a:4:{s:4:\"type\";s:10:\"orderField\";s:9:\"fieldName\";s:8:\"customer\";s:9:\"fieldType\";s:6:\"select\";s:5:\"value\";a:1:{i:0;s:3:\"yur\";}}}}s:12:\"yur_info_bik\";a:5:{s:6:\"active\";s:1:\"1\";s:4:\"sort\";s:2:\"12\";s:8:\"required\";s:1:\"0\";s:13:\"conditionType\";s:5:\"ifAll\";s:10:\"conditions\";a:1:{i:0;a:4:{s:4:\"type\";s:10:\"orderField\";s:9:\"fieldName\";s:8:\"customer\";s:9:\"fieldType\";s:6:\"select\";s:5:\"value\";a:1:{i:0;s:3:\"yur\";}}}}s:11:\"yur_info_ks\";a:5:{s:6:\"active\";s:1:\"1\";s:4:\"sort\";s:2:\"13\";s:8:\"required\";s:1:\"0\";s:13:\"conditionType\";s:5:\"ifAll\";s:10:\"conditions\";a:1:{i:0;a:4:{s:4:\"type\";s:10:\"orderField\";s:9:\"fieldName\";s:8:\"customer\";s:9:\"fieldType\";s:6:\"select\";s:5:\"value\";a:1:{i:0;s:3:\"yur\";}}}}s:11:\"yur_info_rs\";a:5:{s:6:\"active\";s:1:\"1\";s:4:\"sort\";s:2:\"14\";s:8:\"required\";s:1:\"0\";s:13:\"conditionType\";s:5:\"ifAll\";s:10:\"conditions\";a:1:{i:0;a:4:{s:4:\"type\";s:10:\"orderField\";s:9:\"fieldName\";s:8:\"customer\";s:9:\"fieldType\";s:6:\"select\";s:5:\"value\";a:1:{i:0;s:3:\"yur\";}}}}}","Y",""),
("262","lastModVersion","11.0.10","N",""),
("263","lastTimeCacheClear","1729961233","N",""),
("264","chimpApiKey","cbRffRbcabNfiRPcdWZnyGLyOZSdLPOiSNa","N",""),
("267","trialVersionHash","cyRZfdbPalNwippmwJlscVRSfObLcIRCfebu","N",""),
("273","imageDropTimer","1730046264","N",""),
("278","sizeTempFiles","0","N",""),
("280","tempSizeCheckTime","1729959867","N",""),
("281","checkEngine","1729959867","N",""),
("292","pluginsVersionInfo","a:0:{}","N",""),
("296","nextCheckPlugin","1730046336","N",""),
("297","mpPlugins","a:4:{s:7:\\\"plugins\\\";a:79:{i:0;s:42:\\\"db279c5e8a92f741984ee8afa7499fac9512412017\\\";i:1;s:42:\\\"82ebd8293263ccd8b0ef78fe2bcbb5ed7965528918\\\";i:2;s:42:\\\"4525ca2efb7dd5fb2ec371e89d0f366f5377806372\\\";i:3;s:42:\\\"f7a046bd1d850369c5a8c7389de5a2825146955940\\\";i:4;s:42:\\\"5f5694ac20f0646d62181bb86451790a3988354893\\\";i:5;s:42:\\\"33ac44cb0e32a93618003803032512217842131961\\\";i:6;s:42:\\\"831f7714b1c69c15ed749e982d0b98cd8080112842\\\";i:7;s:42:\\\"5d03125f792b66dca0749724b58b40ee8983820027\\\";i:8;s:42:\\\"e0ae5078e83a59ff1c40a9ca59c2b0842776612159\\\";i:9;s:42:\\\"1bd544814016c6c1af7b1f681eae66645627739938\\\";i:10;s:42:\\\"5a6cdb7c768c91fdc3da0cbbe950482c8032222129\\\";i:11;s:42:\\\"64ef2b40c29d07aa98c789dbc4a714572632693325\\\";i:12;s:42:\\\"72c71193311059d248643be1055d2f0d3352203821\\\";i:13;s:42:\\\"6a02824a334312655f2ab220fa661b423750243885\\\";i:14;s:42:\\\"7b70c4e1465cd4293fb98daa7b4f1d595190577090\\\";i:15;s:42:\\\"cf8758d03cf27b81eef3e1b41f9fee045237938992\\\";i:16;s:42:\\\"1ff41d688bdc25385b81a43320f433d04688918972\\\";i:17;s:42:\\\"f5771d452d59e6fc3079b73702fb3fff5874970753\\\";i:18;s:42:\\\"2fdbc0ec4b6b8797bfe08bde2e7bb74d6508212653\\\";i:19;s:42:\\\"6343c58a2a674f246907021000d6f01d4076726873\\\";i:20;s:42:\\\"169e2d69c6a2c13d2cbf82cd8a93f3347535255195\\\";i:21;s:42:\\\"38526fba1d6afbf4a0989637025d70a13542731564\\\";i:22;s:42:\\\"7f39a6455111fbc365a1e719234fccc35793164036\\\";i:23;s:42:\\\"45532a255c17e7eff2f052b04a78a34d8848569395\\\";i:24;s:42:\\\"a45ee691217bb44d1399129e875ad5c87243903040\\\";i:25;s:42:\\\"23d23c71c84be503af4c6e512c904fae5068882714\\\";i:26;s:42:\\\"d45cbefe5ed5709c67d62a0c0aea71574283061280\\\";i:27;s:42:\\\"a3024418e0132f9b99db7c941a0f85901728023577\\\";i:28;s:42:\\\"a7bde2c3fa5f01c3f84e1aaed1ca40c76724884194\\\";i:29;s:42:\\\"0b7085f0292ae323623e12060b1a56316366201289\\\";i:30;s:42:\\\"c378fb35a7feb02abd6c125cf6176e708700362722\\\";i:31;s:42:\\\"cc42d2e117d599e0d1c183b78e0a4f514314790036\\\";i:32;s:42:\\\"4fc9295b8781cc667b225c6d32b1bd409142012035\\\";i:33;s:42:\\\"37803a0a77e3e9757b1d010ad25316634787892311\\\";i:34;s:42:\\\"c230bd250c3f78381dd60a87c68dcbb35060844875\\\";i:35;s:42:\\\"627882fc99501a6e56bebf13860b1bdc4328463132\\\";i:36;s:42:\\\"75ca48714d45e6c9ea4e0c8bcf90fc0d5355231727\\\";i:37;s:42:\\\"d8b387781e064edd68cceb182cf64ddf2207076043\\\";i:38;s:42:\\\"a5b77bbd3b8489c460dfe8e3c90e72139971474346\\\";i:39;s:42:\\\"5425d9221c05857f9ec4fa47d42322293265171394\\\";i:40;s:42:\\\"4024b0a2e19f8d1eb1fde46a79b663f04098807790\\\";i:41;s:42:\\\"4159c58bd40e25e2de68e77d44766fdc8096415525\\\";i:42;s:42:\\\"c188b23298b43ccdb08958dea455e1068445581603\\\";i:43;s:42:\\\"2cd93703d7949652b26aa82a5e6b6e868931631264\\\";i:44;s:42:\\\"8703d6a0ebb0d39d8b04d0bcfb05b7fa6494490549\\\";i:45;s:42:\\\"45bbb14a8090b97ffe6656bf0f10a50a6654494790\\\";i:46;s:42:\\\"5ac68cea1f8b0c7aea84e4dc139ce2f38646387941\\\";i:47;s:42:\\\"0359ca847f3d70497e3c02651b8864ac7343627035\\\";i:48;s:42:\\\"546fda2ea7d70ff2038b3696e2f06b548572919070\\\";i:49;s:42:\\\"2245da3b180092957fa3bb7b6ad06f769185893438\\\";i:50;s:42:\\\"c776ac4090fa1b3b3dfeae18c2eaa5be5908470225\\\";i:51;s:42:\\\"36f1d41894e23d7f0da30084c37312784429413374\\\";i:52;s:42:\\\"5f3dd75e26dff5a96a6bad55696c9c528885459196\\\";i:53;s:42:\\\"6fe2697fdb4fe18be46c92f817f158432650172532\\\";i:54;s:42:\\\"e8e897a73987b3d018e446f6aedf51ac4073387365\\\";i:55;s:42:\\\"a26eea6a4199cff18174a329a2f5e0203158906771\\\";i:56;s:42:\\\"11e43d399cffeca45cf16454abb119776956005889\\\";i:57;s:42:\\\"a2def5264b3b0414ebf25328e9a1e0b95716939540\\\";i:58;s:42:\\\"e0c70893be91f4b47d09b2e33557dd2a6430730373\\\";i:59;s:42:\\\"608c23d26e4090929165f44b4574a35f4906530180\\\";i:60;s:42:\\\"f4b42df1c3083d4422c28638b2c883978033645226\\\";i:61;s:42:\\\"a554dcbeb2cfc361a4e4de0cc763f1934397322694\\\";i:62;s:42:\\\"f75a53c64855ff925926956eb924d4063932189969\\\";i:63;s:42:\\\"883824d659241ece7abc5ced088a7ac63818305689\\\";i:64;s:42:\\\"857993cb8df17d285e25a6481d3625bb5260903321\\\";i:65;s:42:\\\"914a6e4556e3920e352b8094e8ec058d8664759520\\\";i:66;s:42:\\\"f80b2f260bfe29adceb159f8b918ae0a2384017438\\\";i:67;s:42:\\\"d8a8a949f36995f69a677ff53883771a3709611725\\\";i:68;s:42:\\\"cbc6c4277855e31e01c2fe4a08783bab5245492871\\\";i:69;s:42:\\\"aa582c166682f384b7431595b1b6a2971729959932\\\";i:70;s:42:\\\"b324edd52c1f4efae99e719c0fb8e4d92876485089\\\";i:71;s:42:\\\"52477450ae6a0dad3089fb5b018530d78886807692\\\";i:72;s:42:\\\"aec02e7cff7c2a0c0ee1bffb95febbc42762102314\\\";i:73;s:42:\\\"6e2718b6994a2450cfeb9570cf8c173b9798762315\\\";i:74;s:42:\\\"b1c6f7c01268ffa38118df05265853269057825562\\\";i:75;s:42:\\\"4e1fb9452b2ab1fd7c08aee4354bd3ef7165658118\\\";i:76;s:42:\\\"27b810ae467ad19347d4f582ed89ab398560995061\\\";i:77;s:42:\\\"f97a5f11b6e2b856a0610419a58d69708273529104\\\";i:78;s:42:\\\"b8c29ab1e370f1bd692befc676f6db495366454767\\\";}s:7:\\\"boughtP\\\";a:2:{s:5:\\\"CN305\\\";s:15:\\\"mg-repeat-order\\\";s:7:\\\"PLUG227\\\";s:10:\\\"mg-gallery\\\";}s:6:\\\"trials\\\";a:1:{s:9:\\\"back-ring\\\";i:1726813977;}s:3:\\\"key\\\";s:32:\\\"9986a88009acd1578cf2cb8243e5dc2d\\\";}","N",""),
("298","mpUpdate","cURjfrbxaoNEizPqdKZoyELzOqSKLWOnSGaiN","N",""),
("299","notifInfo","<div id=\"timeInfo\" class=\"alert\">Заканчивается подписка на поддержку и обновления. Скидка на продление подписки будет доступна еще 2 дн.\n                <span class=\"extend\">(<a class=\"link\" target=\"blank\" href=\"https://moguta.ru/uslugi/prodlenie-klyucha?key=9986a88009acd1578cf2cb8243e5dc2d\"><span>Продлить сейчас</span></a>)</span><a class=\"close-timeinfo link\" href=\"javascript:void(0);\"><span>Закрыть</span></a></div>","N","");
DROP TABLE IF EXISTS `mg_avito_cats`;

CREATE TABLE `mg_avito_cats` (
  `id` int(255) NOT NULL,
  `name` varchar(249) NOT NULL,
  `parent_id` int(255) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_avito_locations`;

CREATE TABLE `mg_avito_locations` (
  `id` int(255) NOT NULL,
  `name` varchar(249) NOT NULL,
  `type` int(5) NOT NULL,
  `parent_id` int(255) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_avito_settings`;

CREATE TABLE `mg_avito_settings` (
  `name` varchar(191) NOT NULL,
  `settings` longtext NOT NULL,
  `cats` longtext NOT NULL,
  `additional` longtext NOT NULL,
  `edited` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `custom_options` longtext,
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_cache`;

CREATE TABLE `mg_cache` (
  `date_add` int(11) NOT NULL,
  `lifetime` int(11) NOT NULL,
  `name` varchar(191) NOT NULL,
  `value` longtext NOT NULL,
  UNIQUE KEY `name` (`name`),
  KEY `name_2` (`name`),
  KEY `date_add` (`date_add`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_category`;

CREATE TABLE `mg_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `left_key` int(11) NOT NULL DEFAULT '1',
  `right_key` int(11) NOT NULL DEFAULT '1',
  `level` int(11) NOT NULL DEFAULT '2',
  `title` varchar(249) DEFAULT NULL,
  `menu_title` varchar(249) NOT NULL DEFAULT '',
  `url` varchar(191) DEFAULT NULL,
  `parent` int(11) NOT NULL,
  `parent_url` varchar(191) NOT NULL,
  `sort` int(11) DEFAULT NULL,
  `html_content` longtext,
  `meta_title` text,
  `meta_keywords` text,
  `meta_desc` text,
  `invisible` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'Не выводить в меню',
  `1c_id` varchar(191) DEFAULT NULL,
  `image_url` text,
  `menu_icon` text,
  `rate` double NOT NULL DEFAULT '0',
  `export` tinyint(1) NOT NULL DEFAULT '1',
  `seo_content` text,
  `activity` tinyint(1) NOT NULL DEFAULT '1',
  `unit` varchar(249) NOT NULL DEFAULT 'шт.',
  `seo_alt` text,
  `seo_title` text,
  `menu_seo_alt` text,
  `menu_seo_title` text,
  `countProduct` int(11) NOT NULL DEFAULT '0',
  `weight_unit` varchar(10) NOT NULL DEFAULT 'kg',
  PRIMARY KEY (`id`),
  KEY `1c_id` (`1c_id`),
  KEY `url` (`url`),
  KEY `parent_url` (`parent_url`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_category_opt_fields`;

CREATE TABLE `mg_category_opt_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(249) NOT NULL,
  `sort` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_category_opt_fields_content`;

CREATE TABLE `mg_category_opt_fields_content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `field_id` int(11) NOT NULL DEFAULT '0',
  `category_id` int(11) NOT NULL DEFAULT '0',
  `value` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_category_user_property`;

CREATE TABLE `mg_category_user_property` (
  `category_id` int(11) NOT NULL,
  `property_id` int(11) NOT NULL,
  KEY `category_id` (`category_id`),
  KEY `property_id` (`property_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_comments`;

CREATE TABLE `mg_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `comment` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `uri` varchar(249) NOT NULL,
  `approved` tinyint(4) NOT NULL DEFAULT '0',
  `img` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_delivery`;

CREATE TABLE `mg_delivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(249) NOT NULL,
  `description_public` text,
  `cost` double DEFAULT NULL,
  `description` text,
  `activity` int(1) NOT NULL DEFAULT '0',
  `free` double DEFAULT NULL COMMENT 'Бесплатно от',
  `date` int(1) DEFAULT NULL,
  `date_settings` text,
  `sort` int(11) DEFAULT NULL,
  `plugin` varchar(249) DEFAULT NULL,
  `weight` longtext,
  `interval` longtext,
  `address_parts` int(1) NOT NULL DEFAULT '0',
  `show_storages` varchar(249) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COMMENT='таблица способов доставки товара';


INSERT INTO `mg_delivery` VALUES
("1","Курьер","","700","Курьерская служба","1","0","1","{\"dateShift\":0,\"daysWeek\":{\"md\":true,\"tu\":true,\"we\":true,\"thu\":true,\"fri\":true,\"sa\":true,\"su\":true},\"monthWeek\":{\"jan\":\"\",\"feb\":\"\",\"mar\":\"\",\"aip\":\"\",\"may\":\"\",\"jum\":\"\",\"jul\":\"\",\"aug\":\"\",\"sep\":\"\",\"okt\":\"\",\"nov\":\"\",\"dec\":\"\"}}","1","","","","0","0"),
("2","Почта","","200","Почта России","1","0","0","{\"dateShift\":0,\"daysWeek\":{\"md\":true,\"tu\":true,\"we\":true,\"thu\":true,\"fri\":true,\"sa\":true,\"su\":true},\"monthWeek\":{\"jan\":\"\",\"feb\":\"\",\"mar\":\"\",\"aip\":\"\",\"may\":\"\",\"jum\":\"\",\"jul\":\"\",\"aug\":\"\",\"sep\":\"\",\"okt\":\"\",\"nov\":\"\",\"dec\":\"\"}}","2","","","","0","0"),
("3","Без доставки","","0","Самовывоз","1","0","0","{\"dateShift\":0,\"daysWeek\":{\"md\":true,\"tu\":true,\"we\":true,\"thu\":true,\"fri\":true,\"sa\":true,\"su\":true},\"monthWeek\":{\"jan\":\"\",\"feb\":\"\",\"mar\":\"\",\"aip\":\"\",\"may\":\"\",\"jum\":\"\",\"jul\":\"\",\"aug\":\"\",\"sep\":\"\",\"okt\":\"\",\"nov\":\"\",\"dec\":\"\"}}","3","","","","0","0");
DROP TABLE IF EXISTS `mg_delivery_payment_compare`;

CREATE TABLE `mg_delivery_payment_compare` (
  `payment_id` int(10) DEFAULT NULL,
  `delivery_id` int(10) DEFAULT NULL,
  `compare` int(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


INSERT INTO `mg_delivery_payment_compare` VALUES
("1","1","1"),
("5","1","1"),
("2","2","1"),
("3","1","1"),
("1","2","1"),
("2","1","1"),
("3","2","1"),
("4","2","1"),
("4","3","1"),
("3","3","1"),
("2","3","1"),
("1","3","1"),
("4","1","1"),
("5","2","1"),
("6","1","1"),
("6","2","1"),
("6","3","1"),
("5","3","1"),
("7","1","1"),
("7","2","1"),
("7","3","1"),
("8","1","1"),
("8","2","1"),
("8","3","1"),
("9","1","1"),
("9","2","1"),
("9","3","1"),
("10","1","1"),
("10","2","1"),
("10","3","1"),
("1001","1","1"),
("1001","2","1"),
("1001","3","1"),
("1002","1","1"),
("1002","2","1"),
("1002","3","1"),
("1003","1","1"),
("1003","2","1"),
("1003","3","1");
DROP TABLE IF EXISTS `mg_googlemerchant`;

CREATE TABLE `mg_googlemerchant` (
  `name` varchar(191) NOT NULL,
  `settings` longtext NOT NULL,
  `cats` longtext NOT NULL,
  `edited` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_googlemerchantcats`;

CREATE TABLE `mg_googlemerchantcats` (
  `id` int(255) NOT NULL,
  `name` varchar(249) NOT NULL,
  `parent_id` int(255) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_import_yml_core_cats`;

CREATE TABLE `mg_import_yml_core_cats` (
  `id` int(11) DEFAULT NULL,
  `parentId` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `mg_import_yml_core_images`;

CREATE TABLE `mg_import_yml_core_images` (
  `id` int(11) DEFAULT NULL,
  `images` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `mg_landings`;

CREATE TABLE `mg_landings` (
  `id` int(11) NOT NULL,
  `template` varchar(249) CHARACTER SET utf8 DEFAULT NULL,
  `templateColor` varchar(6) CHARACTER SET utf8 DEFAULT NULL,
  `ytp` longtext CHARACTER SET utf8,
  `image` varchar(249) CHARACTER SET utf8 DEFAULT NULL,
  `buySwitch` varchar(6) CHARACTER SET utf8 DEFAULT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_letters`;

CREATE TABLE `mg_letters` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content` mediumtext NOT NULL,
  `lang` varchar(50) DEFAULT 'default',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4;


INSERT INTO `mg_letters` VALUES
("1","email_feedback.php","<h1 style=\'margin: 0 0 10px 0; font-size: 16px;padding: 0;\'>Сообщение с формы обратной связи!</h1><p style=\'padding: 0;margin: 10px 0;font-size: 12px;\'>Пользователь <strong>{userName}</strong> с почтовым ящиком <strong>{userEmail}</strong>, телефон: {userPhone}, пишет:</p><div style=\'margin: 0;padding: 10px;background: #FFF5B5; font-weight: bold;\'>{message}</div>","default"),
("2","email_forgot.php","<h1 style=\"margin: 0 0 10px 0; font-size: 16px;padding: 0;\">Здравствуйте!</h1><p style=\"padding: 0;margin: 10px 0;font-size: 12px;\">Вы зарегистрированы на сайте <strong>{siteName}</strong> с логином <strong>{userEmail}</strong></p><p style=\"padding: 0;margin: 10px 0;font-size: 12px;\">Для восстановления пароля пройдите по ссылке</p><div style=\"margin: 0;padding: 10px;background: #FFF5B5; font-weight: bold; text-align: center;\"><a href=\"{link}\" target=\"blank\"> {link} </a></div><p style=\"padding: 0;margin: 10px 0;font-size: 12px;\">Если Вы не делали запрос на восстановление пароля, то проигнорируйте это письмо.</p><p style=\"padding: 0;margin: 10px 0;font-size: 10px; color: #555; font-weight: bold;\">Отвечать на данное сообщение не нужно.</p>","default"),
("3","email_order.php","<table bgcolor=\"#FFFFFF\" cellspacing=\"0\" cellpadding=\"10\" border=\"0\" width=\"675\"><tbody><tr><td valign=\"top\"><h1 style=\"margin: 0 0 10px 0; font-size: 16px;padding: 0;\">Здравствуйте, {fullName}!</h1><div style=\"font-size:12px;line-height:16px;margin:0;\">Ваш заказ <b>№{orderNumber}</b> успешно оформлен.<p class=\"confirm-info\" style=\"font-size:12px;margin:0 0 10px 0\"><br>Перейдите по {confirmLink} для подтверждения заказа.<br><br>Следить за статусом заказа вы можете в <a href=\"{personal}\" style=\"color:#1E7EC8;\" target=\"_blank\">личном кабинете</a>.</p><br>Если у Вас возникнут вопросы — их можно задать по почте: <a href=\"mailto:{adminEmail}\" style=\"color:#1E7EC8;\" target=\"_blank\">{adminEmail}</a> или по телефону: <span><span class=\"js-phone-number highlight-phone\">{shopPhone}</span></span></div></td></tr></tbody></table>{tableOrder}","default"),
("4","email_order_change_status.php","<p style=\"font-size:12px;line-height:16px;margin:0;\">Здравствуйте, <b>{buyerName}</b>!<br/> Статус Вашего заказа <b>№{orderInfo}</b> был изменен c \"<b>{oldStatus}</b>\" на \"<b>{newStatus}</b>\".<br/>{managerComment}<br/>Следить за состоянием заказа Вы можете в <a href=\"{personal}\">личном кабинете</a>.</p>","default"),
("5","email_order_electro.php","<p style=\"font-size:12px;line-height:16px;margin:0;\">Ваш заказ <b>№{orderNumber}</b> содержит электронные товары, которые можно скачать по следующей ссылке:<br/> <a href=\"{getElectro}\">{getElectro}</a></p>","default"),
("6","email_order_new_user.php","<table bgcolor=\"#FFFFFF\" cellspacing=\"0\" cellpadding=\"10\" border=\"0\" width=\"675\"><tbody><tr><td valign=\"top\"><h1 style=\"margin: 0 0 10px 0; font-size: 16px;padding: 0;\">Здравствуйте, {fullName}!</h1><div style=\"font-size:12px;line-height:16px;margin:0;\"><br>Мы создали для вас <a href=\"{personal}\" style=\"color:#1E7EC8;\" target=\"_blank\">личный кабинет</a>, чтобы вы могли следить за статусом заказа, а также скачивать оплаченные электронные товары.<br><br><b>Ваш логин:</b> {userEmail}<br><b>Ваш пароль:</b> {pass}<br><b>Ссылка для подтверждения регистрации:</b>{link}</div></td></tr></tbody></table>","default"),
("7","email_order_paid.php","<p style=\"font-size:12px;line-height:16px;margin:0;\">Вы получили это письмо, так как произведена оплата заказа №{orderNumber} на сумму {summ}. Оплата произведена при помощи {payment} <br/>Статус заказа сменен на \"{status} \"</p>","default"),
("9","email_registry.php","<h1 style=\"margin: 0 0 10px 0; font-size: 16px;padding: 0;\">Здравствуйте!</h1><p style=\"padding: 0;margin: 10px 0;font-size: 12px;\">Вы получили данное письмо так как зарегистрировались на сайте <strong>{siteName}</strong> с логином <strong>{userEmail}</strong></p><p style=\"padding: 0;margin: 10px 0;font-size: 12px;\">Для активации пользователя и возможности пользоваться личным кабинетом пройдите по ссылке:</p><div style=\"margin: 0;padding: 10px;background: #FFF5B5; font-weight: bold; text-align: center;\">{link}</div><p style=\"padding: 0;margin: 10px 0;font-size: 10px; color: #555; font-weight: bold;\">Отвечать на данное сообщение не нужно.</p>","default"),
("10","email_registry_independent.php","<h1 style=\"margin: 0 0 10px 0; font-size: 16px;padding: 0;\">Здравствуйте!</h1><p style=\"padding: 0;margin: 10px 0;font-size: 12px;\">Вы получили данное письмо так как на сайте <strong>{siteName} </strong> зарегистрирован новый пользователь с логином <strong>{userEmail}</strong></p><p style=\"padding: 0;margin: 10px 0;font-size: 10px; color: #555; font-weight: bold;\">Отвечать на данное сообщение не нужно.</p>","default"),
("11","email_unclockauth.php","<h1 style=\"margin: 0 0 10px 0; font-size: 16px;padding: 0;\">Подбор паролей на сайте {siteName} предотвращен!</h1><p style=\"padding: 0;margin: 10px 0;font-size: 12px;\">Система защиты от перебора паролей для авторизации зафиксировала активность. С IP адреса {IP} было введено более 5 неверных паролей. Последний email: <strong>{lastEmail}</strong> Пользователь вновь сможет ввести пароль через 15 минут.</p><p style=\"padding: 0;margin: 10px 0;font-size: 12px;\">Если 5 неправильных попыток авторизации были инициированы администратором,то для снятия блокировки перейдите по ссылке</p><div style=\"margin: 0;padding: 10px;background: #FFF5B5; font-weight: bold; text-align: center;\">{link}</div><p style=\"padding: 0;margin: 10px 0;font-size: 10px; color: #555; font-weight: bold;\">Отвечать на данное сообщение не нужно.</p>","default");
DROP TABLE IF EXISTS `mg_locales`;

CREATE TABLE `mg_locales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_ent` int(11) NOT NULL,
  `locale` varchar(249) CHARACTER SET utf8 NOT NULL,
  `table` varchar(249) CHARACTER SET utf8 NOT NULL,
  `field` varchar(249) CHARACTER SET utf8 NOT NULL,
  `text` longtext CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `id_ent` (`id_ent`),
  KEY `locale` (`locale`),
  KEY `table` (`table`),
  KEY `field` (`field`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_logs_ajax`;

CREATE TABLE `mg_logs_ajax` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ajax` text NOT NULL COMMENT 'Запрос, в котором данные, кроме данных для роутинга, заменены на _sql_',
  `action` varchar(256) NOT NULL,
  `actioner` varchar(256) NOT NULL,
  `handler` varchar(256) NOT NULL,
  `mguniqueurl` varchar(256) NOT NULL,
  `params` text NOT NULL COMMENT 'Часть запроса с данными, без данных о роутинге',
  `example` text NOT NULL COMMENT 'Исходный запрос со всеми данными',
  `controller` varchar(32) NOT NULL COMMENT 'ajax или ajaxRequest',
  `requestType` varchar(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `mg_messages`;

CREATE TABLE `mg_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(249) NOT NULL,
  `text` text NOT NULL,
  `text_original` text NOT NULL,
  `group` varchar(249) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=utf8mb4;


INSERT INTO `mg_messages` VALUES
("1","msg__order_denied","Для просмотра страницы необходимо зайти на сайт под пользователем сделавшим заказ №#NUMBER#.","Для просмотра страницы необходимо зайти на сайт под пользователем сделавшим заказ №#NUMBER#.","order"),
("2","msg__no_electro","Заказ не содержит электронных товаров или ожидает оплаты!","Заказ не содержит электронных товаров или ожидает оплаты!","order"),
("3","msg__electro_download","Скачать электронные товары для заказа №#NUMBER#.","Скачать электронные товары для заказа №#NUMBER#.","order"),
("4","msg__view_status","Посмотреть статус заказа Вы можете в <a href=\"#LINK#\">личном кабинете</a>.","Посмотреть статус заказа Вы можете в <a href=\"#LINK#\">личном кабинете</a>.","order"),
("5","msg__order_not_found","Некорректная ссылка.<br> Заказ не найден.<br>","Некорректная ссылка.<br> Заказ не найден.<br>","order"),
("6","msg__view_order","Следить за статусом заказа Вы можете по ссылке<br><a href=\"#LINK#\">#LINK#</a>.","Следить за статусом заказа Вы можете по ссылке<br><a href=\"#LINK#\">#LINK#</a>.","order"),
("7","msg__order_confirmed","Ваш заказ №#NUMBER# подтвержден и передан на обработку.<br>","Ваш заказ №#NUMBER# подтвержден и передан на обработку.<br>","order"),
("8","msg__order_processing","Заказ уже подтвержден и находится в работе.<br>","Заказ уже подтвержден и находится в работе.<br>","order"),
("9","msg__order_not_confirmed","Некорректная ссылка.<br>Заказ не подтвержден.<br>","Некорректная ссылка.<br>Заказ не подтвержден.<br>","order"),
("10","msg__email_in_use","Пользователь с таким email существует. Пожалуйста, <a href=\"#LINK#\">войдите в систему</a> используя свой электронный адрес и пароль!","Пользователь с таким email существует. Пожалуйста, <a href=\"#LINK#\">войдите в систему</a> используя свой электронный адрес и пароль!","order"),
("11","msg__email_incorrect","E-mail введен некорректно!","E-mail введен некорректно!","order"),
("12","msg__phone_incorrect","Введите верный номер телефона!","Введите верный номер телефона!","order"),
("13","msg__payment_incorrect","Выберите способ оплаты!","Выберите способ оплаты!","order"),
("15","msg__product_ended","Товара #PRODUCT# уже нет в наличии. Для оформления заказа его необходимо удалить из корзины.","Товара #PRODUCT# уже нет в наличии. Для оформления заказа его необходимо удалить из корзины.","product"),
("16","msg__product_ending","Товар #PRODUCT# доступен в количестве #COUNT# шт. Для оформления заказа измените количество в корзине.","Товар #PRODUCT# доступен в количестве #COUNT# шт. Для оформления заказа измените количество в корзине.","product"),
("17","msg__no_compare","Нет товаров для сравнения в этой категории.","Нет товаров для сравнения в этой категории.","product"),
("18","msg__product_nonavaiable1","Товара временно нет на складе!<br/><a rel=\"nofollow\" href=\"#LINK#\">Сообщить когда будет в наличии.</a>","Товара временно нет на складе!<br/><a rel=\"nofollow\" href=\"#LINK#\">Сообщить когда будет в наличии.</a>","product"),
("19","msg__product_nonavaiable2","Здравствуйте, меня интересует товар #PRODUCT# с артикулом #CODE#, но его нет в наличии. Сообщите, пожалуйста, о поступлении этого товара на склад. ","Здравствуйте, меня интересует товар #PRODUCT# с артикулом #CODE#, но его нет в наличии. Сообщите, пожалуйста, о поступлении этого товара на склад. ","product"),
("20","msg__enter_failed","Неправильная пара email-пароль! Авторизоваться не удалось.","Неправильная пара email-пароль! Авторизоваться не удалось.","register"),
("21","msg__enter_captcha_failed","Неправильно введен код с картинки! Авторизоваться не удалось. Количество оставшихся попыток - #COUNT#.","Неправильно введен код с картинки! Авторизоваться не удалось. Количество оставшихся попыток - #COUNT#.","register"),
("22","msg__enter_blocked","В целях безопасности возможность авторизации заблокирована на #MINUTES# мин. Отсчет времени от #TIME#.","В целях безопасности возможность авторизации заблокирована на #MINUTES# мин. Отсчет времени от #TIME#.","register"),
("23","msg__enter_field_missing","Одно из обязательных полей не заполнено!","Одно из обязательных полей не заполнено!","register"),
("24","msg__feedback_sent","Ваше сообщение отправлено!","Ваше сообщение отправлено!","feedback"),
("25","msg__feedback_wrong_email","E-mail не существует!","E-mail не существует!","feedback"),
("26","msg__feedback_no_text","Введите текст сообщения!","Введите текст сообщения!","feedback"),
("27","msg__captcha_incorrect","Текст с картинки введен неверно!","Текст с картинки введен неверно!","feedback"),
("28","msg__reg_success_email","Вы успешно зарегистрировались! Для активации пользователя Вам необходимо перейти по ссылке высланной на Ваш электронный адрес <strong>#EMAIL#</strong>","Вы успешно зарегистрировались! Для активации пользователя Вам необходимо перейти по ссылке высланной на Ваш электронный адрес <strong>#EMAIL#</strong>","register"),
("29","msg__reg_success","Вы успешно зарегистрировались! <a href=\"#LINK#\">Вход в личный кабинет</a></strong>","Вы успешно зарегистрировались! <a href=\"#LINK#\">Вход в личный кабинет</a></strong>","register"),
("30","msg__reg_activated","Ваша учетная запись активирована. Теперь Вы можете <a href=\"#LINK#\">войти в личный кабинет</a> используя логин и пароль заданный при регистрации.","Ваша учетная запись активирована. Теперь Вы можете <a href=\"#LINK#\">войти в личный кабинет</a> используя логин и пароль заданный при регистрации.","register"),
("31","msg__reg_wrong_link","Некорректная ссылка. Повторите активацию!","Некорректная ссылка. Повторите активацию!","register"),
("32","msg__reg_link","Для активации пользователя Вам необходимо перейти по ссылке высланной на Ваш электронный адрес #EMAIL#","Для активации пользователя Вам необходимо перейти по ссылке высланной на Ваш электронный адрес #EMAIL#","register"),
("33","msg__wrong_login","К сожалению, такой логин не найден. Если вы уверены, что данный логин существует, свяжитесь, пожалуйста, с нами.","К сожалению, такой логин не найден. Если вы уверены, что данный логин существует, свяжитесь, пожалуйста, с нами.","register"),
("34","msg__reg_email_in_use","Указанный email уже используется.","Указанный email уже используется.","register"),
("35","msg__reg_short_pass","Пароль менее 5 символов.","Пароль менее 5 символов.","register"),
("36","msg__reg_wrong_pass","Введенные пароли не совпадают.","Введенные пароли не совпадают.","register"),
("37","msg__reg_wrong_email","Неверно заполнено поле email","Неверно заполнено поле email","register"),
("38","msg__forgot_restore","Инструкция по восстановлению пароля была отправлена на <strong>#EMAIL#</strong>.","Инструкция по восстановлению пароля была отправлена на <strong>#EMAIL#</strong>.","register"),
("39","msg__forgot_wrong_link","Некорректная ссылка. Повторите заново запрос восстановления пароля.","Некорректная ссылка. Повторите заново запрос восстановления пароля.","register"),
("40","msg__forgot_success","Пароль изменен! Вы можете войти в личный кабинет по адресу <a href=\"#LINK#\">#LINK#</a>","Пароль изменен! Вы можете войти в личный кабинет по адресу <a href=\"#LINK#\">#LINK#</a>","register"),
("41","msg__pers_saved","Данные успешно сохранены","Данные успешно сохранены","register"),
("42","msg__pers_wrong_pass","Неверный пароль","Неверный пароль","register"),
("43","msg__pers_pass_changed","Пароль изменен","Пароль изменен","register"),
("44","msg__recaptcha_incorrect","reCAPTCHA не пройдена!","reCAPTCHA не пройдена!","feedback"),
("45","msg__enter_recaptcha_failed","reCAPTCHA не пройдена! Авторизоваться не удалось. Количество оставшихся попыток - #COUNT#.","reCAPTCHA не пройдена! Авторизоваться не удалось. Количество оставшихся попыток - #COUNT#.","register"),
("46","msg__status_not_confirmed","не подтвержден","не подтвержден","status"),
("47","msg__status_expects_payment","ожидает оплаты","ожидает оплаты","status"),
("48","msg__status_paid","оплачен","оплачен","status"),
("49","msg__status_in_delivery","в доставке","в доставке","status"),
("50","msg__status_canceled","отменен","отменен","status"),
("51","msg__status_executed","выполнен","выполнен","status"),
("52","msg__status_processing","в обработке","в обработке","status"),
("53","msg__payment_inn","Заполните ИНН","Заполните ИНН","order"),
("54","msg__payment_required","Заполнены не все обязательные поля","Заполнены не все обязательные поля","order"),
("55","msg__storage_non_selected","Склад не выбран!","Склад не выбран!","order"),
("56","msg__pers_data_fail","Не удалось сохранить данные","Не удалось сохранить данные","register"),
("57","msg__reg_phone_in_use","Номер телефона указан неверно или уже используется","Номер телефона указан неверно или уже используется","register"),
("58","msg__reg_wrong_login","Неверно заполнен E-mail или номер телефона","Неверно заполнен E-mail или номер телефона","register"),
("59","msg__pers_phone_add","Номер телефона был успешно добавлен","Номер телефона был успешно добавлен","register"),
("60","msg__pers_phone_confirm","Номер телефона был успешно подтвержден. Теперь Вы можете войти в личный кабинет используя номер телефона и пароль заданный при регистрации.","Номер телефона был успешно подтвержден. Теперь Вы можете войти в личный кабинет используя номер телефона и пароль заданный при регистрации.","register"),
("61","msg__reg_not_sms","Сервис отправки SMS временно не доступен. Зарегистрируйтесь используя email, либо свяжитесь с нами.","Сервис отправки SMS временно не доступен. Зарегистрируйтесь используя E-mail, или свяжитесь с нами.","register"),
("62","msg__reg_sms_resend","Код подтверждения повторно отправлен на номер","Код подтверждения повторно отправлен на номер","register"),
("63","msg__reg_sms_errore","Неверный код подтверждения","Неверный код подтверждения","register"),
("64","msg__reg_not_sms_confirm","Сервис отправки SMS временно не доступен. Повторите попытку позже, либо свяжитесь с нами.","Сервис отправки SMS временно не доступен. Повторите попытку позже, либо свяжитесь с нами.","register"),
("65","msg__reg_wrong_link_sms","Некорректная ссылка. Повторите попытку позже, либо свяжитесь с нами.","Некорректная ссылка. Повторите попытку позже, либо свяжитесь с нами.","register"),
("66","msg__reg_blocked_email","Указанный E-mail запрещён администратором!","Указанный E-mail запрещён администратором!","register"),
("67","msg__products_not_same_storage","Невозможно собрать заказ с одного склада","Невозможно собрать заказ с одного склада","order");
DROP TABLE IF EXISTS `mg_mg-brand`;

CREATE TABLE `mg_mg-brand` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Порядковый номер записи',
  `data_id` int(11) NOT NULL COMMENT 'Номер в таблице характеристик',
  `brand` text NOT NULL COMMENT 'Бренд',
  `url` text NOT NULL COMMENT 'Логотип',
  `img_alt` text NOT NULL COMMENT 'alt',
  `img_title` text NOT NULL COMMENT 'title',
  `desc` text NOT NULL COMMENT 'Описание',
  `short_url` text NOT NULL COMMENT 'Короткая ссылка',
  `full_url` text NOT NULL COMMENT 'Полная ссылка',
  `add_datetime` datetime NOT NULL COMMENT 'Дата добавления',
  `seo_title` text NOT NULL COMMENT '(SEO) Название',
  `seo_keywords` text NOT NULL COMMENT '(SEO) Ключевые слова',
  `seo_desc` text NOT NULL COMMENT '(SEO) Описание',
  `cat_desc_seo` text NOT NULL COMMENT 'Описание для SEO',
  `invisible` int(1) NOT NULL COMMENT 'Видимость',
  `sort` int(11) NOT NULL COMMENT 'Сортировка',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_mg-slider`;

CREATE TABLE `mg_mg-slider` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Порядковый номер слайдера',
  `name_slider` text NOT NULL COMMENT 'Название слайдера',
  `slides` text NOT NULL COMMENT 'Содержимое слайдов',
  `options` text NOT NULL COMMENT 'Настройки сладера',
  `invisible` int(1) NOT NULL DEFAULT '0' COMMENT 'видимость',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_notification`;

CREATE TABLE `mg_notification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `message` longtext NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_order`;

CREATE TABLE `mg_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `owner` int(11) NOT NULL DEFAULT '0',
  `updata_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `add_date` timestamp NULL DEFAULT NULL,
  `close_date` timestamp NULL DEFAULT NULL,
  `pay_date` timestamp NULL DEFAULT NULL,
  `user_email` varchar(191) DEFAULT NULL,
  `contact_email` varchar(249) DEFAULT NULL,
  `phone` varchar(249) DEFAULT NULL,
  `address` text,
  `address_parts` text,
  `summ` varchar(249) DEFAULT NULL COMMENT 'Общая сумма товаров в заказе ',
  `order_content` longtext,
  `delivery_id` int(11) unsigned DEFAULT NULL,
  `delivery_cost` double DEFAULT NULL COMMENT 'Стоимость доставки',
  `delivery_interval` text,
  `delivery_options` text,
  `payment_id` int(11) DEFAULT NULL,
  `paided` int(1) NOT NULL DEFAULT '0',
  `approve_payment` int(1) NOT NULL DEFAULT '0',
  `status_id` int(11) DEFAULT NULL,
  `user_comment` text,
  `comment` text,
  `confirmation` varchar(249) DEFAULT NULL,
  `yur_info` text NOT NULL,
  `name_buyer` text NOT NULL,
  `name_parts` text,
  `date_delivery` text,
  `ip` text NOT NULL,
  `number` varchar(32) DEFAULT NULL,
  `hash` varchar(32) DEFAULT NULL,
  `1c_last_export` timestamp NULL DEFAULT NULL,
  `orders_set` int(11) DEFAULT NULL,
  `storage` text NOT NULL,
  `summ_shop_curr` double DEFAULT NULL,
  `delivery_shop_curr` double DEFAULT NULL,
  `currency_iso` varchar(249) DEFAULT NULL,
  `utm_source` text,
  `utm_medium` text,
  `utm_campaign` text,
  `utm_term` text,
  `utm_content` text,
  `pay_hash` varchar(191) DEFAULT '' COMMENT 'Случайный hash для оплаты заказа по ссылке',
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `user_email` (`user_email`),
  KEY `status_id` (`status_id`),
  KEY `1c_last_export` (`1c_last_export`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_order_comments`;

CREATE TABLE `mg_order_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `text` longtext NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_order_opt_fields`;

CREATE TABLE `mg_order_opt_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(249) NOT NULL,
  `type` varchar(249) NOT NULL,
  `vars` text,
  `sort` int(11) DEFAULT NULL,
  `placeholder` text,
  `droped` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_order_opt_fields_content`;

CREATE TABLE `mg_order_opt_fields_content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `field_id` int(11) NOT NULL DEFAULT '0',
  `order_id` int(11) NOT NULL DEFAULT '0',
  `value` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_page`;

CREATE TABLE `mg_page` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_url` varchar(249) NOT NULL,
  `parent` int(11) NOT NULL,
  `title` varchar(249) NOT NULL,
  `url` varchar(249) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `html_content` longtext NOT NULL,
  `meta_title` text,
  `meta_keywords` text,
  `meta_desc` text,
  `sort` int(11) DEFAULT NULL,
  `print_in_menu` tinyint(4) NOT NULL DEFAULT '0',
  `invisible` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'Не выводить в меню',
  `without_style` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'Выводить без стилей шаблона',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;


INSERT INTO `mg_page` VALUES
("1","","0","Главная","index","<h3 class=\"c-title\">О магазине</h3><div><p>Мы стабильная и надежная компания, с каждым днем наращиваем свой потенциал. Имеем огромный опыт в сфере корпоративных продаж, наши менеджеры готовы предложить Вам высокий уровень сервиса, грамотную консультацию, выгодные условия работы и широкий спектр цветовых решений. В число наших постоянных клиентов входят крупные компании.</p><p>Наши товары производятся только из самых качественных материалов!</p><p>Отдел корпоративных продаж готов предложить Вам персонального менеджера, грамотную консультацию, доставку на следующий день после оплаты, сертификаты на всю продукцию, индивидуальный метод работы.</p><p>Отдельным направлением является работа с частными лицами с оперативной доставкой, низкими ценами и высоким качеством обслуживания.</p><p>Главное для нас — своевременно удовлетворять потребности наших клиентов всеми силами и доступными нам средствами. Работая с нами, Вы гарантированно приобретаете только оригинальный товар подлинного качества.</p><p>Мы работаем по всем видам оплат. Только приобретая товар у официального дилера, Вы застрахованы от подделок. Будем рады нашему долгосрочному сотрудничеству.</p><p>** Информация представленная на сайте является демонстрационной для ознакомления с Moguta.CMS. <a data-cke-saved-href=\"https://moguta.ru/\" href=\"https://moguta.ru/\">Moguta.CMS - простая cms для интернет-магазина.</a></p></div>","Главная","Главная","","5","0","1","0"),
("2","","0","Доставка и оплата","dostavka","<div><h1 class=\"new-products-title\">Доставка и оплата</h1><p><strong>Курьером по Москве</strong></p><p>Доставка осуществляется по Москве бесплатно, если сумма заказа составляет свыше 3000 руб.  Стоимость доставки меньше чем на сумму 3000 руб. Составляет 700 руб. Данный способ доставки дает вам возможность получить товар прямо в руки, курьером по Москве. Срок доставки до 24 часов с момента заказа товара в интернет - магазине.</p><p><strong>Доставка по России</strong></p><p>Доставка по России осуществляется с помощью почтово – курьерских служб во все регионы России. Стоимость доставки зависит от региона и параметров товара. Рассчитать стоимость доставки Вы сможете на официальном сайте почтово – курьерской службы Почта-России и т.д. Сроки доставки составляет до 3-х дней с момента заказа товара в интернет – магазине.</p><h2>Способы оплаты:</h2><p><strong>Наличными: </strong>Оплатить заказ товара Вы сможете непосредственно курьеру в руки при получение товара. </p><p><strong>Наложенным платежом:</strong> Оплатить заказ товара Вы сможете наложенным платежом при получение товара на складе. С данным видом оплаты Вы оплачиваете комиссию за пересылку денежных средств. </p><p><strong>Электронными деньгами:</strong> VISA, Master Card, Yandex.Деньги, Webmoney, Qiwi и др.</p></div><div></div><div></div><div></div>","Доставка","Доставка","Доставка осуществляется по Москве бесплатно, если сумма заказа составляет свыше 3000 руб.  Стоимость доставки меньше чем на сумму 3000 руб. Составляет 700 руб.","2","1","0","0"),
("3","","0","Обратная связь","feedback","<p>Свяжитесь с нами, посредством формы обратной связи представленной ниже. Вы можете задать любой вопрос, и после отправки сообщения наш менеджер свяжется с вами.</p>","Обратная связь","Обратная связь","Свяжитесь с нами, по средствам формы обратной связи представленной ниже. Вы можете задать любой вопрос, и после отправки сообщения наш менеджер свяжется с вами.","3","1","0","0"),
("4","","0","Контакты","contacts","<h1 class=\"new-products-title\">Контакты</h1><p><strong>Наш адрес </strong>г. Санкт-Петербург Невский проспект, дом 3</p><p><strong>Телефон отдела продаж </strong>8 (555) 555-55-55 </p><p>Пн-Пт 9.00 - 19.00</p><p>Электронный ящик: <span style=\"line-height: 1.6em;\">info@sale.ru</span></p><p><strong>Мы в социальных сетях</strong></p><p></p><p style=\"line-height: 20.7999992370605px;\"><strong>Мы в youtoube</strong></p><p style=\"line-height: 20.7999992370605px;\"></p>","Контакты","Контакты","Мы в социальных сетях  Мы в youtoube ","4","1","0","0"),
("5","","0","Каталог","catalog","В каталоге нашего магазина вы найдете не только качественные и полезные вещи, но и абсолютно уникальные новинки из мира цифровой индустрии.","Каталог","Каталог","","1","1","0","0"),
("6","","0","Новинки","group?type=latest","","Новинки","Новинки","","6","1","1","0"),
("7","","0","Акции","group?type=sale","","Акции","Акции","","7","1","1","0"),
("8","","0","Хиты продаж","group?type=recommend","","Хиты продаж","Хиты продаж","","8","1","1","0");
DROP TABLE IF EXISTS `mg_payment`;

CREATE TABLE `mg_payment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(191) NOT NULL DEFAULT '',
  `name` varchar(1024) NOT NULL,
  `public_name` varchar(1023) DEFAULT NULL,
  `activity` int(1) NOT NULL DEFAULT '0',
  `paramArray` text,
  `urlArray` varchar(1023) DEFAULT NULL,
  `rate` double NOT NULL DEFAULT '0',
  `sort` int(11) DEFAULT NULL,
  `permission` varchar(5) NOT NULL DEFAULT 'fiz',
  `plugin` varchar(255) DEFAULT NULL,
  `icon` varchar(511) DEFAULT NULL,
  `logs` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT 'Флаг, обозначающий поддерживает оплата логирование или нет',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1004 DEFAULT CHARSET=utf8mb4;


INSERT INTO `mg_payment` VALUES
("1","old#1","WebMoney","","1","{\"Номер кошелька\":\"\",\"Секретный ключ\":\"\",\"Тестовый режим\":\"ZmFsc2VoWSo2bms3ISEjMnFq\",\"Метод шифрования\":\"bWQ1aFkqNm5rNyEhIzJxag==\"}","{\"result URL:\":\"/payment?id=1&pay=result\",\"success URL:\":\"/payment?id=1&pay=success\",\"fail URL:\":\"/payment?id=1&pay=fail\"}","0","1","fiz","","","0"),
("3","old#3","Наложенный платеж","","0","{\"Примечание\":\"\"}","","0","3","fiz","","","0"),
("4","old#4","Наличные (курьеру)","","0","{\"Примечание\":\"\"}","","0","4","fiz","","","0"),
("5","old#5","ROBOKASSA","","0","{\"Логин\":\"\",\"пароль 1\":\"\",\"пароль 2\":\"\",\"Метод шифрования\":\"bWQ1aFkqNm5rNyEhIzJxag==\",\"Использовать онлайн кассу\":\"ZmFsc2VoWSo2bms3ISEjMnFq\",\"НДС, включенный в цену\":\"MjAlaFkqNm5rNyEhIzJxag==\",\"Обработка смены статуса при переходе на successUrl\":\"ZmFsc2VoWSo2bms3ISEjMnFq\"}","{\"result URL:\":\"/payment?id=5&pay=result\",\"success URL:\":\"/payment?id=5&pay=success\",\"fail URL:\":\"/payment?id=5&pay=fail\"}","0","5","fiz","","","0"),
("7","old#7","Оплата по реквизитам","","0","{\"Юридическое лицо\":\"\", \"ИНН\":\"\",\"КПП\":\"\", \"Адрес\":\"\", \"Банк получателя\":\"\", \"БИК\":\"\",\"Расчетный счет\":\"\",\"Кор. счет\":\"\"}","","0","7","yur","","","0"),
("8","old#8","Интеркасса","","0","{\"Идентификатор кассы\":\"\",\"Секретный ключ\":\"\",\"Тестовый режим\":\"ZmFsc2VoWSo2bms3ISEjMnFq\",\"Метод шифрования\":\"bWQ1aFkqNm5rNyEhIzJxag==\"}","{\"result URL:\":\"/payment?id=8&pay=result\",\"success URL:\":\"/payment?id=8&pay=success\",\"fail URL:\":\"/payment?id=8&pay=fail\"}","0","8","fiz","","","0"),
("9","old#9","PayAnyWay","","0","{\"Номер расширенного счета\":\"\",\"Код проверки целостности данных\":\"\",\"Тестовый режим\":\"ZmFsc2VoWSo2bms3ISEjMnFq\",\"Метод шифрования\":\"bWQ1aFkqNm5rNyEhIzJxag==\",\"НДС на товары\":\"MTEwNWhZKjZuazchISMycWo=\"}","{\"result URL:\":\"/payment?id=9&pay=result\",\"success URL:\":\"/payment?id=9&pay=success\",\"fail URL:\":\"/payment?id=9&pay=fail\"}","0","9","fiz","","","0"),
("10","old#10","PayMaster","","0","{\"ID магазина\":\"\",\"Секретный ключ\":\"\",\"Метод шифрования\":\"bWQ1aFkqNm5rNyEhIzJxag==\",\"Использовать онлайн кассу\":\"ZmFsc2VoWSo2bms3ISEjMnFq\",\"НДС, включенный в цену\":\"MjAlaFkqNm5rNyEhIzJxag==\"}","{\"result URL:\":\"/payment?id=10&pay=result\",\"success URL:\":\"/payment?id=10&pay=success\",\"fail URL:\":\"/payment?id=10&pay=fail\"}","0","10","fiz","","","0"),
("11","old#11","AlfaBank","","1","{\"Логин\":\"\",\"Пароль\":\"\",\"Адрес сервера\":\"\",\"Метод шифрования\":\"bWQ1aFkqNm5rNyEhIzJxag==\", \"Код валюты\":\"\", \"НДС на товары\":\"MGhZKjZuazchISMycWo=\", \"Использовать онлайн кассу\":\"ZmFsc2VoWSo2bms3ISEjMnFq\"}","{\"result URL:\":\"/payment?id=11&pay=result\",\"success URL:\":\"/payment?id=11&pay=success\",\"fail URL:\":\"/payment?id=11&pay=fail\"}","0","11","fiz","","","0"),
("14","old#14","Ю.Касса (HTTP)","","0","{\"Ссылка для отправки данных\":\"\",\"Идентификатор магазина\":\"\",\"Идентификатор витрины\":\"\",\"shopPassword\":\"\",\"Метод шифрования\":\"bWQ1aFkqNm5rNyEhIzJxag==\",\"Использовать онлайн кассу\":\"ZmFsc2VoWSo2bms3ISEjMnFq\",\"НДС, включенный в цену\":\"MjAlaFkqNm5rNyEhIzJxag==\"}","{\"result URL:\":\"/payment?id=14&pay=result\",\"success URL:\":\"/payment?id=14&pay=success\",\"fail URL:\":\"/payment?id=14&pay=fail\"}","0","12","fiz","","","0"),
("15","old#15","Приват24","","0","{\"ID мерчанта\":\"\",\"Пароль марчанта\":\"\"}","","0","13","fiz","","","0"),
("16","old#16","LiqPay","","0","{\"Публичный ключ\":\"\",\"Приватный ключ\":\"\",\"Тестовый режим\":\"\"}","","0","14","fiz","","","0"),
("17","old#17","Сбербанк","","1","{\"API Логин\":\"\",\"Пароль\":\"\",\"Адрес сервера\":\"\",\"Использовать онлайн кассу\":\"ZmFsc2VoWSo2bms3ISEjMnFq\",\"Система налогообложения\":\"MGhZKjZuazchISMycWo=\",\"НДС на товары\":\"M2hZKjZuazchISMycWo=\",\"НДС на доставку\":\"M2hZKjZuazchISMycWo=\",\"Код валюты\":\"\"}","{\"callback URL:\":\"/payment?id=17&pay=result\"}","0","15","fiz","","","0"),
("18","old#18","Тинькофф","","1","{\"Ключ терминала\":\"\",\"Секретный ключ\":\"\",\"Адрес сервера\":\"\",\"Использовать онлайн кассу\":\"ZmFsc2VoWSo2bms3ISEjMnFq\",\"Система налогообложения\":\"b3NuaFkqNm5rNyEhIzJxag==\",\"НДС на товары\":\"dmF0MjBoWSo2bms3ISEjMnFq\",\"НДС на доставку\":\"dmF0MjBoWSo2bms3ISEjMnFq\",\"Email продавца\":\"\"}","{\"result URL:\":\"/payment?id=18&pay=result\"}","0","16","fiz","","","0"),
("19","old#19","PayPal","","0","{\"Токен идентичности\":\"\",\"Email продавца\":\"\",\"Тестовый режим\":\"dHJ1ZWhZKjZuazchISMycWo=\"}","{\"result URL:\":\"/payment?id=19&pay=result\"}","0","19","fiz","","","0"),
("20","old#20","Comepay: интернет-эквайринг и прием платежей","","0","{\"Идентификатор магазина\":\"\",\"Номер магазина\":\"\",\"Пароль магазина\":\"\",\"Callback Password\":\"\",\"Время жизни счета в часах\":\"\",\"Тестовый режим\":\"ZmFsc2VoWSo2bms3ISEjMnFq\",\"Comepay URL\":\"aHR0cHM6Ly9hY3Rpb25zaG9wLmNvbWVwYXkucnVoWSo2bms3ISEjMnFq\",\"Comepay test URL\":\"aHR0cHM6Ly9tb25leXRlc3QuY29tZXBheS5ydTo0NDloWSo2bms3ISEjMnFq\",\"Разрешить печать чеков в ККТ\":\"ZmFsc2VoWSo2bms3ISEjMnFq\",\"НДС на товары\":\"M2hZKjZuazchISMycWo=\",\"НДС на доставку\":\"M2hZKjZuazchISMycWo=\",\"Признак способа расчёта\":\"NGhZKjZuazchISMycWo=\"}","{\"result URL:\":\"/payment?id=20&pay=result\",\"success URL:\":\"/payment?id=20&pay=success\",\"fail URL:\":\"/payment?id=20&pay=fail\"}","0","20","fiz","","","0"),
("21","old#21","Онлайн оплата (payKeeper)","","0","{\"Язык страницы оплаты\":\"\",\"ID Магазина\":\"=\",\"Секретный ключ\":\"=\",\"Система налогообложения\":\"bm9uZWhZKjZuazchISMycWo=\"}","{\"result URL:\":\"/payment?id=21&pay=result\",\"success URL:\":\"/payment?id=21&pay=success\",\"fail URL:\":\"/payment?id=21&pay=fail\"}","0","21","all","","","0"),
("22","old#22","CloudPayments","","0","{\"Public ID\":\"\",\"Секретный ключ\":\"\",\"Схема проведения платежа\":\"Y2hhcmdlaFkqNm5rNyEhIzJxag==\",\"Дизайн виджета\":\"Y2xhc3NpY2hZKjZuazchISMycWo=\",\"Язык виджета\":\"cnUtUlVoWSo2bms3ISEjMnFq\",\"Использовать онлайн кассу\":\"\",\"Инн\":\"\",\"Система налогообложения\":\"dHNfMGhZKjZuazchISMycWo=\",\"Ставка НДС\":\"dmF0XzIwaFkqNm5rNyEhIzJxag==\",\"Ставка НДС для доставки\":\"dmF0XzIwaFkqNm5rNyEhIzJxag==\",\"Способ расчета\":\"MWhZKjZuazchISMycWo=\",\"Предмет расчета\":\"MWhZKjZuazchISMycWo=\",\"Статус заказа для печати второго чека\":\"M2hZKjZuazchISMycWo=\"}","{\"Check URL:\":\"/payment?id=22&pay=result&action=check\",\"Pay URL:\":\"/payment?id=22&pay=result&action=pay\",\"Confirm URL:\":\"/payment?id=22&pay=result&action=confirm\",\"Fail URL:\":\"/payment?id=22&pay=result&action=fail\",\"Refund URL:\":\"/payment?id=22&pay=result&action=refund\",\"Cancel URL:\":\"/payment?id=22&pay=result&action=cancel\"}","0","22","fiz","","","0"),
("23","old#23","Заплатить по частям от Ю.Кассы","","0","","","0","23","fiz","","","0"),
("24","old#24","Ю.Касса (API)","","1","{\"shopid\":\"\",\"api_key\":\"\",\"Использовать онлайн кассу\":\"ZmFsc2VoWSo2bms3ISEjMnFq\",\"НДС, включенный в цену\":\"MjAlaFkqNm5rNyEhIzJxag==\"}","{\"Check URL:\":\"/payment?id=24\"}","0","24","fiz","","","0"),
("25","old#25","Apple Pay от Ю.Кассы","","0","{\"MerchantIdentifier\":\"\",\"MerchantName\":\"\",\"Password\":\"\",\"CertPath\":\"\",\"KeyPath\":\"\"}","","0","25","fiz","","","0"),
("26","old#26","FREE-KASSA","","0","{\"Язык страницы оплаты\":\"\", \"ID Магазина\":\"\", \"Секретный ключ1\":\"\", \"Секретный ключ2\":\"\", \"Валюта\":\"\"}","{\"URL оповещения:\":\"/payment?id=26&pay=result\",\"URL возврата в случае успеха:\":\"/payment?id=26&pay=success\",\"URL возврата в случае неудачи:\":\"/payment?id=26&pay=fail\"}","0","26","fiz","","","0"),
("27","old#27","Мегакасса","","0","{\"ID магазина\":\"\", \"Секретный ключ\":\"\"}","{\"result URL:\":\"/payment?id=27&pay=result\",\"success URL:\":\"/payment?id=27&pay=success\",\"fail URL:\":\"/payment?id=27&pay=fail\"}","0","27","fiz","","","0"),
("28","old#28","Qiwi (API)","","1","{\"Публичный ключ\":\"\", \"Секретный ключ\":\"\"}","{\"result URL:\":\"/payment?id=28&pay=result\"}","0","28","fiz","","","0"),
("29","old#29","intellectmoney","","0","{\"ID магазина\":\"\",\"Секретный ключ\":\"\",\"ИНН\":\"\",\"Использовать онлайн кассу\":\"ZmFsc2VoWSo2bms3ISEjMnFq\",\"Тестовый режим\":\"\",\"НДС на товары\":\"MmhZKjZuazchISMycWo=\",\"НДС на доставку\":\"NmhZKjZuazchISMycWo=\"}","{\"result URL:\":\"/payment?id=29&pay=result\"}","0","29","fiz","","","0"),
("30","old#30","beGateway","","0","{\"Shop ID\":\"\",\"Shop Secret Key\":\"\",\"Shop Public Key\":\"\",\"Payment Domain\":\"\",\"Тестовый режим\":\"dHJ1ZWhZKjZuazchISMycWo=\"}","{\"result URL:\":\"/payment?id=30&pay=result\",\"success URL:\":\"/payment?id=30&pay=success\",\"fail URL:\":\"/payment?id=30&pay=fail\"}","0","30","fiz","","","0"),
("31","old#31","Оплата по QR","","0","","","0","31","fiz","","","0"),
("1001","custom#1001","Наложенный платеж","Наложенный платеж","1","[{\"name\":\"description\",\"title\":\"Примечание\",\"type\":\"text\",\"value\":\"\"}]","","0","1001","fiz","","","0"),
("1002","custom#1002","Наличные (курьеру)","Наличные (курьеру)","1","[{\"name\":\"description\",\"title\":\"Примечание\",\"type\":\"text\",\"value\":\"\"}]","","0","1002","fiz","","","0"),
("1003","custom#1003","Оплата через менеджера","Оплата через менеджера","1","[{\"name\":\"description\",\"title\":\"Примечание\",\"type\":\"text\",\"value\":\"\"}]","","0","1003","yur","","","0");
DROP TABLE IF EXISTS `mg_plugins`;

CREATE TABLE `mg_plugins` (
  `folderName` varchar(249) NOT NULL,
  `active` tinyint(1) NOT NULL,
  `template` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


INSERT INTO `mg_plugins` VALUES
("mg-brand","0","moguta"),
("back-ring","0","moguta"),
("breadcrumbs","1","moguta"),
("comments","1","moguta"),
("daily-product","0","moguta"),
("in-cart","1","moguta"),
("mg-slider","0","moguta"),
("rating","1","moguta");
DROP TABLE IF EXISTS `mg_product`;

CREATE TABLE `mg_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sort` int(11) DEFAULT NULL,
  `cat_id` int(11) NOT NULL,
  `title` varchar(249) NOT NULL,
  `description` longtext,
  `price` double NOT NULL,
  `url` varchar(191) NOT NULL,
  `image_url` text,
  `code` varchar(191) NOT NULL,
  `count` float NOT NULL DEFAULT '0',
  `activity` tinyint(1) NOT NULL,
  `meta_title` text,
  `meta_keywords` text,
  `meta_desc` text,
  `old_price` varchar(249) DEFAULT NULL,
  `recommend` tinyint(4) NOT NULL DEFAULT '0',
  `new` tinyint(4) NOT NULL DEFAULT '0',
  `related` text,
  `inside_cat` text,
  `1c_id` varchar(191) NOT NULL DEFAULT '',
  `weight` double DEFAULT NULL,
  `link_electro` varchar(1024) DEFAULT NULL,
  `currency_iso` varchar(249) DEFAULT NULL,
  `price_course` double DEFAULT NULL,
  `image_title` text,
  `image_alt` text,
  `yml_sales_notes` text,
  `count_buy` int(11) NOT NULL DEFAULT '0',
  `system_set` int(11) DEFAULT NULL,
  `related_cat` text,
  `short_description` longtext,
  `last_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `unit` varchar(249) DEFAULT NULL,
  `weight_unit` varchar(10) DEFAULT NULL,
  `multiplicity` float NOT NULL DEFAULT '1',
  `storage_count` float DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `1c_id` (`1c_id`),
  KEY `id` (`id`),
  KEY `cat_id` (`cat_id`),
  KEY `url` (`url`),
  KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_product_on_storage`;

CREATE TABLE `mg_product_on_storage` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `storage` varchar(191) NOT NULL,
  `product_id` int(11) NOT NULL,
  `variant_id` int(11) NOT NULL,
  `count` float NOT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `variant_id` (`variant_id`),
  KEY `storage` (`storage`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_product_opt_fields`;

CREATE TABLE `mg_product_opt_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text,
  `is_price` tinyint(1) DEFAULT '0',
  `sort` int(11) DEFAULT NULL,
  `active` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_product_rating`;

CREATE TABLE `mg_product_rating` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Порядковый номер записи',
  `id_product` int(11) NOT NULL COMMENT 'ID товара',
  `rating` double NOT NULL COMMENT 'Оценка',
  `count` int(11) NOT NULL COMMENT 'Количество голосов',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_product_user_property`;

CREATE TABLE `mg_product_user_property` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `property_id` int(11) NOT NULL,
  `value` text NOT NULL,
  `product_margin` text NOT NULL COMMENT 'наценка продукта',
  `type_view` enum('checkbox','select','radiobutton','') NOT NULL DEFAULT 'select',
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `property_id` (`property_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Таблица пользовательских свойств продуктов';


DROP TABLE IF EXISTS `mg_product_user_property_data`;

CREATE TABLE `mg_product_user_property_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `prop_id` int(11) NOT NULL,
  `prop_data_id` int(11) NOT NULL DEFAULT '0',
  `product_id` int(11) NOT NULL,
  `name` text,
  `margin` text,
  `type_view` text CHARACTER SET utf8 NOT NULL,
  `active` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `prop_id` (`prop_id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_product_variant`;

CREATE TABLE `mg_product_variant` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `title_variant` varchar(249) NOT NULL,
  `image` varchar(249) DEFAULT NULL,
  `sort` int(11) DEFAULT NULL,
  `price` double NOT NULL,
  `old_price` varchar(249) NOT NULL,
  `count` float NOT NULL,
  `code` varchar(249) DEFAULT NULL,
  `activity` tinyint(1) NOT NULL,
  `weight` double NOT NULL,
  `currency_iso` varchar(249) DEFAULT NULL,
  `price_course` double DEFAULT NULL,
  `1c_id` varchar(249) DEFAULT NULL,
  `color` varchar(249) NOT NULL,
  `size` varchar(249) NOT NULL,
  `last_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_property`;

CREATE TABLE `mg_property` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `type` varchar(249) NOT NULL,
  `default` text,
  `data` text,
  `all_category` tinyint(1) DEFAULT NULL,
  `activity` int(1) NOT NULL DEFAULT '0',
  `sort` int(11) DEFAULT NULL,
  `filter` tinyint(1) NOT NULL DEFAULT '0',
  `description` text,
  `type_filter` varchar(32) DEFAULT NULL,
  `1c_id` varchar(191) DEFAULT NULL,
  `plugin` varchar(249) DEFAULT NULL,
  `unit` varchar(32) DEFAULT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `name` (`name`),
  KEY `1c_id` (`1c_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_property_data`;

CREATE TABLE `mg_property_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `prop_id` int(11) NOT NULL,
  `name` varchar(249) NOT NULL,
  `margin` text NOT NULL,
  `sort` int(11) NOT NULL DEFAULT '1',
  `color` varchar(45) NOT NULL,
  `img` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `name` (`name`),
  KEY `prop_id` (`prop_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_property_group`;

CREATE TABLE `mg_property_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(249) NOT NULL,
  `sort` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_sessions`;

CREATE TABLE `mg_sessions` (
  `session_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `session_expires` int(11) unsigned NOT NULL DEFAULT '0',
  `session_data` longtext,
  PRIMARY KEY (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_site-block-editor`;

CREATE TABLE `mg_site-block-editor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `comment` text NOT NULL,
  `type` varchar(249) NOT NULL,
  `content` text NOT NULL,
  `width` text NOT NULL,
  `height` text NOT NULL,
  `alt` text NOT NULL,
  `title` text NOT NULL,
  `href` text NOT NULL,
  `class` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_trigger-guarantee`;

CREATE TABLE `mg_trigger-guarantee` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Порядковый номер',
  `title` text NOT NULL COMMENT 'Загаловок',
  `settings` text NOT NULL COMMENT 'Настройки',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_trigger-guarantee-elements`;

CREATE TABLE `mg_trigger-guarantee-elements` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Порядковый номер',
  `parent` int(11) NOT NULL COMMENT 'id блока',
  `text` text NOT NULL COMMENT 'Текст триггера',
  `icon` text NOT NULL COMMENT 'Иконка или url картинки',
  `sort` int(11) NOT NULL COMMENT 'Сортировка',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_url_canonical`;

CREATE TABLE `mg_url_canonical` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url_page` text NOT NULL,
  `url_canonical` text NOT NULL,
  `activity` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_url_redirect`;

CREATE TABLE `mg_url_redirect` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url_old` text NOT NULL,
  `url_new` text NOT NULL,
  `code` int(3) NOT NULL,
  `activity` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_url_rewrite`;

CREATE TABLE `mg_url_rewrite` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` text NOT NULL,
  `short_url` varchar(249) NOT NULL,
  `titeCategory` varchar(249) DEFAULT NULL,
  `cat_desc` longtext NOT NULL,
  `meta_title` text NOT NULL,
  `meta_keywords` text NOT NULL,
  `meta_desc` text NOT NULL,
  `activity` tinyint(1) NOT NULL DEFAULT '1',
  `cat_desc_seo` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_user`;

CREATE TABLE `mg_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `owner` int(11) NOT NULL DEFAULT '0',
  `email` varchar(191) DEFAULT NULL,
  `pass` varchar(249) DEFAULT NULL,
  `role` int(11) DEFAULT NULL,
  `name` varchar(249) DEFAULT NULL,
  `sname` varchar(249) DEFAULT NULL,
  `pname` varchar(249) DEFAULT NULL,
  `address` text,
  `address_index` text,
  `address_country` text,
  `address_region` text,
  `address_city` text,
  `address_street` text,
  `address_house` text,
  `address_flat` text,
  `phone` varchar(249) DEFAULT NULL,
  `last_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `date_add` timestamp NULL DEFAULT NULL,
  `blocked` int(1) NOT NULL DEFAULT '0',
  `restore` varchar(249) DEFAULT NULL,
  `activity` int(1) DEFAULT '0',
  `inn` text,
  `kpp` text,
  `nameyur` text,
  `adress` text,
  `bank` text,
  `bik` text,
  `ks` text,
  `rs` text,
  `birthday` text,
  `ip` text,
  `op` text COMMENT 'Дополнительные поля',
  `fails` tinytext,
  `login_email` varchar(191) DEFAULT NULL,
  `login_phone` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `login_email_2` (`login_email`),
  KEY `email` (`email`),
  KEY `login_email` (`login_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;


INSERT INTO `mg_user` VALUES
("1","0","tech@belka.one","$2y$10$c9aUxt.lCYlEqZ4nDi.RTe7PA/CAYSkcfzy6VVsIVXf6.GEorX5gK","1","Администратор","","","","","","","","","","","+7 (111) 111 11-11","2024-10-26 19:24:19","2024-10-26 19:24:19","0","","1","","","","","","","","","","","","","tech@belka.one","");
DROP TABLE IF EXISTS `mg_user_group`;

CREATE TABLE `mg_user_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `can_drop` tinyint(1) NOT NULL DEFAULT '1',
  `name` varchar(249) NOT NULL DEFAULT '0',
  `admin_zone` tinyint(1) NOT NULL DEFAULT '0',
  `product` tinyint(1) NOT NULL DEFAULT '0',
  `page` tinyint(1) NOT NULL DEFAULT '0',
  `category` tinyint(1) NOT NULL DEFAULT '0',
  `order` tinyint(1) DEFAULT '0',
  `user` tinyint(1) NOT NULL DEFAULT '0',
  `plugin` tinyint(1) NOT NULL DEFAULT '0',
  `setting` tinyint(1) NOT NULL DEFAULT '0',
  `wholesales` tinyint(1) NOT NULL DEFAULT '0',
  `order_status` text COMMENT 'доступные статусы заказов',
  `ignore_owners` tinyint(4) DEFAULT '0' COMMENT 'игнорировать ответственных',
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;


INSERT INTO `mg_user_group` VALUES
("-1","0","Гость (Не авторизован)","0","0","0","0","0","0","0","0","0","","0"),
("1","0","Администратор","1","2","2","2","2","2","2","2","1","","0"),
("2","0","Пользователь","0","0","0","0","0","0","0","0","0","","0"),
("3","0","Менеджер","1","2","0","1","2","0","2","0","0","","0"),
("4","0","Модератор","1","1","2","0","0","0","2","0","0","","0");
DROP TABLE IF EXISTS `mg_user_logins`;

CREATE TABLE `mg_user_logins` (
  `created_at` bigint(20) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `access` tinytext,
  `last_used` int(11) DEFAULT NULL,
  `fails` tinytext,
  UNIQUE KEY `created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


INSERT INTO `mg_user_logins` VALUES
("17299598672767","1","$2y$10$R/J2aHQ7KEAhYs/2FHGmRebNhb38WeHEQU8pBxnRc87XWQF2JV54.","1729959867","");
DROP TABLE IF EXISTS `mg_user_opt_fields`;

CREATE TABLE `mg_user_opt_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(249) NOT NULL,
  `type` varchar(249) NOT NULL,
  `vars` text,
  `sort` int(11) DEFAULT NULL,
  `placeholder` text,
  `active` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_user_opt_fields_content`;

CREATE TABLE `mg_user_opt_fields_content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `field_id` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  `value` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_vk-export`;

CREATE TABLE `mg_vk-export` (
  `moguta_id` int(11) NOT NULL,
  `vk_id` varchar(249) NOT NULL,
  `moguta_img` varchar(249) NOT NULL,
  `vk_img` varchar(249) NOT NULL,
  PRIMARY KEY (`moguta_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_wholesales_sys`;

CREATE TABLE `mg_wholesales_sys` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `variant_id` int(11) NOT NULL,
  `count` float NOT NULL,
  `price` double NOT NULL DEFAULT '0',
  `group` int(11) DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `variant_id` (`variant_id`),
  KEY `count` (`count`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_write_lock`;

CREATE TABLE `mg_write_lock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `table` varchar(249) NOT NULL,
  `entity_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `time_block` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_yandexmarket`;

CREATE TABLE `mg_yandexmarket` (
  `name` varchar(191) NOT NULL,
  `settings` longtext NOT NULL,
  `edited` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

