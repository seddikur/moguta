<p style="font-size:12px;line-height:16px;margin:0;">
  Ваш заказ <b>№<?php echo $data['orderNumber'] ?></b>
  содержит электронные товары, которые можно скачать по следующей ссылке:
    <br/> <a href="<?php echo $data['getElectro'];?>"><?php echo $data['getElectro'];?></a>
</p>
  