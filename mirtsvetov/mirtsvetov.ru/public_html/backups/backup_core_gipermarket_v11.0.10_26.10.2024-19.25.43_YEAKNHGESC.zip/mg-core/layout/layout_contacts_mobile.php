<div class="mg-contacts-block mobile">
  <div class="address">
    <span>Адрес:</span>
    <h2><?php echo MG::getSetting('shopAddress') ?></h2>
  </div>
  <div class="phone">
    <span>Телефон:</span>
    <h2><?php echo MG::getSetting('shopPhone') ?></h2>
  </div>
</div>