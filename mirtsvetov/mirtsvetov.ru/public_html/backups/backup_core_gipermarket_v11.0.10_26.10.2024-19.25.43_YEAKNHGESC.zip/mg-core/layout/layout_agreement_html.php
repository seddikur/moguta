<label class="agreement-container">
	<input class="agreement-data-checkbox-<?php echo $data['button'] ;?>" type="checkbox"> 
	<span><?php echo $data['text'] ;?>
		<a role="button" href="javascript:void(0);" class="show-more-agreement-data"><?php echo $data['textLink'] ;?></a>
	</span>
</label>
<br>