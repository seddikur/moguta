$(document).ready(function() {
  $('.mg-recent-products .recent-products-slider').bxSlider({
    minSlides: 3,
    maxSlides: 3,
    slideWidth: 200,
    slideMargin: 15,
    moveSlides: 1,
    pager: false,
    auto: false,
    pause: 6000,
    useCSS: false
  });
});