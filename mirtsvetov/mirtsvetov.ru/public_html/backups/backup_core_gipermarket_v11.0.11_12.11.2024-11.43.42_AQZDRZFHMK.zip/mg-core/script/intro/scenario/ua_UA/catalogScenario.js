/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
var catalogScenario = {
    hits:[
        {
            selector: '.button.success.tip.add-new-button.tooltip--small.tooltip--center',
            message: 'Додати товар',
        },
        {
            selector: 'button.button.secondary.tip.import-csv.tooltip--center',
            message: 'Вивантаження товарів в CSV'
        }
    ] 
}


