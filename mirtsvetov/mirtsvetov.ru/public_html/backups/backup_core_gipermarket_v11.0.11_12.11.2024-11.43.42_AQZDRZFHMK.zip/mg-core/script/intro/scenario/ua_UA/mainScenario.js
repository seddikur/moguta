/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
var allHits ={
    globalHites: [
        {
           selector: '[data-section="orders"]',
           message: 'Підказки для замовлень',
           position: 'top'
        },
        {
            selector: '[data-section="users"]',
            message: 'Підказки для користувачів',
            position: 'bottom'
        },
        {
            selector: '[data-section="catalog"]',
            message: 'Ваші товари',
            position: 'bottom'
        }
    ]
    
}