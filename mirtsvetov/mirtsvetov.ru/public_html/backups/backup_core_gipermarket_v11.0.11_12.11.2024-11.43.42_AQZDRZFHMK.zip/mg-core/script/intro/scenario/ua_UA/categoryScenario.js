/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
var categoryScenario = {
    hits:[
        {
            selector: 'button.button.success.tip.add-new-button.tooltip--center',
            message: 'Створити нову категорію'
        },
        {
            selector: '.button.secondary.tip.sort-all-cat.tooltip--small.tooltip--center',
            message: 'Сортування категорій',
            position: 'bottom'
        }
    ] 
}

