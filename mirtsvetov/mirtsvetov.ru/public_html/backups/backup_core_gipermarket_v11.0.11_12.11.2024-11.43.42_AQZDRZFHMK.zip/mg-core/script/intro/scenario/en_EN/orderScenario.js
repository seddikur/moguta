/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

var orderScenario = {
    hits:[
        {
            selector: '.button.mg-panel-toggle.show-filters.tooltip--small.tooltip--center',
            message: 'Order Filter',
            position: 'bottom'
        },
        {
            selector: '.button.success.add-new-button.tooltip--small.tooltip--center',
            message: 'Create order',
            position: 'top'
        }
    ] 
}
