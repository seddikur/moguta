/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
var allHits ={
    globalHites: [
        {
           selector: '[data-section="orders"]',
           message: 'Tips for orders',
           position: 'top'
        },
        {
            selector: '[data-section="users"]',
            message: 'User Tips',
            position: 'bottom'
        },
        {
            selector: '[data-section="catalog"]',
            message: 'Your goods',
            position: 'bottom'
        }
    ]
    
}