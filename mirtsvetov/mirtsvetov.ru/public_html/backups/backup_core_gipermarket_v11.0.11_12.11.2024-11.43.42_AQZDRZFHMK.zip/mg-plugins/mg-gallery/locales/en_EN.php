<?php
$lang = array(
  "DIR_NOT_FOUND" => 'The directory could not be found',
  "NOT_TEMPLATE_FILE" => 'File not found the template plugin',
);
