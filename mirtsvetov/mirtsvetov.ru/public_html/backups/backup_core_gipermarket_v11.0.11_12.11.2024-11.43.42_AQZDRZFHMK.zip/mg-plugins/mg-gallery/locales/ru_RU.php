<?php
$lang = array(
  "DIR_NOT_FOUND" => 'Директория не найдена',
  "NOT_TEMPLATE_FILE" => 'Не найден файл шаблона плагина',
);