<?php mgAddMeta('<script src="'.SCRIPT.'jquery.fancybox.pack.js"></script>'); ?>
<?php mgAddMeta('<script src="'.SITE.'/'.self::$path.'/js/script.js"></script>'); ?>
<link type="text/css" href="<?php echo SCRIPT;?>standard/css/jquery.fancybox.css" rel="stylesheet"/>
<span class='gal' data-id='4' data-line="<?= $options['in_line']; ?>"></span>
<link rel="stylesheet" href="<?php echo SITE.'/'.self::$path;?>/css/style.css" type="text/css" />