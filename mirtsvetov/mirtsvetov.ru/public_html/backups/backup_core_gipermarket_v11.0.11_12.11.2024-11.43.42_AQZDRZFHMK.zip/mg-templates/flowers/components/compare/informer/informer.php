<?php mgAddMeta('components/compare/informer/informer.css'); ?>

<div class="c-compare__informer js-compare-informer">
    <div class="c-compare__informer--content">
        <svg class="icon icon--check">
            <use xlink:href="#icon--check"></use>
        </svg>
        <?php echo lang('compareAdded'); ?>
    </div>
</div>