<a href="<?php echo SITE . '/compare?inCompareProductId=' . $data["id"]; ?>"
   title="<?php echo lang('buttonCompare'); ?>"
   rel="nofollow"
   class="js-add-to-compare addToCompare"
   data-item-id="<?php echo $data["id"]; ?> ">
    <svg>
          <use xlink:href="<?php echo PATH_SITE_TEMPLATE ?>/images/svg/icons.svg#compare"></use>
      </svg>
</a>