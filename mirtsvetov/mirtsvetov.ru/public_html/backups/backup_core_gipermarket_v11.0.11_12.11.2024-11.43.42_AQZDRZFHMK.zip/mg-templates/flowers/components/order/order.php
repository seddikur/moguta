<?php
mgAddMeta('js/jquery.maskedinput.min.js');
mgAddMeta('components/order/form/form.js');
?>
<div class="checkout-form-wrapper" style="display:<?php echo $data['isEmpty'] ? 'block' : 'none'; ?>">

    <?php if ($data['msg']):?><div class="alert"><?php echo $data['msg'] ?></div><?php endif; ?>

    <div class="payment-option">
        <form class="js-orderForm" action="<?php echo SITE ?>/order?creation=1" method="post">
            <div class="step">
                <div class="h3-like">1. <?php echo lang('orderContactData'); ?></div>
                <?php
                if (in_array(EDITION, array('gipermarket', 'saas'))) {
                    // Форма заказа, настраиваемая в панели управления Moguta.CMS «Гипермаркет» в разделе Настройки/Форма заказа
                    component('order/form/custom');
                }
                else {
                    // статичная форма заказа для остальных редакций
                    component('order/form/static');
                } ?>
            </div>
            
            <div class="step">
                <div class="h3-like">2. <?php echo lang('orderDelivery'); ?></div>
                <?php
                // Способы доставки
                if ('' != $data['delivery']): ?>
                    <ul class="delivery-details-list">
                        <?php foreach ($data['delivery'] as $delivery): ?>
                            <li <?php echo ($delivery['checked']) ? 'class = "active"' : 'class = "noneactive"' ?>>
                                <label data-delivery-date="<?php echo $delivery['date']; ?>"
                                       data-delivery-intervals='<?php echo $delivery["interval"]; ?>'
                                       data-delivery-address='<?php echo $delivery["address_parts"]; ?>'
                                       data-delivery-use-storage='<?php echo $delivery["show_storages"]; ?>'>
                                    <input type="radio" name="delivery" <?php if ($delivery['checked']) echo 'checked' ?> value="<?php echo $delivery['id'] ?>">
                                    <span class="deliveryName"><?php echo $delivery['description'] ?></span>
                                    <?php
                                    if ($delivery['cost'] != 0 || DELIVERY_ZERO == 1) {
                                        $deliveryCostShow = true;
                                    } else {
                                        $deliveryCostShow = false;
                                    }
                                    ?>
                                    <span class="deliveryPrice"
                                          style="<?php echo $deliveryCostShow ? '' : 'display:none;'; ?>">
                                        <?php echo MG::numberFormat($delivery['cost']); ?>
                                    </span>

                                    <span class="deliveryCurrency"
                                          style="<?php echo $deliveryCostShow ? '' : 'display:none;'; ?>">
                                        <?php echo '&nbsp;' . $data['currency']; ?>
                                    </span>
                                    <span class = "date_settings" style="display:none">
                                        <?php echo $delivery['date_settings'] ?>
                                    </span>
                                </label>
                                <span class="deliveryInfo">
                                    <?php echo $delivery['description_public']; ?>
                                </span>

                                <!--
                                Для способов доставки с автоматическим расчетом стоимости, добавленных из плагинов.
                                Проверяем наличие шорткода у способа доставки и выводим его в специальный блок при наличии
                                -->
                                <?php if (!empty($delivery['plugin'])): ?>
                                    <?php echo '[' . $delivery['plugin'] . ']'; ?>
                                <?php endif; ?>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
                <!--  Выбор даты доставки -->
                <div class="delivery-date" style="display:none;">
                    <?php echo lang('orderDeliveryDate'); ?>:<input type="text" aria-label="<?php echo lang('orderDeliveryDate'); ?>" name="date_delivery" placeholder="<?php echo lang('orderDeliveryDate'); ?>" value="<?php echo $_POST['date_delivery'] ?>">
                </div>

                <!-- Выбор времени доставки -->
                <div class="delivery-interval" style="display:none"><?php echo lang('orderDeliveryInterval'); ?>:<select name="delivery_interval" aria-label="<?php echo lang('orderDeliveryInterval'); ?>"></select>
                </div>

                <!-- Выбор склада -->
                <?php MG::checkProductOnStorage(); ?>
            </div>


            <!-- Выбор способа оплаты -->
            <div class="step">
                <div class="h3-like">3. <?php echo lang('orderPaymentMethod'); ?></div>
                <ul class="payment-details-list">
                    <?php if (count($data['delivery']) > 1 && !$_POST['payment']): ?>
                        <li>
                            <div class="alert"><?php echo lang('orderPaymentNoDeliv'); ?></div>
                        </li>
                    <?php elseif ('' != $data['paymentArray']): ?>
                        <?php echo $data['paymentArray'] ?>
                    <?php else:
                        ?>
                        <li>
                            <div class="alert"><?php echo lang('orderPaymentNone'); ?></div>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>

            <!-- Полная цена, соглашения на обработку и кнопка оформить -->
            <div class="step">
                <div class="total-price-block total">
                    <div class="h3-like">4. <?php echo lang('orderPaymentTotal'); ?></div>
                    <div class="c-order__total">
                        <div class="c-order__total--amount summ-info">
                            <span class="order-summ total-sum"><span><?php echo $data['summOrder'] ?></span></span>
                            <span class="delivery-summ"><?php echo $data['deliveryInfo'] ?></span>
                        </div>
                        <?php if(class_exists('bonusCard')) { ?> 
                            <?php if(bonusCard::getCountBonus() != '0 бонусов'): ?>
                                [pay-bonus order=true]
                            <?php endif; ?>
                        <?php } ?>
                        <?php if ($data['captcha'] && !$data['recaptcha']) { ?>
                            <div class="checkCapcha" style="display:inline-block">
                                <img src="captcha.html"
                                     width="140"
                                     height="36">
                                <div class="capcha-text">
                                    <?php echo lang('captcha'); ?>
                                    <span class="red-star">*</span>
                                </div>
                                <input type="text"
                                       aria-label="capcha"
                                       name="capcha"
                                       class="captcha">
                            </div>
                        <?php } ?>
                        <?php if ($data['recaptcha']) { ?>
                            <div class="checkCapcha" style="display:inline-block">
                                <?php echo MG::printReCaptcha(); ?>
                            </div>
                        <?php } ?>
                        <?php if (class_exists('PersonalData')): ?>
                            <div class="PersonalData">
                                [personal-data]
                            </div>
                        <?php endif; ?>
                        
                        <form action="<?php echo SITE ?>/order" method="post" class="checkout-form">
                            <input type="submit" name="toOrder" class="checkout-btn button success" value="<?php echo lang('checkout'); ?>" disabled>
                        </form>
                        <?php
                        echo MG::addAgreementCheckbox(
                            'checkout-btn',
                            array(
                                'text' => lang('agreementCheckboxText'),
                                'textLink' => lang('agreementCheckboxLink')
                            ),
                            'addInlineScript'
                        );
                        ?>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>