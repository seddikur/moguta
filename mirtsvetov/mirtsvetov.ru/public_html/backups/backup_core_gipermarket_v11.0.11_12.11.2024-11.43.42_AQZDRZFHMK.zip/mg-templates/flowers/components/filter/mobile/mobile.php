<?php mgAddMeta('components/filter/mobile/mobile.js'); ?>

<a href="#c-filter" class="c-button c-filter__button">
    <svg class="icon icon--filter">
        <use xlink:href="#icon--filter"></use>
    </svg>
    <?php echo lang('mobileShowFilter'); ?>
</a>