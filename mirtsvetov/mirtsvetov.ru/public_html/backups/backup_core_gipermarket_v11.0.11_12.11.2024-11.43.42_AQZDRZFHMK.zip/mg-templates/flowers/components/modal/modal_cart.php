<div class="modal">
    <div class="inner">
        <?php component('cart/popup', $data); ?>
    </div>
</div>