
DROP TABLE IF EXISTS `mg_setting`;

CREATE TABLE `mg_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `option` varchar(191) NOT NULL,
  `value` longtext,
  `active` varchar(1) NOT NULL DEFAULT 'N',
  `name` varchar(249) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `option` (`option`),
  KEY `option_2` (`option`)
) ENGINE=InnoDB AUTO_INCREMENT=2237 DEFAULT CHARSET=utf8mb4;


INSERT INTO `mg_setting` VALUES
("1","sitename","Мир цветов","Y","SITE_NAME"),
("2","adminEmail","tech@belka.one","Y","EMAIL_ADMIN"),
("3","templateName","flowers","Y","SITE_TEMPLATE"),
("4","countСatalogProduct","100","Y","CATALOG_COUNT_PAGE"),
("5","currency","руб.","Y","SETTING_CURRENCY"),
("6","staticMenu","true","N","SETTING_STATICMENU"),
("7","orderMessage","Оформлен заказ № #ORDER# на сайте #SITE#","Y","TPL_EMAIL_ORDER"),
("8","downtime","false","N","DOWNTIME_SITE"),
("9","downtime1C","false","N","CLOSE_SITE_FOR_1C"),
("10","currentVersion","{\"dateActivateKey\":\"2024-10-28 20:47:07\",\"edition\":\"giper\",\"notifications\":[],\"last\":null,\"final\":null,\"disc\":null,\"author\":null}","N","INFO_CUR_VERSION"),
("11","timeLastUpdata","cjoXNTvyhsBrOKgfDUSSUAfpKCrZSbUWfGKPreSjUXfTKyrs","N","LASTTIME_UPDATE"),
("12","title"," Лучший магазин | Moguta.CMS","N","SETTING_PAGE_TITLE"),
("13","countPrintRowsProduct","100","Y","ADMIN_COUNT_PROD"),
("14","languageLocale","ru_RU","N","ADMIN_LANG_LOCALE"),
("15","countPrintRowsPage","10","Y","ADMIN_COUNT_PAGE"),
("16","themeColor","green-theme","N","ADMIN_THEM_COLOR"),
("17","themeBackground","bg_7.png","N","ADMIN_THEM_BG"),
("18","countPrintRowsOrder","20","N","ADMIN_COUNT_ORDER"),
("19","countPrintRowsUser","30","N","ADMIN_COUNT_USER"),
("20","licenceKey","9986a88009acd1578cf2cb8243e5dc2d","N","LICENCE_KEY"),
("21","mainPageIsCatalog","true","Y","SETTING_CAT_ON_INDEX"),
("22","countNewProduct","5","Y","COUNT_NEW_PROD"),
("23","countRecomProduct","5","Y","COUNT_RECOM_PROD"),
("24","countSaleProduct","5","Y","COUNT_SALE_PROD"),
("25","actionInCatalog","true","Y","VIEW_OR_BUY"),
("26","printProdNullRem","true","Y","PRINT_PROD_NULL_REM"),
("27","printRemInfo","true","Y","PRINT_REM_INFO"),
("28","printCount","true","Y","PRINT_COUNT"),
("29","printCode","true","Y","PRINT_CODE"),
("30","printUnits","true","Y","PRINT_UNITS"),
("31","printBuy","true","Y","PRINT_BUY"),
("32","printCost","true","Y","PRINT_COST"),
("33","heightPreview","700","Y","PREVIEW_HEIGHT"),
("34","widthPreview","700","Y","PREVIEW_WIDTH"),
("35","heightSmallPreview","700","Y","PREVIEW_HEIGHT_2"),
("36","widthSmallPreview","700","Y","PREVIEW_WIDTH_2"),
("37","categoryIconHeight","100","Y","CAT_ICON_HEIGHT"),
("38","categoryIconWidth","100","Y","CAT_ICON_WIDTH"),
("39","waterMark","false","Y","WATERMARK"),
("40","waterMarkPosition","center","Y","WATERMARKPOSITION"),
("41","widgetCode","<!-- В это поле необходимо прописать код счетчика посещаемости Вашего сайта. Например, Яндекс.Метрика или Google analytics -->","Y","WIDGETCODE"),
("42","metaConfirmation","<!-- В это поле необходимо прописать код подтверждения Вашего сайта. Например, Яндекс.Метрика или Google analytics -->","Y","META_TAGS_CONFIRMATION"),
("43","noReplyEmail","noreply@sitename.ru","Y","NOREPLY_EMAIL"),
("44","smtp","false","Y","SMTP"),
("45","smtpHost","","Y","SMTP_HOST"),
("46","smtpLogin","","Y","SMTP_LOGIN"),
("47","smtpPass","aFkqNm5rNyEhIzJxag==","Y","SMTP_PASS"),
("48","smtpPort","","Y","SMTP_PORT"),
("49","shopPhone","8 (555) 555-55-55","Y","SHOP_PHONE"),
("50","shopAddress","г. Москва, ул. Тверская, 1.","Y","SHOP_ADDERSS"),
("51","shopName","Интернет-магазин","Y","SHOP_NAME"),
("52","shopLogo","/uploads/logo.svg","Y","SHOP_LOGO"),
("53","phoneMask","+7 (###) ### ##-##,+380 (##) ### ##-##,+375 (##) ### ##-##","Y","PHONE_MASK"),
("54","printStrProp","false","Y","PROP_STR_PRINT"),
("55","noneSupportOldTemplate","false","Y","OLD_TEMPLATE"),
("56","printCompareButton","true","Y","BUTTON_COMPARE"),
("57","currencyShopIso","RUR","Y","CUR_SHOP_ISO"),
("58","cacheObject","false","Y","CACHE_OBJECT"),
("59","cacheMode","FILE","Y","CACHE_MODE"),
("60","cacheTime","86400","Y","CACHE_TIME"),
("61","cacheHost","","Y","CACHE_HOST"),
("62","cachePort","","Y","CACHE_PORT"),
("63","priceFormat","1 234,56","Y","PRICE_FORMAT"),
("64","horizontMenu","false","Y","HORIZONT_MENU"),
("65","buttonBuyName","Купить","Y","BUTTON_BUY_NAME"),
("66","buttonCompareName","Сравнить","Y","BUTTON_COMPARE_NAME"),
("67","randomProdBlock","false","Y","RANDOM_PROD_BLOCK"),
("68","buttonMoreName","Подробнее","Y","BUTTON_MORE_NAME"),
("69","compareCategory","true","Y","COMPARE_CATEGORY"),
("70","colorScheme","1","Y","COLOR_SCHEME"),
("71","useCaptcha","false","Y","USE_CAPTCHA"),
("72","autoRegister","true","Y","AUTO_REGISTER"),
("73","printFilterResult","true","Y","FILTER_RESULT"),
("74","dateActivateKey","2024-10-28 20:47:07","N",""),
("75","propertyOrder","a:20:{s:7:\"nameyur\";s:6:\"ООО\";s:6:\"adress\";s:48:\"г.Москва ул. Тверская, дом 1\";s:5:\"email\";s:0:\"\";s:3:\"inn\";s:10:\"8805614058\";s:3:\"kpp\";s:9:\"980501000\";s:4:\"ogrn\";s:13:\"7137847078193\";s:4:\"bank\";s:16:\"Сбербанк\";s:3:\"bik\";s:9:\"041012721\";s:2:\"ks\";s:20:\"40702810032030000834\";s:2:\"rs\";s:20:\"30101810600000000957\";s:7:\"general\";s:48:\"Михаил Васильевич Могутов\";s:4:\"sing\";s:0:\"\";s:5:\"stamp\";s:0:\"\";s:3:\"nds\";s:2:\"18\";s:8:\"usedsing\";s:4:\"true\";s:8:\"currency\";s:34:\"рубль,рубля,рублей\";s:12:\"order_status\";s:1:\"0\";s:19:\"default_date_filter\";s:7:\"default\";s:15:\"downloadInvoice\";s:1:\"1\";s:19:\"paymentAfterConfirm\";s:5:\"false\";}","N","PROPERTY_OPRDER"),
("76","enabledSiteEditor","false","N",""),
("77","lockAuthorization","false","Y","LOCK_AUTH"),
("78","orderNumber","true","Y","ORDER_NUMBER"),
("79","popupCart","true","Y","POPUP_CART"),
("80","catalogIndex","false","Y","CATALOG_INDEX"),
("81","productInSubcat","true","Y","PRODUCT_IN_SUBCAT"),
("82","copyrightMoguta","true","Y","COPYRIGHT_MOGUTA"),
("83","copyrightMogutaLink","","Y","COPYRIGHT_MOGUTA_LINK"),
("84","picturesCategory","true","Y","PICTURES_CATEGORY"),
("85","noImageStub","/uploads/no-img.jpg","Y","NO_IMAGE_STUB"),
("86","backgroundSite","","Y","BACKGROUND_SITE"),
("87","backgroundColorSite","","Y","BACKGROUND_COLOR_SITE"),
("88","backgroundTextureSite","","Y","BACKGROUND_TEXTURE_SITE"),
("89","backgroundSiteLikeTexture","false","Y","BACKGROUND_SITE_LIKE_TEXTURE"),
("90","fontSite","default","Y","FONT_SITE"),
("91","cacheCssJs","false","Y","CACHE_CSS_JS"),
("92","categoryImgWidth","200","Y","CATEGORY_IMG_WIDTH"),
("93","categoryImgHeight","200","Y","CATEGORY_IMG_HEIGHT"),
("94","propImgWidth","50","Y","PROP_IMG_WIDTH"),
("95","propImgHeight","50","Y","PROP_IMG_HEIGHT"),
("96","favicon","favicon-temp.svg","Y","FAVICON"),
("97","connectZoom","true","Y","CONNECT_ZOOM"),
("98","filterSort","sort|asc","Y","FILTER_SORT"),
("99","shortLink","false","Y","SHORT_LINK"),
("100","imageResizeType","PROPORTIONAL","Y","IMAGE_RESIZE_TYPE");
INSERT INTO `mg_setting` VALUES
("101","imageSaveQuality","100","Y","IMAGE_SAVE_QUALITY"),
("102","duplicateDesc","false","Y","DUPLICATE_DESC"),
("103","excludeUrl","","Y","EXCLUDE_SITEMAP"),
("104","autoGeneration","true","Y","AUTO_GENERATION"),
("105","generateEvery","2","Y","GENERATE_EVERY"),
("106","consentData","false","Y","CONSENT_DATA"),
("107","showCountInCat","true","Y","SHOW_COUNT_IN_CAT"),
("108","nameOfLinkyml","getyml","N","NAME_OF_LINKYML"),
("109","clearCatalog1C","false","Y","CLEAR_1C_CATALOG"),
("110","fileLimit1C","10000000","Y","FILE_LIMIT_1C"),
("111","ordersPerTransfer1c","1000","Y","ORDERS_PER_TRANSFER_1C"),
("112","weightPropertyName1c","Вес","Y","WEIGHT_NAME_1C"),
("113","multiplicityPropertyName1c","Кратность","Y","MULTIPLICITY_NAME_1C"),
("114","oldPriceName1c","","Y","OLD_PRICE_NAME_1C"),
("115","retailPriceName1c","","Y","RETAIL_PRICE_NAME_1C"),
("116","showSortFieldAdmin","false","Y","SHOW_SORT_FIELD_ADMIN"),
("117","filterSortVariant","sort|asc","Y","FILTER_SORT_VARIANT"),
("118","productsOutOfStockToEnd","false","Y","PRODUCTS_OUT_OF_STOCK_TO_THE_END"),
("119","showVariantNull","true","Y","SHOW_VARIANT_NULL"),
("120","confirmRegistration","true","Y","CONFIRM_REGISTRATION"),
("121","cachePrefix","","Y","CACHE_PREFIX"),
("122","usePhoneMask","true","Y","USE_PHONE_MASK"),
("123","smtpSsl","false","Y","SMTP_SSL"),
("124","sessionToDB","false","Y","SAVE_SESSION_TO_DB"),
("125","sessionLifeTime","1440","Y","SESSION_LIVE_TIME"),
("126","sessionAutoUpdate","true","Y","SESSION_AUTO_UPDATE"),
("127","showCodeInCatalog","false","Y","SHOW_CODE_IN_CATALOG"),
("128","openGraph","true","Y","OPEN_GRAPH"),
("129","openGraphLogoPath","","Y","OPEN_GRAPH_LOGO_PATH"),
("130","dublinCore","true","Y","DUBLIN_CORE"),
("131","printSameProdNullRem","true","Y","PRINT_SAME_PROD_NULL_REM"),
("132","landingName","lp-moguta","N","LANDING_NAME"),
("133","colorSchemeLanding","none","N","COLOR_SCHEME_LANDING"),
("134","printQuantityInMini","false","Y","SHOW_QUANTITY"),
("135","printCurrencySelector","false","Y","CURRENCY_SELECTOR"),
("136","interface","a:7:{s:9:\\\"colorMain\\\";s:7:\\\"#000000\\\";s:9:\\\"colorLink\\\";s:7:\\\"#1585cf\\\";s:9:\\\"colorSave\\\";s:7:\\\"#4caf50\\\";s:11:\\\"colorBorder\\\";s:7:\\\"#e6e6e6\\\";s:14:\\\"colorSecondary\\\";s:7:\\\"#ebebeb\\\";s:8:\\\"adminBar\\\";s:9:\\\"#00000088\\\";s:17:\\\"adminBarFontColor\\\";s:7:\\\"#000000\\\";}","Y","INTERFACE_SETTING"),
("137","filterCountProp","3","Y","FILTER_COUNT_PROP"),
("138","filterMode","true","Y","FILTER_MODE"),
("139","filterCountShow","5","Y","FILTER_COUNT_SHOW"),
("140","filterSubcategory","false","Y","FILTER_SUBCATGORY"),
("141","printVariantsInMini","false","Y","SHOW_VARIANT_MINI"),
("142","useReCaptcha","false","Y","USE_RECAPTCHA"),
("143","invisibleReCaptcha","false","Y","INVISIBLE_RECAPTCHA"),
("144","reCaptchaKey","","Y","RECAPTCHA_KEY"),
("145","reCaptchaSecret","","Y","RECAPTCHA_SECRET"),
("146","timeWork","09:00 - 19:00,10:00 - 17:00","Y","TIME_WORK"),
("147","useSeoRewrites","true","Y","SEO_REWRITES"),
("148","useSeoRedirects","false","Y","SEO_REDIRECTS"),
("149","showMainImgVar","false","Y","SHOW_MAIN_IMG_VAR"),
("150","loginAttempt","5","Y","LOGIN_ATTEMPT"),
("151","prefixOrder","M-010","Y","PREFIX_ORDER"),
("152","captchaOrder","false","Y","CAPTCHA_ORDER"),
("153","deliveryZero","true","Y","DELIVERY_ZERO"),
("154","outputMargin","true","Y","OUTPUT_MARGIN"),
("155","prefixCode","CN","Y","PREFIX_CODE"),
("156","maxUploadImgWidth","1500","Y","MAX_UPLOAD_IMAGE_WIDTH"),
("157","maxUploadImgHeight","1500","Y","MAX_UPLOAD_IMAGE_HEIGHT"),
("158","searchType","like","Y","SEARCH_TYPE"),
("159","searchSphinxHost","localhost","Y","SEARCH_SPHINX_HOST"),
("160","searchSphinxPort","9312","Y","SEARCH_SPHINX_PORT"),
("161","checkAdminIp","false","Y","CHECK_ADMIN_IP"),
("162","printSeo","all","Y","PRINT_SEO"),
("163","catalogProp","0","Y","CATALOG_PROP"),
("164","printAgreement","true","Y","PRINT_AGREEMENT"),
("165","currencyShort","a:6:{s:3:\\\"RUR\\\";s:7:\\\"руб.\\\";s:3:\\\"UAH\\\";s:7:\\\"грн.\\\";s:3:\\\"USD\\\";s:1:\\\"$\\\";s:3:\\\"EUR\\\";s:3:\\\"€\\\";s:3:\\\"KZT\\\";s:10:\\\"тенге\\\";s:3:\\\"UZS\\\";s:6:\\\"сум\\\";}","Y","CUR_SHOP_SHORT"),
("166","useElectroLink","false","Y","USE_ELECTRO_LINK"),
("167","useMultiplicity","false","Y","USE_MULTIPLICITY"),
("168","currencyActive","a:5:{i:0;s:3:\"UAH\";i:1;s:3:\"USD\";i:2;s:3:\"EUR\";i:3;s:3:\"KZT\";i:4;s:3:\"UZS\";}","Y",""),
("169","closeSite","false","Y","CLOSE_SITE_1C"),
("170","catalogPreCalcProduct","old","Y","CATALOG_PRE_CALC_PRODUCT"),
("171","printSpecFilterBlock","true","Y","FILTER_PRINT_SPEC"),
("172","disabledPropFilter","false","Y","DISABLED_PROP_FILTER"),
("173","enableDeliveryCur","false","Y","ENABLE_DELIVERY_CUR"),
("174","addDateToImg","false","Y","ADD_DATE_TO_IMG"),
("175","variantToSize1c","false","Y","VARIANT_TO_SIZE_1C"),
("176","skipRootCat1C","false","Y","SKIP_ROOT_CAT_1C"),
("177","sphinxLimit","20","Y","SPHINX_LIMIT"),
("178","filterCatalogMain","false","Y","FILTER_CATALOG_MAIN"),
("179","importColorSize","size","Y","IMPORT_COLOR_SIZE"),
("180","sizeName1c","Размер","Y","SIZE_NAME_1C"),
("181","colorName1c","Цвет","Y","COLOR_NAME_1C"),
("182","sizeMapMod","color","Y","SIZE_MAP_MOD"),
("183","modParamInVarName","true","Y","MOD_PARAM_IN_VAR_NAME"),
("184","orderOwners","false","Y","ORDER_OWNERS"),
("185","ownerRotation","false","Y","OWNER_ROTATION"),
("186","ownerRotationCurrent","","Y","OWNER_ROTATION_CURRENT"),
("187","ownerList","","Y","OWNER_LIST"),
("188","ownerRemember","false","Y","OWNER_REMBER"),
("189","ownerRememberPhone","false","Y","OWNER_REMBER_PHONE"),
("190","ownerRememberEmail","false","Y","OWNER_REMBER_EMAIL"),
("191","ownerRememberDays","14","Y","OWNER_REMBER_DAYS"),
("192","convertCountToHR","2:последний товар,5:скоро закончится,15:мало,100:много","Y","CONVERT_COUNT_TO_HR"),
("193","blockEntity","false","Y","BLOCK_ENTITY"),
("194","useFavorites","true","Y","USE_FAVORITES"),
("195","countPrintRowsBrand","10","Y",""),
("196","varHashProduct","true","Y","VAR_HASH_PRODUCT"),
("197","useSearchEngineInfo","false","Y","USE_SEARCH_ENGINE_INFO"),
("198","timezone","noChange","Y","TIMEZONE"),
("199","recalcWholesale","true","Y","RECALC_WHOLESALE"),
("200","recalcForeignCurrencyOldPrice","true","Y","RECALCT_FOREIGN_CURRENCY_OLD_PRICE");
INSERT INTO `mg_setting` VALUES
("201","printOneColor","false","Y","PRINT_ONE_COLOR"),
("202","updateStringProp1C","false","Y","UPDATE_STRING_PROP_1C"),
("203","weightUnit1C","kg","Y","WEIGHT_UNIT_1C"),
("204","writeLog1C","false","Y","WRITE_LOG_1C"),
("205","writeFiles1C","false","Y","WRITE_FILES_1C"),
("206","writeFullName1C","false","Y","WRITE_FULL_NAME_1C"),
("207","activityCategory1C","true","Y","ACTIVITY_CATEGORY_1C"),
("208","notUpdate1C","a:14:{s:8:\\\"1c_title\\\";s:4:\\\"true\\\";s:7:\\\"1c_code\\\";s:4:\\\"true\\\";s:6:\\\"1c_url\\\";s:4:\\\"true\\\";s:9:\\\"1c_weight\\\";s:4:\\\"true\\\";s:8:\\\"1c_count\\\";s:4:\\\"true\\\";s:14:\\\"1c_description\\\";s:4:\\\"true\\\";s:12:\\\"1c_image_url\\\";s:4:\\\"true\\\";s:13:\\\"1c_meta_title\\\";s:4:\\\"true\\\";s:16:\\\"1c_meta_keywords\\\";s:4:\\\"true\\\";s:12:\\\"1c_meta_desc\\\";s:5:\\\"false\\\";s:11:\\\"1c_activity\\\";s:4:\\\"true\\\";s:12:\\\"1c_old_price\\\";s:4:\\\"true\\\";s:9:\\\"1c_cat_id\\\";s:4:\\\"true\\\";s:15:\\\"1c_multiplicity\\\";s:5:\\\"false\\\";}","y","update_1c"),
("209","notUpdateCat1C","a:4:{s:11:\\\"cat1c_title\\\";s:4:\\\"true\\\";s:9:\\\"cat1c_url\\\";s:4:\\\"true\\\";s:12:\\\"cat1c_parent\\\";s:4:\\\"true\\\";s:18:\\\"cat1c_html_content\\\";s:5:\\\"false\\\";}","Y","UPDATE_CAT_1C"),
("210","listMatch1C","a:7:{i:0;s:27:\\\"не подтвержден\\\";i:1;s:27:\\\"ожидает оплаты\\\";i:2;s:14:\\\"оплачен\\\";i:3;s:19:\\\"в доставке\\\";i:4;s:14:\\\"отменен\\\";i:5;s:16:\\\"выполнен\\\";i:6;s:21:\\\"в обработке\\\";}","Y","UPDATE_STATUS_1C"),
("211","product404","false","Y",""),
("212","product404Sitemap","false","Y",""),
("213","productFilterPriceSliderStep","10","Y","PRODUCT_FILTER_PRICE_SLIDER_STEP"),
("214","catalogColumns","a:6:{i:0;s:6:\"number\";i:1;s:8:\"category\";i:2;s:3:\"img\";i:3;s:5:\"title\";i:4;s:5:\"price\";i:5;s:5:\"count\";}","Y",""),
("215","orderColumns","a:9:{i:0;s:2:\"id\";i:1;s:6:\"number\";i:2;s:4:\"date\";i:3;s:3:\"fio\";i:4;s:5:\"email\";i:5;s:4:\"summ\";i:6;s:5:\"deliv\";i:7;s:7:\"payment\";i:8;s:6:\"status\";}","Y",""),
("216","userColumns","a:5:{i:0;s:5:\"email\";i:1;s:6:\"status\";i:2;s:5:\"group\";i:3;s:8:\"register\";i:4;s:8:\"personal\";}","Y",""),
("217","useNameParts","false","Y","ORDER_NAME_PARTS"),
("218","searchInDefaultLang","true","Y","SEARCH_IN_DEFAULT_LANG"),
("219","backupBeforeUpdate","true","Y","BACKUP_BEFORE_UPDATE"),
("220","mailsBlackList","","Y","MAILS_BLACK_LIST"),
("221","rememberLogins","true","Y","REMEMBER_LOGINS"),
("222","rememberLoginsDays","180","Y","REMEMBER_LOGINS_DAYS"),
("223","loginBlockTime","15","Y","LOGIN_BLOCK_TIME"),
("224","printMultiLangSelector","true","Y",""),
("225","imageResizeRetina","false","Y","IMAGE_RESIZE_RETINA"),
("226","timeWorkDays","Пн-Пт:,Сб-Вс:","Y","TIME_WORK_DAYS"),
("227","logger","false","Y","LOGGER"),
("228","hitsFlag","true","Y","HITSFLAG"),
("229","introFlag","[\"main\"]","Y","INTRO_FLAG"),
("230","useAbsolutePath","false","Y","USE_ABSOLUTE_PATH"),
("231","productSitemapLocale","true","Y","PRODUCT_SITEMAP_LOCALE"),
("232","sitetheme","Доставка цветов","Y","SITE_TEME"),
("233","siteThemeVariants","a:41:{i:0;s:26:\"Одежда и обувь\";i:1;s:55:\"Электроника и бытовая техника\";i:2;s:42:\"Косметика и парфюмерия\";i:3;s:53:\"Специализированные магазины\";i:4;s:64:\"Товары для ремонта и строительства\";i:5;s:46:\"Автозапчасти и транспорт\";i:6;s:34:\"Красота и здоровье\";i:7;s:30:\"Товары для детей\";i:8;s:28:\"Товары для дома\";i:9;s:46:\"Товары для сада и огорода\";i:10;s:32:\"Товары для спорта\";i:11;s:29:\"Доставка цветов\";i:12;s:54:\"Товары для хобби и творчества\";i:13;s:58:\"Смартфоны, планшеты, аксессуары\";i:14;s:49:\"Продукты питания и напитки\";i:15;s:43:\"Универсальные магазины\";i:16;s:30:\"Товары для офиса\";i:17;s:36:\"Товары для животных\";i:18;s:18:\"Чай и кофе\";i:19;s:28:\"Табак и кальяны\";i:20;s:28:\"Рыбалка и охота\";i:21;s:34:\"Свет и светильники\";i:22;s:32:\"Сантехника и вода\";i:23;s:44:\"Радиотехника и запчасти\";i:24;s:34:\"Товары для бизнеса\";i:25;s:12:\"Мебель\";i:26;s:32:\"Еда, пицца и роллы\";i:27;s:56:\"Производство и промышленность\";i:28;s:36:\"Товары для взрослых\";i:29;s:58:\"Видеонаблюдение и безопасность\";i:30;s:10:\"Сумки\";i:31;s:12:\"Услуги\";i:32;s:30:\"Софт и программы\";i:33;s:47:\"Ювелирные магазины и часы\";i:34;s:10:\"Двери\";i:35;s:10:\"Книги\";i:36;s:34:\"Подарки и сувениры\";i:37;s:34:\"Упаковки и коробки\";i:38;s:62:\"Средства для борьбы с вредителями\";i:39;s:31:\"Постельное белье\";i:40;s:12:\"Другое\";}","N","SITE_TEME_VARIANTS"),
("234","useDefaultSettings","false","N",""),
("235","backupSettingsFile","","N",""),
("236","ordersPerPageForUser","10","Y","ORDER_USER_COUNT"),
("237","useTemplatePlugins","1","Y","USE_TEMPLATE_PLUGINS"),
("238","thumbsProduct","false","Y","THUMBS_PRODUCT"),
("239","exifRotate","false","Y","EXIF_ROTATE"),
("240","metaLangContent","zxx","Y","META_LANG_CONTENT"),
("241","useSeoCanonical","false","Y","SEO_CANONICAL"),
("242","confirmRegistrationEmail","true","Y","CONFIRM_REGISTRATION_EMAIL"),
("243","confirmRegistrationPhone","false","Y","CONFIRM_REGISTRATION_PHONE"),
("244","confirmRegistrationPhoneType","sms","Y","CONFIRM_REGISTRATION_PHONE_TYPE"),
("245","storages_settings","a:3:{s:12:\"writeOffProc\";s:1:\"1\";s:28:\"storagesAlgorithmWithoutMain\";s:0:\"\";s:11:\"mainStorage\";s:0:\"\";}","N","STORAGES_SETTINGS"),
("246","useOneStorage","false","N","USE_ONE_STORAGE"),
("247","genMetaLang","true","Y","GEN_META_LANG"),
("248","catalog_meta_title","{titeCategory}","N","CATALOG_META_TITLE"),
("249","catalog_meta_description","{cat_desc,160}","N","CATALOG_META_DESC"),
("250","catalog_meta_keywords","{meta_keywords}","N","CATALOG_META_KEYW"),
("251","product_meta_title","{title}","N","PRODUCT_META_TITLE"),
("252","product_meta_description","{description}","N","PRODUCT_META_DESC"),
("253","product_meta_keywords","{%title}","N","PRODUCT_META_KEYW"),
("254","page_meta_title","{title}","N","PAGE_META_TITLE"),
("255","page_meta_description","{html_content,160}","N","PAGE_META_DESC"),
("256","page_meta_keywords","{meta_keywords}","N","PAGE_META_KEYW"),
("257","useWebpImg","false","Y","USE_WEBP_IMAGES"),
("258","currencyRate","a:6:{s:3:\\\"RUR\\\";d:1;s:3:\\\"UAH\\\";d:2.03990999999999989000798450433649122714996337890625;s:3:\\\"USD\\\";d:56.62780000000000057980287238024175167083740234375;s:3:\\\"EUR\\\";d:70.4959000000000060026650317013263702392578125;s:3:\\\"KZT\\\";d:0.1756999999999999950706097706643049605190753936767578125;s:3:\\\"UZS\\\";d:0.00692599999999999986488585790311844903044402599334716796875;}","Y","CUR_SHOP_RATE"),
("259","1c_unit_item","Килограмм:кг,Метр:м,Квадратный метр:м2,Кубический метр:м3,Штука:шт.,Литр:л","Y","1C_UNIT_ITEM"),
("260","showStoragesRecalculate","false","Y",""),
("261","orderFormFields","a:14:{s:5:\"email\";a:4:{s:6:\"active\";s:1:\"1\";s:4:\"sort\";s:1:\"1\";s:8:\"required\";s:1:\"1\";s:13:\"conditionType\";s:6:\"always\";}s:5:\"phone\";a:6:{s:6:\"active\";s:1:\"1\";s:4:\"sort\";s:1:\"2\";s:8:\"required\";s:1:\"1\";s:13:\"conditionType\";s:6:\"always\";s:10:\"conditions\";N;s:4:\"type\";s:5:\"input\";}s:3:\"fio\";a:4:{s:6:\"active\";s:1:\"1\";s:4:\"sort\";s:1:\"3\";s:8:\"required\";s:1:\"0\";s:13:\"conditionType\";s:6:\"always\";}s:7:\"address\";a:6:{s:6:\"active\";s:1:\"1\";s:4:\"sort\";s:1:\"4\";s:8:\"required\";s:1:\"0\";s:13:\"conditionType\";s:5:\"ifAll\";s:10:\"conditions\";a:1:{i:0;a:2:{s:4:\"type\";s:8:\"delivery\";s:5:\"value\";a:3:{i:0;s:1:\"0\";i:1;s:1:\"1\";i:2;s:1:\"2\";}}}s:4:\"type\";s:5:\"input\";}s:4:\"info\";a:5:{s:6:\"active\";s:1:\"1\";s:4:\"sort\";s:1:\"5\";s:8:\"required\";s:1:\"0\";s:13:\"conditionType\";s:6:\"always\";s:10:\"conditions\";N;}s:8:\"customer\";a:4:{s:6:\"active\";s:1:\"1\";s:4:\"sort\";s:1:\"6\";s:8:\"required\";s:1:\"0\";s:13:\"conditionType\";s:6:\"always\";}s:16:\"yur_info_nameyur\";a:5:{s:6:\"active\";s:1:\"1\";s:4:\"sort\";s:1:\"7\";s:8:\"required\";s:1:\"0\";s:13:\"conditionType\";s:5:\"ifAll\";s:10:\"conditions\";a:1:{i:0;a:4:{s:4:\"type\";s:10:\"orderField\";s:9:\"fieldName\";s:8:\"customer\";s:9:\"fieldType\";s:6:\"select\";s:5:\"value\";a:1:{i:0;s:3:\"yur\";}}}}s:15:\"yur_info_adress\";a:5:{s:6:\"active\";s:1:\"1\";s:4:\"sort\";s:1:\"8\";s:8:\"required\";s:1:\"0\";s:13:\"conditionType\";s:5:\"ifAll\";s:10:\"conditions\";a:1:{i:0;a:4:{s:4:\"type\";s:10:\"orderField\";s:9:\"fieldName\";s:8:\"customer\";s:9:\"fieldType\";s:6:\"select\";s:5:\"value\";a:1:{i:0;s:3:\"yur\";}}}}s:12:\"yur_info_inn\";a:5:{s:6:\"active\";s:1:\"1\";s:4:\"sort\";s:1:\"9\";s:8:\"required\";s:1:\"0\";s:13:\"conditionType\";s:5:\"ifAll\";s:10:\"conditions\";a:1:{i:0;a:4:{s:4:\"type\";s:10:\"orderField\";s:9:\"fieldName\";s:8:\"customer\";s:9:\"fieldType\";s:6:\"select\";s:5:\"value\";a:1:{i:0;s:3:\"yur\";}}}}s:12:\"yur_info_kpp\";a:5:{s:6:\"active\";s:1:\"1\";s:4:\"sort\";s:2:\"10\";s:8:\"required\";s:1:\"0\";s:13:\"conditionType\";s:5:\"ifAll\";s:10:\"conditions\";a:1:{i:0;a:4:{s:4:\"type\";s:10:\"orderField\";s:9:\"fieldName\";s:8:\"customer\";s:9:\"fieldType\";s:6:\"select\";s:5:\"value\";a:1:{i:0;s:3:\"yur\";}}}}s:13:\"yur_info_bank\";a:5:{s:6:\"active\";s:1:\"1\";s:4:\"sort\";s:2:\"11\";s:8:\"required\";s:1:\"0\";s:13:\"conditionType\";s:5:\"ifAll\";s:10:\"conditions\";a:1:{i:0;a:4:{s:4:\"type\";s:10:\"orderField\";s:9:\"fieldName\";s:8:\"customer\";s:9:\"fieldType\";s:6:\"select\";s:5:\"value\";a:1:{i:0;s:3:\"yur\";}}}}s:12:\"yur_info_bik\";a:5:{s:6:\"active\";s:1:\"1\";s:4:\"sort\";s:2:\"12\";s:8:\"required\";s:1:\"0\";s:13:\"conditionType\";s:5:\"ifAll\";s:10:\"conditions\";a:1:{i:0;a:4:{s:4:\"type\";s:10:\"orderField\";s:9:\"fieldName\";s:8:\"customer\";s:9:\"fieldType\";s:6:\"select\";s:5:\"value\";a:1:{i:0;s:3:\"yur\";}}}}s:11:\"yur_info_ks\";a:5:{s:6:\"active\";s:1:\"1\";s:4:\"sort\";s:2:\"13\";s:8:\"required\";s:1:\"0\";s:13:\"conditionType\";s:5:\"ifAll\";s:10:\"conditions\";a:1:{i:0;a:4:{s:4:\"type\";s:10:\"orderField\";s:9:\"fieldName\";s:8:\"customer\";s:9:\"fieldType\";s:6:\"select\";s:5:\"value\";a:1:{i:0;s:3:\"yur\";}}}}s:11:\"yur_info_rs\";a:5:{s:6:\"active\";s:1:\"1\";s:4:\"sort\";s:2:\"14\";s:8:\"required\";s:1:\"0\";s:13:\"conditionType\";s:5:\"ifAll\";s:10:\"conditions\";a:1:{i:0;a:4:{s:4:\"type\";s:10:\"orderField\";s:9:\"fieldName\";s:8:\"customer\";s:9:\"fieldType\";s:6:\"select\";s:5:\"value\";a:1:{i:0;s:3:\"yur\";}}}}}","Y",""),
("262","lastModVersion","11.1.0","N",""),
("263","lastTimeCacheClear","1733313124","N",""),
("264","chimpApiKey","croKNfvUhSBvONgoDcSDUgfOKBrhSIUufxKdrjSXUTfyKsr","N",""),
("267","trialVersionHash","cvoNNovchvBNOogcDvSNUofcKrrKefPUGSWjdXxTuyIs","N",""),
("273","imageDropTimer","1733399911","N",""),
("278","sizeTempFiles","395527","N",""),
("280","tempSizeCheckTime","1733313511","N",""),
("281","checkEngine","1733313511","N",""),
("292","pluginsVersionInfo","a:0:{}","N",""),
("296","nextCheckPlugin","1733399914","N",""),
("297","mpPlugins","a:4:{s:7:\\\"plugins\\\";a:80:{i:0;s:42:\\\"4e1fb9452b2ab1fd7c08aee4354bd3ef8756273978\\\";i:1;s:42:\\\"6343c58a2a674f246907021000d6f01d6120070103\\\";i:2;s:42:\\\"6e2718b6994a2450cfeb9570cf8c173b5800268675\\\";i:3;s:42:\\\"4525ca2efb7dd5fb2ec371e89d0f366f9372857268\\\";i:4;s:42:\\\"c378fb35a7feb02abd6c125cf6176e703356757860\\\";i:5;s:42:\\\"5ac68cea1f8b0c7aea84e4dc139ce2f35236093551\\\";i:6;s:42:\\\"b324edd52c1f4efae99e719c0fb8e4d94679196286\\\";i:7;s:42:\\\"0b7085f0292ae323623e12060b1a56314813768020\\\";i:8;s:42:\\\"a3024418e0132f9b99db7c941a0f85901728023577\\\";i:9;s:42:\\\"a2def5264b3b0414ebf25328e9a1e0b99057377094\\\";i:10;s:42:\\\"23d23c71c84be503af4c6e512c904fae6404514017\\\";i:11;s:42:\\\"45bbb14a8090b97ffe6656bf0f10a50a9690878537\\\";i:12;s:42:\\\"5d03125f792b66dca0749724b58b40ee5948504335\\\";i:13;s:42:\\\"0359ca847f3d70497e3c02651b8864ac4494479242\\\";i:14;s:42:\\\"ec849cb7444b865700ad2ebe48f266614736665145\\\";i:15;s:42:\\\"a554dcbeb2cfc361a4e4de0cc763f1936896756841\\\";i:16;s:42:\\\"e8e897a73987b3d018e446f6aedf51ac9086895281\\\";i:17;s:42:\\\"52477450ae6a0dad3089fb5b018530d76131682276\\\";i:18;s:42:\\\"e0ae5078e83a59ff1c40a9ca59c2b0842511266555\\\";i:19;s:42:\\\"7f39a6455111fbc365a1e719234fccc39143653107\\\";i:20;s:42:\\\"f80b2f260bfe29adceb159f8b918ae0a7316214781\\\";i:21;s:42:\\\"4024b0a2e19f8d1eb1fde46a79b663f02202018470\\\";i:22;s:42:\\\"cf8758d03cf27b81eef3e1b41f9fee048145747973\\\";i:23;s:42:\\\"857993cb8df17d285e25a6481d3625bb8308358184\\\";i:24;s:42:\\\"627882fc99501a6e56bebf13860b1bdc5675008385\\\";i:25;s:42:\\\"aa582c166682f384b7431595b1b6a2971733308625\\\";i:26;s:42:\\\"a7bde2c3fa5f01c3f84e1aaed1ca40c75739426091\\\";i:27;s:42:\\\"914a6e4556e3920e352b8094e8ec058d8592165148\\\";i:28;s:42:\\\"64ef2b40c29d07aa98c789dbc4a714578037839335\\\";i:29;s:42:\\\"4159c58bd40e25e2de68e77d44766fdc6955006699\\\";i:30;s:42:\\\"8703d6a0ebb0d39d8b04d0bcfb05b7fa8961547133\\\";i:31;s:42:\\\"883824d659241ece7abc5ced088a7ac65692742285\\\";i:32;s:42:\\\"11e43d399cffeca45cf16454abb119772923379286\\\";i:33;s:42:\\\"36f1d41894e23d7f0da30084c37312789560089296\\\";i:34;s:42:\\\"b8c29ab1e370f1bd692befc676f6db495431121057\\\";i:35;s:42:\\\"c230bd250c3f78381dd60a87c68dcbb34123315136\\\";i:36;s:42:\\\"cc42d2e117d599e0d1c183b78e0a4f518662121622\\\";i:37;s:42:\\\"33ac44cb0e32a93618003803032512214091159659\\\";i:38;s:42:\\\"5f3dd75e26dff5a96a6bad55696c9c528204469333\\\";i:39;s:42:\\\"2cd93703d7949652b26aa82a5e6b6e866970403730\\\";i:40;s:42:\\\"72c71193311059d248643be1055d2f0d7604738917\\\";i:41;s:42:\\\"1bd544814016c6c1af7b1f681eae66643377933460\\\";i:42;s:42:\\\"a26eea6a4199cff18174a329a2f5e0207652431063\\\";i:43;s:42:\\\"169e2d69c6a2c13d2cbf82cd8a93f3344184801252\\\";i:44;s:42:\\\"d8a8a949f36995f69a677ff53883771a3133894169\\\";i:45;s:42:\\\"aec02e7cff7c2a0c0ee1bffb95febbc47478873653\\\";i:46;s:42:\\\"db279c5e8a92f741984ee8afa7499fac4475000430\\\";i:47;s:42:\\\"5f5694ac20f0646d62181bb86451790a3064046273\\\";i:48;s:42:\\\"37803a0a77e3e9757b1d010ad25316633666240044\\\";i:49;s:42:\\\"45532a255c17e7eff2f052b04a78a34d4190489922\\\";i:50;s:42:\\\"546fda2ea7d70ff2038b3696e2f06b548923552562\\\";i:51;s:42:\\\"f5771d452d59e6fc3079b73702fb3fff3184123347\\\";i:52;s:42:\\\"831f7714b1c69c15ed749e982d0b98cd3368053886\\\";i:53;s:42:\\\"5425d9221c05857f9ec4fa47d42322293016706383\\\";i:54;s:42:\\\"f97a5f11b6e2b856a0610419a58d69707022208558\\\";i:55;s:42:\\\"d8b387781e064edd68cceb182cf64ddf7458615942\\\";i:56;s:42:\\\"a45ee691217bb44d1399129e875ad5c89089049454\\\";i:57;s:42:\\\"f7a046bd1d850369c5a8c7389de5a2829003633416\\\";i:58;s:42:\\\"6fe2697fdb4fe18be46c92f817f158435569669013\\\";i:59;s:42:\\\"82ebd8293263ccd8b0ef78fe2bcbb5ed9980251284\\\";i:60;s:42:\\\"4fc9295b8781cc667b225c6d32b1bd406429372398\\\";i:61;s:42:\\\"7b70c4e1465cd4293fb98daa7b4f1d596544817054\\\";i:62;s:42:\\\"d45cbefe5ed5709c67d62a0c0aea71575202888208\\\";i:63;s:42:\\\"a5b77bbd3b8489c460dfe8e3c90e72133858750169\\\";i:64;s:42:\\\"1ff41d688bdc25385b81a43320f433d08127445717\\\";i:65;s:42:\\\"6a02824a334312655f2ab220fa661b423877135248\\\";i:66;s:42:\\\"75ca48714d45e6c9ea4e0c8bcf90fc0d7222212099\\\";i:67;s:42:\\\"5a6cdb7c768c91fdc3da0cbbe950482c7978549543\\\";i:68;s:42:\\\"608c23d26e4090929165f44b4574a35f6204804110\\\";i:69;s:42:\\\"2fdbc0ec4b6b8797bfe08bde2e7bb74d8158480277\\\";i:70;s:42:\\\"f4b42df1c3083d4422c28638b2c883978158478307\\\";i:71;s:42:\\\"e0c70893be91f4b47d09b2e33557dd2a3109704997\\\";i:72;s:42:\\\"cbc6c4277855e31e01c2fe4a08783bab7363463809\\\";i:73;s:42:\\\"27b810ae467ad19347d4f582ed89ab396956635972\\\";i:74;s:42:\\\"2245da3b180092957fa3bb7b6ad06f766630507496\\\";i:75;s:42:\\\"b1c6f7c01268ffa38118df05265853266870402531\\\";i:76;s:42:\\\"f75a53c64855ff925926956eb924d4067497337076\\\";i:77;s:42:\\\"c776ac4090fa1b3b3dfeae18c2eaa5be5950768087\\\";i:78;s:42:\\\"38526fba1d6afbf4a0989637025d70a19646883856\\\";i:79;s:42:\\\"c188b23298b43ccdb08958dea455e1069122636963\\\";}s:7:\\\"boughtP\\\";a:2:{s:5:\\\"CN305\\\";s:15:\\\"mg-repeat-order\\\";s:7:\\\"PLUG227\\\";s:10:\\\"mg-gallery\\\";}s:6:\\\"trials\\\";a:1:{s:9:\\\"back-ring\\\";i:1726813977;}s:3:\\\"key\\\";s:32:\\\"9986a88009acd1578cf2cb8243e5dc2d\\\";}","N",""),
("298","mpUpdate","cIouNxvdhrBKOfgUDSSjUXfTKyrsSVUtfLKjrXSTUyfsKr","N",""),
("299","notifInfo","","N",""),
("314","updateDowntime","false","N",""),
("316","maxDbVersion","1","N",""),
("372","isFirstStartHelperTemplate","1","N",""),
("373","userDefinedTemplateColors","a:1:{s:7:\\\"flowers\\\";a:19:{s:10:\\\"main-color\\\";s:7:\\\"#c56689\\\";s:15:\\\"secondary-color\\\";s:7:\\\"#7d3e6f\\\";s:15:\\\"main-text-color\\\";s:7:\\\"#494949\\\";s:16:\\\"background-color\\\";s:7:\\\"#f8f8f8\\\";s:22:\\\"third-background-color\\\";s:7:\\\"#4854a2\\\";s:17:\\\"button-background\\\";s:7:\\\"#f8f8f8\\\";s:15:\\\"hover-btn-color\\\";s:7:\\\"#d2d2d2\\\";s:11:\\\"icons-color\\\";s:7:\\\"#AAADB2\\\";s:17:\\\"second-text-color\\\";s:7:\\\"#898d94\\\";s:16:\\\"third-text-color\\\";s:7:\\\"#696161\\\";s:16:\\\"light-text-color\\\";s:4:\\\"#fff\\\";s:22:\\\"background-sticker-new\\\";s:7:\\\"#2ecc71\\\";s:22:\\\"background-sticker-hit\\\";s:7:\\\"#f39c12\\\";s:23:\\\"background-sticker-sale\\\";s:7:\\\"#9bd050\\\";s:23:\\\"background-sticker-code\\\";s:7:\\\"#fdf2cc\\\";s:29:\\\"background-sticker-product-in\\\";s:7:\\\"#dbf5ce\\\";s:30:\\\"background-sticker-product-out\\\";s:7:\\\"#ffe0e0\\\";s:17:\\\"main-border-color\\\";s:7:\\\"#dadada\\\";s:19:\\\"accent-border-color\\\";s:7:\\\"#f39c12\\\";}}","N",""),
("666","customBackground","","N",""),
("667","bgfullscreen","false","N",""),
("668","customAdminLogo","","N",""),
("1374","registrationMethod","email","Y","REGISTRATION_METHOD"),
("1375","oldPricedOnSalePageOnly","false","Y","OLD_PRICED_ON_SALE_PAGE_ONLY"),
("1452","wholesalesGroup","a:20:{i:0;i:1;i:1;i:2;i:2;i:3;i:3;i:4;i:4;i:5;i:5;i:6;i:6;i:7;i:7;i:8;i:8;i:9;i:9;i:10;i:10;i:11;i:11;i:12;i:12;i:13;i:13;i:14;i:14;i:15;i:15;i:16;i:16;i:17;i:17;i:18;i:18;i:19;i:19;i:20;}","N",""),
("1476","op1c","a:20:{i:1;s:39:\\\"Типовое соглашение к1\\\";i:2;s:39:\\\"Типовое соглашение к2\\\";i:3;s:39:\\\"Типовое соглашение к3\\\";i:4;s:39:\\\"Типовое соглашение к4\\\";i:5;s:39:\\\"Типовое соглашение к5\\\";i:6;s:39:\\\"Типовое соглашение к6\\\";i:7;s:39:\\\"Типовое соглашение к7\\\";i:8;s:39:\\\"Типовое соглашение к8\\\";i:9;s:39:\\\"Типовое соглашение к9\\\";i:10;s:40:\\\"Типовое соглашение к10\\\";i:11;s:40:\\\"Типовое соглашение к11\\\";i:12;s:40:\\\"Типовое соглашение к12\\\";i:13;s:40:\\\"Типовое соглашение к13\\\";i:14;s:40:\\\"Типовое соглашение к14\\\";i:15;s:40:\\\"Типовое соглашение к15\\\";i:16;s:40:\\\"Типовое соглашение к16\\\";i:17;s:40:\\\"Типовое соглашение к17\\\";i:18;s:40:\\\"Типовое соглашение к18\\\";i:19;s:40:\\\"Типовое соглашение к19\\\";i:20;s:40:\\\"Типовое соглашение к20\\\";}","N",""),
("1477","op1cPrice","a:20:{i:1;s:9:\\\"fromPrice\\\";i:2;s:9:\\\"fromPrice\\\";i:3;s:9:\\\"fromPrice\\\";i:4;s:9:\\\"fromPrice\\\";i:5;s:9:\\\"fromPrice\\\";i:6;s:9:\\\"fromPrice\\\";i:7;s:9:\\\"fromPrice\\\";i:8;s:9:\\\"fromPrice\\\";i:9;s:9:\\\"fromPrice\\\";i:10;s:9:\\\"fromPrice\\\";i:11;s:9:\\\"fromPrice\\\";i:12;s:9:\\\"fromPrice\\\";i:13;s:9:\\\"fromPrice\\\";i:14;s:9:\\\"fromPrice\\\";i:15;s:9:\\\"fromPrice\\\";i:16;s:9:\\\"fromPrice\\\";i:17;s:9:\\\"fromPrice\\\";i:18;s:9:\\\"fromPrice\\\";i:19;s:9:\\\"fromPrice\\\";i:20;s:9:\\\"fromPrice\\\";}","N",""),
("1478","op1cPriceWholesales","a:19:{i:1;a:2:{s:5:\\\"count\\\";i:1;s:5:\\\"group\\\";s:1:\\\"1\\\";}i:2;a:2:{s:5:\\\"count\\\";i:1;s:5:\\\"group\\\";s:1:\\\"2\\\";}i:3;a:2:{s:5:\\\"count\\\";i:1;s:5:\\\"group\\\";s:1:\\\"3\\\";}i:4;a:2:{s:5:\\\"count\\\";i:1;s:5:\\\"group\\\";s:1:\\\"4\\\";}i:6;a:2:{s:5:\\\"count\\\";i:1;s:5:\\\"group\\\";s:1:\\\"6\\\";}i:7;a:2:{s:5:\\\"count\\\";i:1;s:5:\\\"group\\\";s:1:\\\"7\\\";}i:8;a:2:{s:5:\\\"count\\\";i:1;s:5:\\\"group\\\";s:1:\\\"8\\\";}i:9;a:2:{s:5:\\\"count\\\";i:1;s:5:\\\"group\\\";s:1:\\\"9\\\";}i:10;a:2:{s:5:\\\"count\\\";i:1;s:5:\\\"group\\\";s:2:\\\"10\\\";}i:11;a:2:{s:5:\\\"count\\\";i:1;s:5:\\\"group\\\";s:2:\\\"11\\\";}i:12;a:2:{s:5:\\\"count\\\";i:1;s:5:\\\"group\\\";s:2:\\\"12\\\";}i:13;a:2:{s:5:\\\"count\\\";i:1;s:5:\\\"group\\\";s:2:\\\"13\\\";}i:14;a:2:{s:5:\\\"count\\\";i:1;s:5:\\\"group\\\";s:2:\\\"14\\\";}i:15;a:2:{s:5:\\\"count\\\";i:1;s:5:\\\"group\\\";s:2:\\\"15\\\";}i:16;a:2:{s:5:\\\"count\\\";i:1;s:5:\\\"group\\\";s:2:\\\"16\\\";}i:17;a:2:{s:5:\\\"count\\\";i:1;s:5:\\\"group\\\";s:2:\\\"17\\\";}i:18;a:2:{s:5:\\\"count\\\";i:1;s:5:\\\"group\\\";s:2:\\\"18\\\";}i:19;a:2:{s:5:\\\"count\\\";i:1;s:5:\\\"group\\\";s:2:\\\"19\\\";}i:20;a:2:{s:5:\\\"count\\\";i:1;s:5:\\\"group\\\";s:2:\\\"20\\\";}}","N","");
DROP TABLE IF EXISTS `mg_all_galleries`;

CREATE TABLE `mg_all_galleries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gal_name` varchar(255) NOT NULL,
  `height` mediumtext NOT NULL,
  `in_line` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;


INSERT INTO `mg_all_galleries` VALUES
("1","Каталог 1","150","3"),
("2","Каталог 2","150","3");
DROP TABLE IF EXISTS `mg_avito_cats`;

CREATE TABLE `mg_avito_cats` (
  `id` int(255) NOT NULL,
  `name` varchar(249) NOT NULL,
  `parent_id` int(255) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_avito_locations`;

CREATE TABLE `mg_avito_locations` (
  `id` int(255) NOT NULL,
  `name` varchar(249) NOT NULL,
  `type` int(5) NOT NULL,
  `parent_id` int(255) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_avito_settings`;

CREATE TABLE `mg_avito_settings` (
  `name` varchar(191) NOT NULL,
  `settings` longtext NOT NULL,
  `cats` longtext NOT NULL,
  `additional` longtext NOT NULL,
  `edited` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `custom_options` longtext,
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_cache`;

CREATE TABLE `mg_cache` (
  `date_add` int(11) NOT NULL,
  `lifetime` int(11) NOT NULL,
  `name` varchar(191) NOT NULL,
  `value` longtext NOT NULL,
  UNIQUE KEY `name` (`name`),
  KEY `name_2` (`name`),
  KEY `date_add` (`date_add`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_category`;

CREATE TABLE `mg_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `left_key` int(11) NOT NULL DEFAULT '1',
  `right_key` int(11) NOT NULL DEFAULT '1',
  `level` int(11) NOT NULL DEFAULT '2',
  `title` varchar(249) DEFAULT NULL,
  `menu_title` varchar(249) NOT NULL DEFAULT '',
  `url` varchar(191) DEFAULT NULL,
  `parent` int(11) NOT NULL,
  `parent_url` varchar(191) NOT NULL,
  `sort` int(11) DEFAULT NULL,
  `html_content` longtext,
  `meta_title` text,
  `meta_keywords` text,
  `meta_desc` text,
  `invisible` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'Не выводить в меню',
  `1c_id` varchar(191) DEFAULT NULL,
  `image_url` text,
  `menu_icon` text,
  `rate` double NOT NULL DEFAULT '0',
  `export` tinyint(1) NOT NULL DEFAULT '1',
  `seo_content` text,
  `activity` tinyint(1) NOT NULL DEFAULT '1',
  `unit` varchar(249) NOT NULL DEFAULT 'шт.',
  `seo_alt` text,
  `seo_title` text,
  `menu_seo_alt` text,
  `menu_seo_title` text,
  `countProduct` int(11) NOT NULL DEFAULT '0',
  `weight_unit` varchar(10) NOT NULL DEFAULT 'kg',
  PRIMARY KEY (`id`),
  KEY `1c_id` (`1c_id`),
  KEY `url` (`url`),
  KEY `parent_url` (`parent_url`),
  KEY `id` (`id`),
  KEY `left_key` (`left_key`),
  KEY `right_key` (`right_key`),
  KEY `level` (`level`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;


INSERT INTO `mg_category` VALUES
("1","2","3","1","Одноголовые","","odnogolovye","0","","1","","Одноголовые","","","0","","","","0","1","","1","","","","","","0",""),
("2","4","5","1","Кустовые","","kustovye","0","","2","","Кустовые","","","0","","","","0","1","","1","","","","","","0",""),
("3","6","7","1","Садовые","","sadovye","0","","3","","Садовые","","","0","","","","0","1","","1","","","","","","0","");
DROP TABLE IF EXISTS `mg_category_opt_fields`;

CREATE TABLE `mg_category_opt_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(249) NOT NULL,
  `sort` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_category_opt_fields_content`;

CREATE TABLE `mg_category_opt_fields_content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `field_id` int(11) NOT NULL DEFAULT '0',
  `category_id` int(11) NOT NULL DEFAULT '0',
  `value` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_category_user_property`;

CREATE TABLE `mg_category_user_property` (
  `category_id` int(11) NOT NULL,
  `property_id` int(11) NOT NULL,
  KEY `category_id` (`category_id`),
  KEY `property_id` (`property_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


INSERT INTO `mg_category_user_property` VALUES
("1","1"),
("2","1"),
("3","1"),
("1","2"),
("2","2"),
("3","2"),
("1","3"),
("2","3"),
("3","3"),
("1","4"),
("2","4"),
("3","4");
DROP TABLE IF EXISTS `mg_comments`;

CREATE TABLE `mg_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `comment` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `uri` varchar(249) NOT NULL,
  `approved` tinyint(4) NOT NULL DEFAULT '0',
  `img` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_delivery`;

CREATE TABLE `mg_delivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(249) NOT NULL,
  `description_public` text,
  `cost` double DEFAULT NULL,
  `description` text,
  `activity` int(1) NOT NULL DEFAULT '0',
  `free` double DEFAULT NULL COMMENT 'Бесплатно от',
  `date` int(1) DEFAULT NULL,
  `date_settings` text,
  `sort` int(11) DEFAULT NULL,
  `plugin` varchar(249) DEFAULT NULL,
  `weight` longtext,
  `interval` longtext,
  `address_parts` int(1) NOT NULL DEFAULT '0',
  `show_storages` varchar(249) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COMMENT='таблица способов доставки товара';


INSERT INTO `mg_delivery` VALUES
("1","Курьер","","700","Курьерская служба","1","0","1","{\"dateShift\":0,\"daysWeek\":{\"md\":true,\"tu\":true,\"we\":true,\"thu\":true,\"fri\":true,\"sa\":true,\"su\":true},\"monthWeek\":{\"jan\":\"\",\"feb\":\"\",\"mar\":\"\",\"aip\":\"\",\"may\":\"\",\"jum\":\"\",\"jul\":\"\",\"aug\":\"\",\"sep\":\"\",\"okt\":\"\",\"nov\":\"\",\"dec\":\"\"}}","1","","","","0","0"),
("2","Почта","","200","Почта России","1","0","0","{\"dateShift\":0,\"daysWeek\":{\"md\":true,\"tu\":true,\"we\":true,\"thu\":true,\"fri\":true,\"sa\":true,\"su\":true},\"monthWeek\":{\"jan\":\"\",\"feb\":\"\",\"mar\":\"\",\"aip\":\"\",\"may\":\"\",\"jum\":\"\",\"jul\":\"\",\"aug\":\"\",\"sep\":\"\",\"okt\":\"\",\"nov\":\"\",\"dec\":\"\"}}","2","","","","0","0"),
("3","Без доставки","","0","Самовывоз","1","0","0","{\"dateShift\":0,\"daysWeek\":{\"md\":true,\"tu\":true,\"we\":true,\"thu\":true,\"fri\":true,\"sa\":true,\"su\":true},\"monthWeek\":{\"jan\":\"\",\"feb\":\"\",\"mar\":\"\",\"aip\":\"\",\"may\":\"\",\"jum\":\"\",\"jul\":\"\",\"aug\":\"\",\"sep\":\"\",\"okt\":\"\",\"nov\":\"\",\"dec\":\"\"}}","3","","","","0","0");
DROP TABLE IF EXISTS `mg_delivery_payment_compare`;

CREATE TABLE `mg_delivery_payment_compare` (
  `payment_id` int(10) DEFAULT NULL,
  `delivery_id` int(10) DEFAULT NULL,
  `compare` int(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


INSERT INTO `mg_delivery_payment_compare` VALUES
("1","1","1"),
("5","1","1"),
("2","2","1"),
("3","1","1"),
("1","2","1"),
("2","1","1"),
("3","2","1"),
("4","2","1"),
("4","3","1"),
("3","3","1"),
("2","3","1"),
("1","3","1"),
("4","1","1"),
("5","2","1"),
("6","1","1"),
("6","2","1"),
("6","3","1"),
("5","3","1"),
("7","1","1"),
("7","2","1"),
("7","3","1"),
("8","1","1"),
("8","2","1"),
("8","3","1"),
("9","1","1"),
("9","2","1"),
("9","3","1"),
("10","1","1"),
("10","2","1"),
("10","3","1"),
("1001","1","1"),
("1001","2","1"),
("1001","3","1"),
("1002","1","1"),
("1002","2","1"),
("1002","3","1"),
("1003","1","1"),
("1003","2","1"),
("1003","3","1");
DROP TABLE IF EXISTS `mg_galleries_img`;

CREATE TABLE `mg_galleries_img` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_gal` int(11) NOT NULL,
  `image_url` mediumtext NOT NULL,
  `alt` mediumtext NOT NULL,
  `title` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8mb4;


INSERT INTO `mg_galleries_img` VALUES
("5","2","/uploads/gallery/2/01.jpg","1",""),
("6","2","/uploads/gallery/2/02.jpg","5",""),
("7","2","/uploads/gallery/2/03.jpg","10",""),
("8","2","/uploads/gallery/2/04.jpg","15",""),
("9","2","/uploads/gallery/2/05.jpg","20",""),
("10","2","/uploads/gallery/2/06.jpg","25",""),
("11","2","/uploads/gallery/2/07.jpg","25",""),
("12","2","/uploads/gallery/2/08.jpg","30",""),
("13","2","/uploads/gallery/2/09.jpg","30",""),
("14","2","/uploads/gallery/2/10.jpg","35",""),
("15","2","/uploads/gallery/2/11.jpg","40",""),
("16","2","/uploads/gallery/2/12.jpg","45",""),
("17","2","/uploads/gallery/2/13.jpg","50",""),
("18","2","/uploads/gallery/2/14.jpg","55",""),
("19","2","/uploads/gallery/2/15.jpg","60",""),
("20","2","/uploads/gallery/2/16.jpg","65",""),
("21","2","/uploads/gallery/2/17.jpg","70",""),
("22","2","/uploads/gallery/2/18.jpg","75",""),
("23","2","/uploads/gallery/2/19.jpg","80",""),
("24","2","/uploads/gallery/2/20.jpg","85",""),
("27","2","/uploads/gallery/2/23.jpg","95",""),
("28","2","/uploads/gallery/2/24.jpg","100",""),
("29","2","/uploads/gallery/2/25.jpg","105",""),
("30","2","/uploads/gallery/2/26.jpg","110",""),
("33","2","/uploads/gallery/2/29.jpg","115",""),
("34","2","/uploads/gallery/2/30.jpg","120",""),
("35","2","/uploads/gallery/2/31.jpg","125",""),
("36","2","/uploads/gallery/2/32.jpg","130",""),
("37","2","/uploads/gallery/2/33.jpg","135",""),
("38","2","/uploads/gallery/2/34.jpg","140",""),
("39","2","/uploads/gallery/2/35.jpg","145",""),
("40","2","/uploads/gallery/2/36.jpg","150",""),
("41","2","/uploads/gallery/2/37.jpg","155",""),
("42","2","/uploads/gallery/2/38.jpg","160",""),
("43","2","/uploads/gallery/2/39.jpg","165",""),
("44","2","/uploads/gallery/2/40.jpg","170",""),
("45","2","/uploads/gallery/2/41.jpg","175",""),
("46","2","/uploads/gallery/2/42.jpg","180",""),
("47","2","/uploads/gallery/2/43.jpg","185",""),
("48","2","/uploads/gallery/2/44.jpg","190",""),
("49","2","/uploads/gallery/2/45.jpg","195",""),
("50","2","/uploads/gallery/2/46.jpg","200",""),
("51","2","/uploads/gallery/2/47.jpg","205",""),
("52","2","/uploads/gallery/2/48.jpg","210",""),
("53","1","/uploads/gallery/1/03.jpg","1",""),
("56","1","/uploads/gallery/1/02.jpg","5",""),
("57","1","/uploads/gallery/1/01.jpg","10",""),
("58","1","/uploads/gallery/1/04.jpg","15",""),
("59","1","/uploads/gallery/1/05.jpg","20",""),
("60","1","/uploads/gallery/1/06.jpg","25",""),
("61","1","/uploads/gallery/1/07.jpg","30",""),
("62","1","/uploads/gallery/1/08.jpg","35",""),
("63","1","/uploads/gallery/1/09.jpg","40",""),
("64","1","/uploads/gallery/1/10.jpg","45",""),
("65","1","/uploads/gallery/1/11.jpg","50",""),
("66","1","/uploads/gallery/1/12.jpg","55",""),
("67","1","/uploads/gallery/1/13.jpg","60",""),
("68","1","/uploads/gallery/1/14.jpg","65",""),
("69","1","/uploads/gallery/1/15.jpg","70",""),
("70","1","/uploads/gallery/1/16.jpg","75",""),
("71","1","/uploads/gallery/1/17.jpg","80",""),
("72","1","/uploads/gallery/1/18.jpg","85",""),
("73","1","/uploads/gallery/1/19.jpg","90",""),
("74","1","/uploads/gallery/1/20.jpg","95","");
DROP TABLE IF EXISTS `mg_googlemerchant`;

CREATE TABLE `mg_googlemerchant` (
  `name` varchar(191) NOT NULL,
  `settings` longtext NOT NULL,
  `cats` longtext NOT NULL,
  `edited` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_googlemerchantcats`;

CREATE TABLE `mg_googlemerchantcats` (
  `id` int(255) NOT NULL,
  `name` varchar(249) NOT NULL,
  `parent_id` int(255) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_import_yml_core_cats`;

CREATE TABLE `mg_import_yml_core_cats` (
  `id` int(11) DEFAULT NULL,
  `parentId` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `mg_import_yml_core_images`;

CREATE TABLE `mg_import_yml_core_images` (
  `id` int(11) DEFAULT NULL,
  `images` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `mg_landings`;

CREATE TABLE `mg_landings` (
  `id` int(11) NOT NULL,
  `template` varchar(249) CHARACTER SET utf8 DEFAULT NULL,
  `templateColor` varchar(6) CHARACTER SET utf8 DEFAULT NULL,
  `ytp` longtext CHARACTER SET utf8,
  `image` varchar(249) CHARACTER SET utf8 DEFAULT NULL,
  `buySwitch` varchar(6) CHARACTER SET utf8 DEFAULT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_letters`;

CREATE TABLE `mg_letters` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content` mediumtext NOT NULL,
  `lang` varchar(50) DEFAULT 'default',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4;


INSERT INTO `mg_letters` VALUES
("1","email_feedback.php","<h1 style=\'margin: 0 0 10px 0; font-size: 16px;padding: 0;\'>Сообщение с формы обратной связи!</h1><p style=\'padding: 0;margin: 10px 0;font-size: 12px;\'>Пользователь <strong>{userName}</strong> с почтовым ящиком <strong>{userEmail}</strong>, телефон: {userPhone}, пишет:</p><div style=\'margin: 0;padding: 10px;background: #FFF5B5; font-weight: bold;\'>{message}</div>","default"),
("2","email_forgot.php","<h1 style=\"margin: 0 0 10px 0; font-size: 16px;padding: 0;\">Здравствуйте!</h1><p style=\"padding: 0;margin: 10px 0;font-size: 12px;\">Вы зарегистрированы на сайте <strong>{siteName}</strong> с логином <strong>{userEmail}</strong></p><p style=\"padding: 0;margin: 10px 0;font-size: 12px;\">Для восстановления пароля пройдите по ссылке</p><div style=\"margin: 0;padding: 10px;background: #FFF5B5; font-weight: bold; text-align: center;\"><a href=\"{link}\" target=\"blank\"> {link} </a></div><p style=\"padding: 0;margin: 10px 0;font-size: 12px;\">Если Вы не делали запрос на восстановление пароля, то проигнорируйте это письмо.</p><p style=\"padding: 0;margin: 10px 0;font-size: 10px; color: #555; font-weight: bold;\">Отвечать на данное сообщение не нужно.</p>","default"),
("3","email_order.php","<table bgcolor=\"#FFFFFF\" cellspacing=\"0\" cellpadding=\"10\" border=\"0\" width=\"675\"><tbody><tr><td valign=\"top\"><h1 style=\"margin: 0 0 10px 0; font-size: 16px;padding: 0;\">Здравствуйте, {fullName}!</h1><div style=\"font-size:12px;line-height:16px;margin:0;\">Ваш заказ <b>№{orderNumber}</b> успешно оформлен.<p class=\"confirm-info\" style=\"font-size:12px;margin:0 0 10px 0\"><br>Перейдите по {confirmLink} для подтверждения заказа.<br><br>Следить за статусом заказа вы можете в <a href=\"{personal}\" style=\"color:#1E7EC8;\" target=\"_blank\">личном кабинете</a>.</p><br>Если у Вас возникнут вопросы — их можно задать по почте: <a href=\"mailto:{adminEmail}\" style=\"color:#1E7EC8;\" target=\"_blank\">{adminEmail}</a> или по телефону: <span><span class=\"js-phone-number highlight-phone\">{shopPhone}</span></span></div></td></tr></tbody></table>{tableOrder}","default"),
("4","email_order_change_status.php","<p style=\"font-size:12px;line-height:16px;margin:0;\">Здравствуйте, <b>{buyerName}</b>!<br/> Статус Вашего заказа <b>№{orderInfo}</b> был изменен c \"<b>{oldStatus}</b>\" на \"<b>{newStatus}</b>\".<br/>{managerComment}<br/>Следить за состоянием заказа Вы можете в <a href=\"{personal}\">личном кабинете</a>.</p>","default"),
("5","email_order_electro.php","<p style=\"font-size:12px;line-height:16px;margin:0;\">Ваш заказ <b>№{orderNumber}</b> содержит электронные товары, которые можно скачать по следующей ссылке:<br/> <a href=\"{getElectro}\">{getElectro}</a></p>","default"),
("6","email_order_new_user.php","<table bgcolor=\"#FFFFFF\" cellspacing=\"0\" cellpadding=\"10\" border=\"0\" width=\"675\"><tbody><tr><td valign=\"top\"><h1 style=\"margin: 0 0 10px 0; font-size: 16px;padding: 0;\">Здравствуйте, {fullName}!</h1><div style=\"font-size:12px;line-height:16px;margin:0;\"><br>Мы создали для вас <a href=\"{personal}\" style=\"color:#1E7EC8;\" target=\"_blank\">личный кабинет</a>, чтобы вы могли следить за статусом заказа, а также скачивать оплаченные электронные товары.<br><br><b>Ваш логин:</b> {userEmail}<br><b>Ваш пароль:</b> {pass}<br><b>Ссылка для подтверждения регистрации:</b>{link}</div></td></tr></tbody></table>","default"),
("7","email_order_paid.php","<p style=\"font-size:12px;line-height:16px;margin:0;\">Вы получили это письмо, так как произведена оплата заказа №{orderNumber} на сумму {summ}. Оплата произведена при помощи {payment} <br/>Статус заказа сменен на \"{status} \"</p>","default"),
("9","email_registry.php","<h1 style=\"margin: 0 0 10px 0; font-size: 16px;padding: 0;\">Здравствуйте!</h1><p style=\"padding: 0;margin: 10px 0;font-size: 12px;\">Вы получили данное письмо так как зарегистрировались на сайте <strong>{siteName}</strong> с логином <strong>{userEmail}</strong></p><p style=\"padding: 0;margin: 10px 0;font-size: 12px;\">Для активации пользователя и возможности пользоваться личным кабинетом пройдите по ссылке:</p><div style=\"margin: 0;padding: 10px;background: #FFF5B5; font-weight: bold; text-align: center;\">{link}</div><p style=\"padding: 0;margin: 10px 0;font-size: 10px; color: #555; font-weight: bold;\">Отвечать на данное сообщение не нужно.</p>","default"),
("10","email_registry_independent.php","<h1 style=\"margin: 0 0 10px 0; font-size: 16px;padding: 0;\">Здравствуйте!</h1><p style=\"padding: 0;margin: 10px 0;font-size: 12px;\">Вы получили данное письмо так как на сайте <strong>{siteName} </strong> зарегистрирован новый пользователь с логином <strong>{userEmail}</strong></p><p style=\"padding: 0;margin: 10px 0;font-size: 10px; color: #555; font-weight: bold;\">Отвечать на данное сообщение не нужно.</p>","default"),
("11","email_unclockauth.php","<h1 style=\"margin: 0 0 10px 0; font-size: 16px;padding: 0;\">Подбор паролей на сайте {siteName} предотвращен!</h1><p style=\"padding: 0;margin: 10px 0;font-size: 12px;\">Система защиты от перебора паролей для авторизации зафиксировала активность. С IP адреса {IP} было введено более 5 неверных паролей. Последний email: <strong>{lastEmail}</strong> Пользователь вновь сможет ввести пароль через 15 минут.</p><p style=\"padding: 0;margin: 10px 0;font-size: 12px;\">Если 5 неправильных попыток авторизации были инициированы администратором,то для снятия блокировки перейдите по ссылке</p><div style=\"margin: 0;padding: 10px;background: #FFF5B5; font-weight: bold; text-align: center;\">{link}</div><p style=\"padding: 0;margin: 10px 0;font-size: 10px; color: #555; font-weight: bold;\">Отвечать на данное сообщение не нужно.</p>","default");
DROP TABLE IF EXISTS `mg_locales`;

CREATE TABLE `mg_locales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_ent` int(11) NOT NULL,
  `locale` varchar(249) CHARACTER SET utf8 NOT NULL,
  `table` varchar(249) CHARACTER SET utf8 NOT NULL,
  `field` varchar(249) CHARACTER SET utf8 NOT NULL,
  `text` longtext CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `id_ent` (`id_ent`),
  KEY `locale` (`locale`),
  KEY `table` (`table`),
  KEY `field` (`field`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_logs_ajax`;

CREATE TABLE `mg_logs_ajax` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ajax` text NOT NULL COMMENT 'Запрос, в котором данные, кроме данных для роутинга, заменены на _sql_',
  `action` varchar(256) NOT NULL,
  `actioner` varchar(256) NOT NULL,
  `handler` varchar(256) NOT NULL,
  `mguniqueurl` varchar(256) NOT NULL,
  `params` text NOT NULL COMMENT 'Часть запроса с данными, без данных о роутинге',
  `example` text NOT NULL COMMENT 'Исходный запрос со всеми данными',
  `controller` varchar(32) NOT NULL COMMENT 'ajax или ajaxRequest',
  `requestType` varchar(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `mg_messages`;

CREATE TABLE `mg_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(249) NOT NULL,
  `text` text NOT NULL,
  `text_original` text NOT NULL,
  `group` varchar(249) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=utf8mb4;


INSERT INTO `mg_messages` VALUES
("1","msg__order_denied","Для просмотра страницы необходимо зайти на сайт под пользователем сделавшим заказ №#NUMBER#.","Для просмотра страницы необходимо зайти на сайт под пользователем сделавшим заказ №#NUMBER#.","order"),
("2","msg__no_electro","Заказ не содержит электронных товаров или ожидает оплаты!","Заказ не содержит электронных товаров или ожидает оплаты!","order"),
("3","msg__electro_download","Скачать электронные товары для заказа №#NUMBER#.","Скачать электронные товары для заказа №#NUMBER#.","order"),
("4","msg__view_status","Посмотреть статус заказа Вы можете в <a href=\"#LINK#\">личном кабинете</a>.","Посмотреть статус заказа Вы можете в <a href=\"#LINK#\">личном кабинете</a>.","order"),
("5","msg__order_not_found","Некорректная ссылка.<br> Заказ не найден.<br>","Некорректная ссылка.<br> Заказ не найден.<br>","order"),
("6","msg__view_order","Следить за статусом заказа Вы можете по ссылке<br><a href=\"#LINK#\">#LINK#</a>.","Следить за статусом заказа Вы можете по ссылке<br><a href=\"#LINK#\">#LINK#</a>.","order"),
("7","msg__order_confirmed","Ваш заказ №#NUMBER# подтвержден и передан на обработку.<br>","Ваш заказ №#NUMBER# подтвержден и передан на обработку.<br>","order"),
("8","msg__order_processing","Заказ уже подтвержден и находится в работе.<br>","Заказ уже подтвержден и находится в работе.<br>","order"),
("9","msg__order_not_confirmed","Некорректная ссылка.<br>Заказ не подтвержден.<br>","Некорректная ссылка.<br>Заказ не подтвержден.<br>","order"),
("10","msg__email_in_use","Пользователь с таким email существует. Пожалуйста, <a href=\"#LINK#\">войдите в систему</a> используя свой электронный адрес и пароль!","Пользователь с таким email существует. Пожалуйста, <a href=\"#LINK#\">войдите в систему</a> используя свой электронный адрес и пароль!","order"),
("11","msg__email_incorrect","E-mail введен некорректно!","E-mail введен некорректно!","order"),
("12","msg__phone_incorrect","Введите верный номер телефона!","Введите верный номер телефона!","order"),
("13","msg__payment_incorrect","Выберите способ оплаты!","Выберите способ оплаты!","order"),
("15","msg__product_ended","Товара #PRODUCT# уже нет в наличии. Для оформления заказа его необходимо удалить из корзины.","Товара #PRODUCT# уже нет в наличии. Для оформления заказа его необходимо удалить из корзины.","product"),
("16","msg__product_ending","Товар #PRODUCT# доступен в количестве #COUNT# шт. Для оформления заказа измените количество в корзине.","Товар #PRODUCT# доступен в количестве #COUNT# шт. Для оформления заказа измените количество в корзине.","product"),
("17","msg__no_compare","Нет товаров для сравнения в этой категории.","Нет товаров для сравнения в этой категории.","product"),
("18","msg__product_nonavaiable1","Товара временно нет на складе!<br/><a rel=\"nofollow\" href=\"#LINK#\">Сообщить когда будет в наличии.</a>","Товара временно нет на складе!<br/><a rel=\"nofollow\" href=\"#LINK#\">Сообщить когда будет в наличии.</a>","product"),
("19","msg__product_nonavaiable2","Здравствуйте, меня интересует товар #PRODUCT# с артикулом #CODE#, но его нет в наличии. Сообщите, пожалуйста, о поступлении этого товара на склад. ","Здравствуйте, меня интересует товар #PRODUCT# с артикулом #CODE#, но его нет в наличии. Сообщите, пожалуйста, о поступлении этого товара на склад. ","product"),
("20","msg__enter_failed","Неправильная пара email-пароль! Авторизоваться не удалось.","Неправильная пара email-пароль! Авторизоваться не удалось.","register"),
("21","msg__enter_captcha_failed","Неправильно введен код с картинки! Авторизоваться не удалось. Количество оставшихся попыток - #COUNT#.","Неправильно введен код с картинки! Авторизоваться не удалось. Количество оставшихся попыток - #COUNT#.","register"),
("22","msg__enter_blocked","В целях безопасности возможность авторизации заблокирована на #MINUTES# мин. Отсчет времени от #TIME#.","В целях безопасности возможность авторизации заблокирована на #MINUTES# мин. Отсчет времени от #TIME#.","register"),
("23","msg__enter_field_missing","Одно из обязательных полей не заполнено!","Одно из обязательных полей не заполнено!","register"),
("24","msg__feedback_sent","Ваше сообщение отправлено!","Ваше сообщение отправлено!","feedback"),
("25","msg__feedback_wrong_email","E-mail не существует!","E-mail не существует!","feedback"),
("26","msg__feedback_no_text","Введите текст сообщения!","Введите текст сообщения!","feedback"),
("27","msg__captcha_incorrect","Текст с картинки введен неверно!","Текст с картинки введен неверно!","feedback"),
("28","msg__reg_success_email","Вы успешно зарегистрировались! Для активации пользователя Вам необходимо перейти по ссылке высланной на Ваш электронный адрес <strong>#EMAIL#</strong>","Вы успешно зарегистрировались! Для активации пользователя Вам необходимо перейти по ссылке высланной на Ваш электронный адрес <strong>#EMAIL#</strong>","register"),
("29","msg__reg_success","Вы успешно зарегистрировались! <a href=\"#LINK#\">Вход в личный кабинет</a></strong>","Вы успешно зарегистрировались! <a href=\"#LINK#\">Вход в личный кабинет</a></strong>","register"),
("30","msg__reg_activated","Ваша учетная запись активирована. Теперь Вы можете <a href=\"#LINK#\">войти в личный кабинет</a> используя логин и пароль заданный при регистрации.","Ваша учетная запись активирована. Теперь Вы можете <a href=\"#LINK#\">войти в личный кабинет</a> используя логин и пароль заданный при регистрации.","register"),
("31","msg__reg_wrong_link","Некорректная ссылка. Повторите активацию!","Некорректная ссылка. Повторите активацию!","register"),
("32","msg__reg_link","Для активации пользователя Вам необходимо перейти по ссылке высланной на Ваш электронный адрес #EMAIL#","Для активации пользователя Вам необходимо перейти по ссылке высланной на Ваш электронный адрес #EMAIL#","register"),
("33","msg__wrong_login","К сожалению, такой логин не найден. Если вы уверены, что данный логин существует, свяжитесь, пожалуйста, с нами.","К сожалению, такой логин не найден. Если вы уверены, что данный логин существует, свяжитесь, пожалуйста, с нами.","register"),
("34","msg__reg_email_in_use","Указанный email уже используется.","Указанный email уже используется.","register"),
("35","msg__reg_short_pass","Пароль менее 5 символов.","Пароль менее 5 символов.","register"),
("36","msg__reg_wrong_pass","Введенные пароли не совпадают.","Введенные пароли не совпадают.","register"),
("37","msg__reg_wrong_email","Неверно заполнено поле email","Неверно заполнено поле email","register"),
("38","msg__forgot_restore","Инструкция по восстановлению пароля была отправлена на <strong>#EMAIL#</strong>.","Инструкция по восстановлению пароля была отправлена на <strong>#EMAIL#</strong>.","register"),
("39","msg__forgot_wrong_link","Некорректная ссылка. Повторите заново запрос восстановления пароля.","Некорректная ссылка. Повторите заново запрос восстановления пароля.","register"),
("40","msg__forgot_success","Пароль изменен! Вы можете войти в личный кабинет по адресу <a href=\"#LINK#\">#LINK#</a>","Пароль изменен! Вы можете войти в личный кабинет по адресу <a href=\"#LINK#\">#LINK#</a>","register"),
("41","msg__pers_saved","Данные успешно сохранены","Данные успешно сохранены","register"),
("42","msg__pers_wrong_pass","Неверный пароль","Неверный пароль","register"),
("43","msg__pers_pass_changed","Пароль изменен","Пароль изменен","register"),
("44","msg__recaptcha_incorrect","reCAPTCHA не пройдена!","reCAPTCHA не пройдена!","feedback"),
("45","msg__enter_recaptcha_failed","reCAPTCHA не пройдена! Авторизоваться не удалось. Количество оставшихся попыток - #COUNT#.","reCAPTCHA не пройдена! Авторизоваться не удалось. Количество оставшихся попыток - #COUNT#.","register"),
("46","msg__status_not_confirmed","не подтвержден","не подтвержден","status"),
("47","msg__status_expects_payment","ожидает оплаты","ожидает оплаты","status"),
("48","msg__status_paid","оплачен","оплачен","status"),
("49","msg__status_in_delivery","в доставке","в доставке","status"),
("50","msg__status_canceled","отменен","отменен","status"),
("51","msg__status_executed","выполнен","выполнен","status"),
("52","msg__status_processing","в обработке","в обработке","status"),
("53","msg__payment_inn","Заполните ИНН","Заполните ИНН","order"),
("54","msg__payment_required","Заполнены не все обязательные поля","Заполнены не все обязательные поля","order"),
("55","msg__storage_non_selected","Склад не выбран!","Склад не выбран!","order"),
("56","msg__pers_data_fail","Не удалось сохранить данные","Не удалось сохранить данные","register"),
("57","msg__reg_phone_in_use","Номер телефона указан неверно или уже используется","Номер телефона указан неверно или уже используется","register"),
("58","msg__reg_wrong_login","Неверно заполнен E-mail или номер телефона","Неверно заполнен E-mail или номер телефона","register"),
("59","msg__pers_phone_add","Номер телефона был успешно добавлен","Номер телефона был успешно добавлен","register"),
("60","msg__pers_phone_confirm","Номер телефона был успешно подтвержден. Теперь Вы можете войти в личный кабинет используя номер телефона и пароль заданный при регистрации.","Номер телефона был успешно подтвержден. Теперь Вы можете войти в личный кабинет используя номер телефона и пароль заданный при регистрации.","register"),
("61","msg__reg_not_sms","Сервис отправки SMS временно не доступен. Зарегистрируйтесь используя email, либо свяжитесь с нами.","Сервис отправки SMS временно не доступен. Зарегистрируйтесь используя E-mail, или свяжитесь с нами.","register"),
("62","msg__reg_sms_resend","Код подтверждения повторно отправлен на номер","Код подтверждения повторно отправлен на номер","register"),
("63","msg__reg_sms_errore","Неверный код подтверждения","Неверный код подтверждения","register"),
("64","msg__reg_not_sms_confirm","Сервис отправки SMS временно не доступен. Повторите попытку позже, либо свяжитесь с нами.","Сервис отправки SMS временно не доступен. Повторите попытку позже, либо свяжитесь с нами.","register"),
("65","msg__reg_wrong_link_sms","Некорректная ссылка. Повторите попытку позже, либо свяжитесь с нами.","Некорректная ссылка. Повторите попытку позже, либо свяжитесь с нами.","register"),
("66","msg__reg_blocked_email","Указанный E-mail запрещён администратором!","Указанный E-mail запрещён администратором!","register"),
("67","msg__products_not_same_storage","Невозможно собрать заказ с одного склада","Невозможно собрать заказ с одного склада","order");
DROP TABLE IF EXISTS `mg_mg-brand`;

CREATE TABLE `mg_mg-brand` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Порядковый номер записи',
  `data_id` int(11) NOT NULL COMMENT 'Номер в таблице характеристик',
  `brand` text NOT NULL COMMENT 'Бренд',
  `url` text NOT NULL COMMENT 'Логотип',
  `img_alt` text NOT NULL COMMENT 'alt',
  `img_title` text NOT NULL COMMENT 'title',
  `desc` text NOT NULL COMMENT 'Описание',
  `short_url` text NOT NULL COMMENT 'Короткая ссылка',
  `full_url` text NOT NULL COMMENT 'Полная ссылка',
  `add_datetime` datetime NOT NULL COMMENT 'Дата добавления',
  `seo_title` text NOT NULL COMMENT '(SEO) Название',
  `seo_keywords` text NOT NULL COMMENT '(SEO) Ключевые слова',
  `seo_desc` text NOT NULL COMMENT '(SEO) Описание',
  `cat_desc_seo` text NOT NULL COMMENT 'Описание для SEO',
  `invisible` int(1) NOT NULL COMMENT 'Видимость',
  `sort` int(11) NOT NULL COMMENT 'Сортировка',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_mg-slider`;

CREATE TABLE `mg_mg-slider` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Порядковый номер слайдера',
  `name_slider` text NOT NULL COMMENT 'Название слайдера',
  `slides` text NOT NULL COMMENT 'Содержимое слайдов',
  `options` text NOT NULL COMMENT 'Настройки сладера',
  `invisible` int(1) NOT NULL DEFAULT '0' COMMENT 'видимость',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_notification`;

CREATE TABLE `mg_notification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `message` longtext NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_order`;

CREATE TABLE `mg_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `owner` int(11) NOT NULL DEFAULT '0',
  `updata_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `add_date` timestamp NULL DEFAULT NULL,
  `close_date` timestamp NULL DEFAULT NULL,
  `pay_date` timestamp NULL DEFAULT NULL,
  `user_email` varchar(191) DEFAULT NULL,
  `contact_email` varchar(249) DEFAULT NULL,
  `phone` varchar(249) DEFAULT NULL,
  `address` text,
  `address_parts` text,
  `summ` varchar(249) DEFAULT NULL COMMENT 'Общая сумма товаров в заказе ',
  `order_content` longtext,
  `delivery_id` int(11) unsigned DEFAULT NULL,
  `delivery_cost` double DEFAULT NULL COMMENT 'Стоимость доставки',
  `delivery_interval` text,
  `delivery_options` text,
  `payment_id` int(11) DEFAULT NULL,
  `paided` int(1) NOT NULL DEFAULT '0',
  `approve_payment` int(1) NOT NULL DEFAULT '0',
  `status_id` int(11) DEFAULT NULL,
  `user_comment` text,
  `comment` text,
  `confirmation` varchar(249) DEFAULT NULL,
  `yur_info` text NOT NULL,
  `name_buyer` text NOT NULL,
  `name_parts` text,
  `date_delivery` text,
  `ip` text NOT NULL,
  `number` varchar(32) DEFAULT NULL,
  `hash` varchar(32) DEFAULT NULL,
  `1c_last_export` timestamp NULL DEFAULT NULL,
  `orders_set` int(11) DEFAULT NULL,
  `storage` text NOT NULL,
  `summ_shop_curr` double DEFAULT NULL,
  `delivery_shop_curr` double DEFAULT NULL,
  `currency_iso` varchar(249) DEFAULT NULL,
  `utm_source` text,
  `utm_medium` text,
  `utm_campaign` text,
  `utm_term` text,
  `utm_content` text,
  `pay_hash` varchar(191) DEFAULT '' COMMENT 'Случайный hash для оплаты заказа по ссылке',
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `user_email` (`user_email`),
  KEY `status_id` (`status_id`),
  KEY `1c_last_export` (`1c_last_export`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_order_comments`;

CREATE TABLE `mg_order_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `text` longtext NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_order_opt_fields`;

CREATE TABLE `mg_order_opt_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(249) NOT NULL,
  `type` varchar(249) NOT NULL,
  `vars` text,
  `sort` int(11) DEFAULT NULL,
  `placeholder` text,
  `droped` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_order_opt_fields_content`;

CREATE TABLE `mg_order_opt_fields_content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `field_id` int(11) NOT NULL DEFAULT '0',
  `order_id` int(11) NOT NULL DEFAULT '0',
  `value` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_page`;

CREATE TABLE `mg_page` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_url` varchar(249) NOT NULL,
  `parent` int(11) NOT NULL,
  `title` varchar(249) NOT NULL,
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `html_content` longtext NOT NULL,
  `meta_title` text,
  `meta_keywords` text,
  `meta_desc` text,
  `sort` int(11) DEFAULT NULL,
  `print_in_menu` tinyint(4) NOT NULL DEFAULT '0',
  `invisible` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'Не выводить в меню',
  `without_style` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'Выводить без стилей шаблона',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4;


INSERT INTO `mg_page` VALUES
("1","","0","Главная","index","<h3 class=\"c-title\">\n	О магазине\n</h3>\n\n<div>\n	<p>\n		Мы стабильная и надежная компания, с каждым днем наращиваем свой потенциал. Имеем огромный опыт в сфере корпоративных продаж, наши менеджеры готовы предложить Вам высокий уровень сервиса, грамотную консультацию, выгодные условия работы и широкий спектр цветовых решений. В число наших постоянных клиентов входят крупные компании.\n	</p>\n\n	<p>\n		Наши товары производятся только из самых качественных материалов!\n	</p>\n\n	<p>\n		Отдел корпоративных продаж готов предложить Вам персонального менеджера, грамотную консультацию, доставку на следующий день после оплаты, сертификаты на всю продукцию, индивидуальный метод работы.\n	</p>\n\n	<p>\n		Отдельным направлением является работа с частными лицами с оперативной доставкой, низкими ценами и высоким качеством обслуживания.\n	</p>\n\n	<p>\n		Главное для нас — своевременно удовлетворять потребности наших клиентов всеми силами и доступными нам средствами. Работая с нами, Вы гарантированно приобретаете только оригинальный товар подлинного качества.\n	</p>\n\n	<p>\n		Мы работаем по всем видам оплат. Только приобретая товар у официального дилера, Вы застрахованы от подделок. Будем рады нашему долгосрочному сотрудничеству.\n	</p>\n\n	<p>\n		** Информация представленная на сайте является демонстрационной для ознакомления с Moguta.CMS. <a href=\"https://moguta.ru/\">Moguta.CMS - простая cms для интернет-магазина.</a>\n	</p>\n</div>","Мир цветов","Главная","","5","0","1","0"),
("2","","0","Доставка и оплата","dostavka","<div><h1 class=\"new-products-title\">Доставка и оплата</h1><p><strong>Курьером по Москве</strong></p><p>Доставка осуществляется по Москве бесплатно, если сумма заказа составляет свыше 3000 руб.  Стоимость доставки меньше чем на сумму 3000 руб. Составляет 700 руб. Данный способ доставки дает вам возможность получить товар прямо в руки, курьером по Москве. Срок доставки до 24 часов с момента заказа товара в интернет - магазине.</p><p><strong>Доставка по России</strong></p><p>Доставка по России осуществляется с помощью почтово – курьерских служб во все регионы России. Стоимость доставки зависит от региона и параметров товара. Рассчитать стоимость доставки Вы сможете на официальном сайте почтово – курьерской службы Почта-России и т.д. Сроки доставки составляет до 3-х дней с момента заказа товара в интернет – магазине.</p><h2>Способы оплаты:</h2><p><strong>Наличными: </strong>Оплатить заказ товара Вы сможете непосредственно курьеру в руки при получение товара. </p><p><strong>Наложенным платежом:</strong> Оплатить заказ товара Вы сможете наложенным платежом при получение товара на складе. С данным видом оплаты Вы оплачиваете комиссию за пересылку денежных средств. </p><p><strong>Электронными деньгами:</strong> VISA, Master Card, Yandex.Деньги, Webmoney, Qiwi и др.</p></div><div></div><div></div><div></div>","Доставка","Доставка","Доставка осуществляется по Москве бесплатно, если сумма заказа составляет свыше 3000 руб.  Стоимость доставки меньше чем на сумму 3000 руб. Составляет 700 руб.","2","1","0","0"),
("3","","0","Обратная связь","feedback","<p>Свяжитесь с нами, посредством формы обратной связи представленной ниже. Вы можете задать любой вопрос, и после отправки сообщения наш менеджер свяжется с вами.</p>","Обратная связь","Обратная связь","Свяжитесь с нами, по средствам формы обратной связи представленной ниже. Вы можете задать любой вопрос, и после отправки сообщения наш менеджер свяжется с вами.","3","1","0","0"),
("4","","0","Контакты","contacts","<h1>\n	Контакты\n</h1>","Контакты","Контакты","Мы в социальных сетях  Мы в youtoube","4","1","0","0"),
("5","","0","Каталог","catalog","<p>\n	С любовью и ответственностью мы занимаемся своим делом уже 18 лет.\n</p>\n\n<p>\n	В представленном каталоге Вы можете ознакомиться с полным ассортиментом выращиваемых нами сортов роз, часть из которых эксклюзивно представлена в России.\n</p>","Каталог","Каталог","","1","1","0","0"),
("6","","0","Новинки","group?type=latest","","Новинки","Новинки","","6","1","1","0"),
("7","","0","Акции","group?type=sale","","Акции","Акции","","7","1","1","0"),
("8","","0","Хиты продаж","group?type=recommend","","Хиты продаж","Хиты продаж","","8","1","1","0"),
("9","","0","Контент","content","<h1>\n	Контент\n</h1>","","","","9","0","1","0"),
("10","content/","9","CATALOG","01","<h1>\n	CATALOG\n</h1>\n[gallery id=1]","","","","10","0","0","0"),
("11","content/","9","FALL / WINTER 2024","02","<h1>\n	FALL / WINTER 2024\n</h1>\n[gallery id=2]","","","","11","0","0","0"),
("12","","0","Политика конфиденциальности","privacy-policy","Утверждена Советом директоров​<br />\nАО «Мир цветов»<br />\nПротокол №11 от 22.11.2024 г.<br />\n&nbsp;\n<h1>\n	Политика конфиденциальности персональных данных пользователей сайта\n</h1>\n&nbsp;<br />\n1. Общие положения<br />\n&nbsp;<br />\n1.1. Настоящая Политика конфиденциальности персональных данных пользователей сайта (далее - Политика) разработана во исполнение требований ст. 18.1 Федерального закона от 27.07.2006 № 152-ФЗ «О персональных данных», а также иными нормативно-правовыми актами Российской Федерации в области защиты и обработки персональных данных.<br />\n1.2. АО «Мир цветов» (далее - Оператор) обеспечивает защиту обрабатываемых персональных данных от несанкционированного доступа и разглашения, неправомерного использования или утраты в соответствии с требованиями Федерального закона от 27 июля 2006 г. № 152-ФЗ «О персональных данных».<br />\n1.3. Политика является общедоступным документом, который применяется только к сайту, расположенному в информационно-коммуникационной сети Интернет по адресу: https://mirtsvetov.ru/ (далее – Сайт). &nbsp;<br />\n1.4. Действие Политики не распространяется на сторонние сайты, к которым может получить доступ субъект персональных данных через Сайт.<br />\n1.5. Политика устанавливает обязательные для работников Оператора, задействованных в обработке персональных данных, общие требования и правила по работе со всеми видами носителей информации, содержащими персональные данные субъектов персональных данных, пользующихся Сайтом.<br />\n1.6. Действие политики не распространяется на вопросы обеспечения безопасности персональных данных, отнесенных к сведениям, составляющим государственную тайну Российской Федерации.<br />\n1.7. Основными целями Политики является:<br />\n• обеспечение защиты прав и свобод человека и гражданина при обработке персональных данных, в том числе защиты прав на неприкосновенность частной жизни, личную и семейную тайну;<br />\n• исключение несанкционированных действий работников Оператора и третьих лиц по сбору, систематизации, накоплению, хранению, уточнению (обновлению, изменению) персональных данных, иных форм незаконного вмешательства в информационные ресурсы и локальную вычислительную сеть Оператора;<br />\n• обеспечение правового и нормативного режима конфиденциальности недокументированной информации Пользователей Сайта;<br />\n• защита конституционных прав граждан на личную тайну, конфиденциальность сведений, составляющих персональные данные, и предотвращение возникновения возможной угрозы безопасности Пользователей Сайта.<br />\n1.8. Основные понятия, используемые в Политике:<br />\nсайт - совокупность программных и аппаратных средств для ЭВМ, обеспечивающих публикацию для всеобщего обозрения информации и данных, объединенных общим целевым назначением, посредством технических средств, применяемых для связи между ЭВМ в сети Интернет;<br />\nПользователь – субъект персональных данных имеющий доступ к сети Интернет и использующий возможности сайта;<br />\nперсональные данные - любая информация, относящаяся к прямо или косвенно определенному или определяемому физическому лицу (субъекту персональных данных);<br />\nРуководитель – единоличный исполнительный орган Оператора;<br />\nобработка персональных данных - любое действие (операция) или совокупность действий (операций) с персональными данными, совершаемых с использованием средств автоматизации или без их использования. Обработка персональных данных включает в себя в том числе:<br />\n− сбор;<br />\n− запись;<br />\n− систематизацию;<br />\n− накопление;<br />\n− хранение;<br />\n− уточнение (обновление, изменение);<br />\n− извлечение;<br />\n− использование;<br />\n− передачу (распространение, предоставление, доступ);<br />\n− обезличивание;<br />\n− блокирование;<br />\n− удаление;<br />\n− уничтожение.<br />\nавтоматизированная обработка персональных данных - обработка персональных данных с помощью средств вычислительной техники.<br />\nраспространение персональных данных - действия, направленные на раскрытие персональных данных неопределенному кругу лиц;<br />\nпредоставление персональных данных - действия, направленные на раскрытие персональных данных определенному лицу или определенному кругу лиц;<br />\nблокирование персональных данных - временное прекращение обработки персональных данных (за исключением случаев, если обработка необходима для уточнения персональных данных);<br />\nуничтожение персональных данных - действия, в результате которых становится невозможным восстановить содержание персональных данных в информационной системе персональных данных и (или) в результате которых уничтожаются материальные носители персональных данных;<br />\nобезличивание персональных данных - действия, в результате которых становится невозможным без использования дополнительной информации определить принадлежность персональных данных конкретному субъекту персональных данных;<br />\nинформационная система персональных данных (далее ИСПД)- совокупность содержащихся в базах данных персональных данных и обеспечивающих их обработку информационных технологий и технических средств.<br />\n&nbsp;<br />\n2. Принципы обработки<br />\n&nbsp;<br />\n2.1. Принципы обработки персональных данных работники Оператора руководствуются следующим:<br />\n• обработка персональных данных осуществляется на законной и справедливой основе;<br />\n• обработка персональных данных должна ограничиваться достижением конкретных, заранее определенных и законных целей. Не допускается обработка персональных данных, несовместимая с целями сбора персональных данных;<br />\n• не допускается объединение баз данных, содержащих персональные данные, обработка которых осуществляется в целях, несовместимых между собой;<br />\n• содержание и объем обрабатываемых персональных данных должны соответствовать заявленным целям обработки. Обрабатываемые персональные данные не должны быть избыточными по отношению к целям их обработки;<br />\n• при обработке персональных данных должны быть обеспечены точность и достаточность персональных данных;<br />\n• хранение персональных данных должно осуществляться не дольше, чем этого требуют цели обработки персональных данных, если срок хранения персональных данных не установлен Федеральным законом или соглашением с Пользователем;<br />\n• обрабатываемые персональные данные подлежат уничтожению либо обезличиванию по достижении целей обработки или в случае утраты необходимости в достижении этих целей, если иное не предусмотрено требованиями законодательства.<br />\n2.2. Условия обработки персональных данных:<br />\n• обработка персональных данных Пользователей Сайта осуществляется в соответствии с требованиями действующего законодательства в области защиты персональных данных;<br />\n• обработка персональных данных на Сайте осуществляется с соблюдением принципов и правил, предусмотренных Политикой и законодательством РФ.<br />\n2.3. Обработка персональных данных Пользователей Сайта осуществляется исключения в целях:<br />\n• недопущения создания множественных учетных записей Пользователями;<br />\n• авторизации Пользователя на Сайте;<br />\n• предоставления Пользователю возможности оставлять комментарии и сообщения на Сайте, с последующей возможностью их просмотра.<br />\n2.5. Персональные данные, используемые на Сайте, представляются Пользователем самостоятельно, путем внесения в соответствующую форму при регистрации учетной записи, относятся к конфиденциальной информации и обрабатываются исключительно с использованием средств автоматизации.<br />\n&nbsp;<br />\n3. Права Пользователя<br />\n&nbsp;<br />\n3.1. Пользователь имеет право:<br />\n• на получение сведений об Операторе, о месте его нахождения, о наличии у Оператора персональных данных, относящихся к Пользователю, а также на ознакомление с такими персональными данными, за исключением случаев, прямо предусмотренных законом;<br />\n• на получение от Оператора следующей информации, касающейся обработки его персональных данных:<br />\n− подтверждение факта обработки персональных данных Оператором, а также цель такой обработки;<br />\n− правовые основания и цели обработки персональных данных;<br />\n− цели и применяемые Оператором способы обработки персональных данных;<br />\n− наименование и место нахождения Оператора, сведения о лицах, которые имеют доступ к персональным данным или которым могут быть раскрыты персональные данные на основании договора с Оператором или на основании действующего законодательства;<br />\n− обрабатываемые персональные данные, относящиеся к соответствующему Пользователю, источник их получения;<br />\n− сроки обработки персональных данных, в том числе сроки их хранения;<br />\n− порядок осуществления субъектом персональных данных прав, предусмотренных Федеральным законом;<br />\n− информацию об осуществленной или о предполагаемой трансграничной передаче данных;<br />\n− наименование или фамилию, имя, отчество и адрес лица, осуществляющего обработку персональных данных по поручению Оператора, если обработка поручена или будет поручена такому лицу;<br />\n− иные сведения, предусмотренные действующим законодательством РФ;<br />\n• требовать изменения, уточнения, уничтожения информации о самом себе;<br />\n• обжаловать неправомерные действия или бездействие по обработке персональных данных и требовать соответствующей компенсации в суде;<br />\n• определять представителей для защиты своих персональных данных;<br />\n• требовать от Оператора уведомления обо всех произведенных в них изменениях или исключениях из них;<br />\n• обжаловать в уполномоченном органе по защите прав субъектов персональных данных или в судебном порядке действия или бездействие Оператора, если считает, что последний осуществляет обработку его персональных данных с нарушением требований Федерального закона от 27 июля 2006 г. № 152-ФЗ «О персональных данных» или иным образом нарушает его права и свободы;<br />\n• на защиту своих прав и законных интересов, в том числе на возмещение убытков или компенсацию морального вреда в судебном порядке.<br />\n&nbsp;<br />\n4. Обязанности Оператора<br />\n&nbsp;<br />\n4.1. В случае получения письменного запроса от Пользователя, Оператор обязан обработать его и предоставить на него ответ, в порядке предусмотренном Правилами рассмотрения обращений субъектов персональных данных и действующим законодательством РФ.<br />\n4.2. В случае получения запроса от уполномоченного органа по защите прав субъектов персональных данных о предоставлении информации, необходимой для осуществления деятельности указанного органа, Оператор обязан сообщить такую информацию в установленные законом сроки.<br />\n4.3. В случае выявления неправомерной обработки персональных данных Оператор обязан осуществить блокирование неправомерно обрабатываемых персональных данных, относящихся к Пользователю, с момента установления подобного факта.<br />\n4.4. В случае достижения цели обработки персональных данных Оператор обязан прекратить обработку персональных данных и уничтожить персональные данные в порядке, предусмотренном Положением об порядке уничтожения персональных данных и действующим законодательством РФ.<br />\n4.5. Оператору запрещается принятие на основании исключительно автоматизированной обработки персональных данных решений, порождающих юридические последствия в отношении субъекта персональных данных или иным образом затрагивающих его права и законные интересы.<br />\n&nbsp;<br />\n5. Конфиденциальности персональных данных<br />\n&nbsp;<br />\n5.1. Оператор обеспечивает конфиденциальность и безопасность персональных данных при их обработке в соответствии с требованиями локальных нормативных актов Оператора и требованиями действующего законодательства.<br />\n5.2. Оператор не раскрывает третьим лицам и не распространяет персональные данные без согласия Пользователя, если иное не предусмотрено требованиями действующего законодательства РФ.<br />\n&nbsp;<br />\n&nbsp;<br />\n&nbsp;<br />\n6. Обработка персональных данных<br />\n&nbsp;<br />\n6.1. Все персональные данные следует получать от самого Пользователя. В случае получения согласия на обработку персональных данных от представителя Пользователя его полномочия должны быть подтверждены в установленном законом порядке.<br />\n6.2. Перечень лиц, имеющие право доступа к персональным данным определяется согласно локальным нормативным актам Оператора, и утверждается приказом Руководителя Оператора.<br />\n6.2. Оператор осуществляет хранение персональных данных Пользователей с момента их предоставления, до момента отзыва согласия на обработку персональных данных, достижения целей обработки или истечения срока, на который было представлено согласие, а равно в иных случаях, прямо предусмотренных действующим законодательством РФ.<br />\n6.3. Оператором не ведется обработка персональных данных Пользователей на бумажных носителях информации.<br />\n6.4. Оператор не передает персональные данные третьим лицам, в том числе в целях обработки. Персональные данные Пользователей обрабатывают исключительно работниками Оператора.<br />\n6.5. Блокирование и удаление персональных данных на Сайте осуществляется на основании письменного обращения Пользователя или уполномоченного органа.<br />\n6.6. Уничтожение персональных данных осуществляется путем стирания информации с использованием сертифицированного программного обеспечения.<br />\n&nbsp;<br />\n7. Защиты персональных данных<br />\n&nbsp;<br />\n7.1. Оператор при обработке персональных данных принимает необходимые правовые, организационные и технические меры или обеспечивает их принятие для защиты персональных данных от неправомерного или случайного доступа к ним, уничтожения, изменения, блокирования, копирования, предоставления, распространения персональных данных, а также от иных неправомерных действий в отношении персональных данных.<br />\n7.2. Безопасности персональных данных достигается, следующими способами:<br />\n• определением угроз безопасности персональных данных при их обработке в информационных системах персональных данных;<br />\n• применением организационных и технических мер по обеспечению безопасности персональных данных при их обработке в информационных системах персональных данных, необходимых для выполнения требований к защите персональных данных;<br />\n• учетом машинных носителей персональных данных;<br />\n• обнаружением фактов несанкционированного доступа к персональным данным и принятием мер;<br />\n• восстановлением персональных данных, модифицированных или уничтоженных вследствие несанкционированного доступа к ним;<br />\n• установлением правил доступа к персональным данным, обрабатываемым в информационной системе персональных данных, а также обеспечением регистрации и учета всех действий, совершаемых с персональными данными в информационной системе персональных данных;<br />\n• контролем за принимаемыми мерами по обеспечению безопасности персональных данных и уровня защищенности информационных систем персональных данных;<br />\n• назначением лица, ответственного за обработку персональных данных;<br />\n• установлением индивидуальных паролей доступа сотрудников в информационную систему в соответствии с их должностными обязанностями;<br />\n• использованием сертифицированного антивирусного программного обеспечения;<br />\n• обучением работников Оператора, непосредственно осуществляющих обработку персональных данных, положениям законодательства РФ о персональных данных, в том числе требованиям к защите персональных данных.<br />\n7.3. К защищаемым сведениям о Пользователе на Сайте относятся данные, позволяющие идентифицировать Пользователя или получить о нем дополнительные сведения, предусмотренные законодательством и Политикой.<br />\n7.4. К защищаемым объектам персональных данных относятся:<br />\n• объекты информатизации и технические средства автоматизированной обработки информации, содержащей персональные данные;<br />\n• информационные ресурсы, содержащие информацию об информационно-телекоммуникационных системах, в которых используются персональные данные, о событиях, произошедших с управляемыми объектами, о планах обеспечения бесперебойной работы и процедурах перехода к управлению в аварийных режимах;<br />\n• каналы связи, которые используются для передачи персональных данных в виде информативных электрических сигналов и физических полей;<br />\n• отчуждаемые машинные носители информации на магнитной, магнитно-оптической и иной основе, применяемые для обработки персональных данных.<br />\n7.5. Технологическая информация об информационных системах и элементах системы защиты персональных данных, подлежащая защите, включает:<br />\n• сведения о системе управления доступом на объекты информатизации, на которых осуществляется обработка персональных данных;<br />\n• управляющая информация;<br />\n• технологическая информация средств доступа к системам управления;<br />\n• характеристики каналов связи, которые используются для передачи персональных данных в виде информативных электрических сигналов и физических полей;<br />\n• информация о средствах защиты персональных данных, их составе и структуре, принципах и технических решениях защиты;<br />\n• служебные данные, появляющиеся при работе программного обеспечения, сообщений и протоколов межсетевого взаимодействия, в результате обработки персональных данных.<br />\n7.6. Система защиты персональных данных соответствует требованиям постановления Правительства РФ от 1 ноября 2012 г. № 1119 «Об утверждении требований к защите персональных данных при их обработке в информационных системах персональных данных» и обеспечивает:<br />\n• своевременное обнаружение и предотвращение несанкционированного доступа к персональным данным или передачи их лицам, не имеющим права доступа к такой информации;<br />\n• недопущение воздействия на технические средства автоматизированной обработки персональных данных, в результате которого может быть нарушено их функционирование;<br />\n• возможность незамедлительного восстановления персональных данных, модифицированных или уничтоженных вследствие несанкционированного доступа к ним;<br />\n• постоянный контроль за обеспечением уровня защищенности персональных данных.<br />\n&nbsp;<br />\n8. Ответственность<br />\n&nbsp;<br />\n8.1. Все сотрудники Оператора, осуществляющие обработку персональных данных, обязаны хранить тайну о сведениях, содержащих персональные данные. &nbsp;<br />\n8.2. Лица, виновные в нарушении требований к обработке персональных данных несут ответственность в соответствии с действующим законодательством РФ.<br />\n8.3. Ответственность за соблюдение режима персональных данных по отношению к персональным данным, находящимся в базах данных Сайта, несут ответственные за обработку персональных данных работники Оператора.<br />\n9. Заключительные положения<br />\n&nbsp;<br />\n9.1. Политика утверждается Советом директоров АО «Мир цветов» и действует бессрочно, до момента вступления в силу новой редакции Политики.<br />\n9.2. В случае изменения законодательства Российской Федерации в области защиты персональных данных, Оператор принимает новую редакцию Политики, с учетом изменений. До этого момента, Политика действует в части, не противоречащей действующему законодательству Российской Федерации.<br />\n9.3. В целях связи с Операторов, могут быть использованы следующие контактные данные:<br />\nтел. 8 (8342) 24-57-24;<br />\ne-mail: info@mirtsvetov.ru;<br />\nпочтовый адрес: 431900, Мордовия Республика, Кадошкинский Район, Кадошкино Рабочий поселок, Гражданская Улица, дом 47.<br />\n&nbsp;<br />\n&nbsp;<br />\n22.11.2024 г.","","","","12","0","1","0"),
("13","","0","Политика в отношении обработки персональных данных","politika-v-otnoshenii-obrabotki-personalnyh-dannyh","Утверждена Советом директоров​ АО «Мир цветов»<br />\nПротокол №11 от 22.11.2024 г.<br />\n&nbsp;\n<h1>\n	Политика в отношении обработки персональных данных<span style=\"font-size: 13px;\">&nbsp;</span>\n</h1>\n1. Общие положения<br />\n1.1. Настоящая Политика в отношении обработки персональных данных (далее - Политика) разработана во исполнение требований п. 2 ч. 1 ст. 18.1 Федерального закона от 27.07.2006 № 152-ФЗ «О персональных данных» (далее - Закон) в целях обеспечения защиты прав и свобод человека и гражданина при обработке его персональных данных, в том числе защиты прав на неприкосновенность частной жизни, личную и семейную тайну.<br />\n1.2. Политика действует в отношении всех персональных данных, которые обрабатывает АО «Мир цветов» (далее - Оператор).<br />\n1.3. Политика распространяется на отношения в области обработки персональных данных, возникшие у Оператора как до, так и после утверждения настоящей Политики.<br />\n1.4. Во исполнение требований ч. 2 ст. 18.1 Закона настоящая Политика публикуется в свободном доступе путем её размещения на сайте Оператора в информационно телекоммуникационной сети «Интернет», по адресу https://mirtsvetov.ru/, а также на информационной доске на территории Оператора, по адресу: Республика Мордовия, р-н Кадошкинский, рп. Кадошкино, ул. Гражданская, д.47.<br />\n1.5. Основные понятия, используемые в Политике:<br />\nперсональные данные - любая информация, относящаяся к прямо или косвенно определенному или определяемому физическому лицу (субъекту персональных данных);<br />\nоператор персональных данных (оператор) - государственный орган, муниципальный орган, юридическое или физическое лицо, самостоятельно или совместно с другими лицами организующие и (или) осуществляющие обработку персональных данных, а также определяющие цели обработки персональных данных, состав персональных данных, подлежащих обработке, действия (операции), совершаемые с персональными данными;<br />\nобработка персональных данных - любое действие (операция) или совокупность действий (операций) с персональными данными, совершаемых с использованием средств автоматизации или без их использования. Обработка персональных данных включает в себя в том числе:<br />\n• сбор;<br />\n• запись;<br />\n• систематизацию;<br />\n• накопление;<br />\n• хранение;<br />\n• уточнение (обновление, изменение);<br />\n• извлечение;<br />\n• использование;<br />\n• передачу (распространение, предоставление, доступ);<br />\n• обезличивание;<br />\n• блокирование;<br />\n• удаление;<br />\n• уничтожение.<br />\nавтоматизированная обработка персональных данных - обработка персональных данных с помощью средств вычислительной техники;<br />\nраспространение персональных данных - действия, направленные на раскрытие персональных данных неопределенному кругу лиц;<br />\nРуководитель – единоличный исполнительный орган Оператора;<br />\nпредоставление персональных данных - действия, направленные на раскрытие персональных данных определенному лицу или определенному кругу лиц;<br />\nблокирование персональных данных - временное прекращение обработки персональных данных (за исключением случаев, если обработка необходима для уточнения персональных данных);<br />\nуничтожение персональных данных - действия, в результате которых становится невозможным восстановить содержание персональных данных в информационной системе персональных данных и (или) в результате которых уничтожаются материальные носители персональных данных;<br />\nобезличивание персональных данных - действия, в результате которых становится невозможным без использования дополнительной информации определить принадлежность персональных данных конкретному субъекту персональных данных;<br />\nинформационная система персональных данных - совокупность содержащихся в базах данных персональных данных и обеспечивающих их обработку информационных технологий и технических средств.<br />\n1.6. Основные права и обязанности Оператора.<br />\n1.6.1. Оператор имеет право:<br />\n• самостоятельно определять состав и перечень мер, необходимых и достаточных для обеспечения выполнения обязанностей, предусмотренных Законом о персональных данных и принятыми в соответствии с ним нормативными правовыми актами, если иное не предусмотрено Законом о персональных данных или другими федеральными законами;<br />\n• поручить обработку персональных данных другому лицу с согласия субъекта персональных данных, если иное не предусмотрено федеральным законом, на основании заключаемого с этим лицом договора. Лицо, осуществляющее обработку персональных данных по поручению Оператора, обязано соблюдать принципы и правила обработки персональных данных, предусмотренные Законом о персональных данных, соблюдать конфиденциальность персональных данных, принимать необходимые меры, направленные на обеспечение выполнения обязанностей, предусмотренных Законом о персональных данных;<br />\n• в случае отзыва субъектом персональных данных согласия на обработку персональных данных Оператор вправе продолжить обработку персональных данных без согласия субъекта персональных данных при наличии оснований, указанных в Законе о персональных данных.<br />\n1.6.2. Оператор обязан:<br />\n• организовывать обработку персональных данных в соответствии с требованиями Закона о персональных данных;<br />\n• отвечать на обращения и запросы субъектов персональных данных и их законных представителей в соответствии с требованиями Закона о персональных данных;<br />\n• сообщать в уполномоченный орган по защите прав субъектов персональных данных (Федеральную службу по надзору в сфере связи, информационных технологий и массовых коммуникаций (Роскомнадзор)) по запросу этого органа необходимую информацию в течение 10 рабочих дней с даты получения такого запроса. Данный срок может быть продлен, но не более чем на пять рабочих дней. Для этого Оператору необходимо направить в Роскомнадзор мотивированное уведомление с указанием причин продления срока предоставления запрашиваемой информации;<br />\n• в порядке, определенном федеральным органом исполнительной власти, уполномоченным в области обеспечения безопасности, обеспечивать взаимодействие с государственной системой обнаружения, предупреждения и ликвидации последствий компьютерных атак на информационные ресурсы РФ, включая информирование его о компьютерных инцидентах, которые повлекли неправомерную передачу (предоставление, распространение, доступ) персональных данных.<br />\n1.7. Основные права субъекта персональных данных. Субъект персональных данных имеет право:<br />\n• получать информацию, касающуюся обработки его персональных данных, за исключением случаев, предусмотренных федеральными законами. Сведения предоставляются субъекту персональных данных Оператором в доступной форме, и в них не должны содержаться персональные данные, относящиеся к другим субъектам персональных данных, за исключением случаев, когда имеются законные основания для раскрытия таких персональных данных. Перечень информации и порядок ее получения установлен Законом о персональных данных;<br />\n• требовать от оператора уточнения его персональных данных, их блокирования или уничтожения в случае, если персональные данные являются неполными, устаревшими, неточными, незаконно полученными или не являются необходимыми для заявленной цели обработки, а также принимать предусмотренные законом меры по защите своих прав;<br />\n• дать предварительное согласие на обработку персональных данных в целях продвижения на рынке товаров, работ и услуг;<br />\n• обжаловать в Роскомнадзоре или в судебном порядке неправомерные действия или бездействие Оператора при обработке его персональных данных.<br />\n1.8. Контроль за исполнением требований настоящей Политики осуществляется уполномоченным лицом, ответственным за организацию обработки персональных данных у Оператора.<br />\n1.9. Ответственность за нарушение требований законодательства Российской Федерации и нормативных актов Оператора в сфере обработки и защиты персональных данных определяется в соответствии с законодательством Российской Федерации.<br />\n&nbsp;<br />\n2. Цели сбора персональных данных<br />\n2.1. Обработка персональных данных ограничивается достижением конкретных, заранее определенных и законных целей. Не допускается обработка персональных данных, несовместимая с целями сбора персональных данных.<br />\n2.2. Обработке подлежат только персональные данные, которые отвечают целям их обработки.<br />\n2.3. Обработка Оператором персональных данных осуществляется в следующих целях:<br />\n• ведение кадрового и бухгалтерского учета;<br />\n• подготовка, заключение и исполнение гражданско-правовых договоров;<br />\n• иных целях предусмотренных действующим законодательством РФ.<br />\n2.4. Обработка персональных данных может осуществляться исключительно в целях обеспечения соблюдения законов и иных нормативных правовых актов.<br />\n&nbsp;<br />\n3. Правовые основания обработки персональных данных<br />\n3.1. Правовым основанием обработки персональных данных является совокупность нормативных правовых актов, во исполнение которых и в соответствии с которыми Оператор осуществляет обработку персональных данных, в том числе:<br />\n• Конституция Российской Федерации;<br />\n• Гражданский кодекс Российской Федерации;<br />\n• Трудовой кодекс Российской Федерации;<br />\n• Налоговый кодекс Российской Федерации;<br />\n• Федеральный закон от 27.07.2006 № 152-ФЗ «О персональных данных»;<br />\n• Федеральный закон от 06.12.2011 № 402-ФЗ «О бухгалтерском учете»;<br />\n• Федеральный закон от 15.12.2001 № 167-ФЗ «Об обязательном пенсионном страховании в Российской Федерации»;<br />\n• Федеральный закон от 27.07.2006 № 149-ФЗ «Об информации, информационных технологиях и о защите информации»;<br />\n• Постановление Правительства РФ от 27.11.2006 № 719 «Об утверждении Положения о воинском учете»;<br />\n• Постановление Правительства РФ от 15.09.2008 г. № 687 «Об утверждении Положения об особенностях обработки персональных данных, осуществляемой без использования средств автоматизации»;<br />\n• иные нормативные правовые акты, регулирующие отношения, связанные с деятельностью Оператора.<br />\n3.2. Правовым основанием обработки персональных данных также являются:<br />\n• Устав Оператора;<br />\n• договоры, заключаемые между Оператором и субъектами персональных данных;<br />\n• согласие субъектов персональных данных на обработку их персональных данных.<br />\n&nbsp;<br />\n4. Объем и категории обрабатываемых персональных данных, категории субъектов персональных данных<br />\n4.1. Содержание и объем обрабатываемых персональных данных должны соответствовать заявленным целям обработки, предусмотренным в разд. 2 настоящей Политики. Обрабатываемые персональные данные не должны быть избыточными по отношению к заявленным целям их обработки.<br />\n4.2. Оператор может обрабатывать персональные данные следующих категорий субъектов персональных данных:<br />\n4.2.1. Уволенные работники, работники, а также их родственники - для цели ведения кадрового и бухгалтерского учета:<br />\n• фамилия, имя, отчество;<br />\n• год рождения;<br />\n• месяц рождения;<br />\n• дата рождения;<br />\n• место рождения;<br />\n• семейное положение;<br />\n• социальное положение;<br />\n• доходы;<br />\n• пол;<br />\n• адрес электронной почты;<br />\n• адрес места жительства;<br />\n• адрес регистрации;<br />\n• номер телефона;<br />\n• СНИЛС;<br />\n• ИНН;<br />\n• гражданство;<br />\n• данные документа, удостоверяющего личность;<br />\n• данные водительского удостоверения;<br />\n• данные документа, содержащиеся в свидетельстве о рождении;<br />\n• номер расчетного счета;<br />\n• профессия;<br />\n• должность;<br />\n• сведения о трудовой деятельности (в том числе стаж работы, данные о трудовой занятости на текущее время с указанием наименования и расчетного счета организации);<br />\n• отношение к воинской обязанности, сведения о воинском учете;<br />\n• сведения об образовании;<br />\n• иные персональные данные, получение которых необходимо для исполнения требований действующего законодательства.<br />\n4.2.2. Выгодоприобретатели по договорам, клиенты и контрагенты Оператора, включая их представителей - для цели осуществления уставной деятельности, включая подготовку, заключение и исполнение договоров:<br />\n• фамилия, имя, отчество;<br />\n• год рождения;<br />\n• месяц рождения;<br />\n• дата рождения;<br />\n• адрес электронной почты;<br />\n• адрес места жительства;<br />\n• адрес регистрации;<br />\n• номер телефона;<br />\n• СНИЛС;<br />\n• ИНН;<br />\n• гражданство;<br />\n• данные документа, удостоверяющего личность;<br />\n• номер расчетного счета;<br />\n• должность;<br />\n• сведения о трудовой деятельности;<br />\n• иные персональные данные, представленные субъектом персональных данных.<br />\n4.2.3. Посетители сайта – для цели сбора персональных данных на сайте Оператора:<br />\n• фамилия, имя, отчество;<br />\n• адрес электронной почты;<br />\n• номер телефона;<br />\n• сведения, собираемые посредством метрических программ;<br />\n• иные персональные данные, представленные субъектом персональных данных.<br />\n4.3. Обработка Оператором биометрических персональных данных (сведений, которые характеризуют физиологические и биологические особенности человека, на основании которых можно установить его личность) осуществляется в соответствии с законодательством Российской Федерации.<br />\n4.4. Оператором не осуществляется обработка специальных категорий персональных данных, касающихся расовой, национальной принадлежности, политических взглядов, религиозных или философских убеждений, состояния здоровья, интимной жизни, за исключением случаев, предусмотренных законодательством РФ.<br />\n&nbsp;<br />\n5. Порядок и условия обработки персональных данных<br />\n5.1. Обработка персональных данных осуществляется Оператором в соответствии с требованиями законодательства Российской Федерации.<br />\n5.2. Обработка персональных данных осуществляется с согласия субъектов персональных данных на обработку их персональных данных, а также без такового в случаях, предусмотренных законодательством Российской Федерации.<br />\n5.3. Оператор осуществляет обработку персональных данных для каждой цели их обработки следующими способами:<br />\n• неавтоматизированная обработка персональных данных;<br />\n• автоматизированная обработка персональных данных с передачей полученной информации по информационно-телекоммуникационным сетям или без таковой;<br />\n• смешанная обработка персональных данных.<br />\n5.4. К обработке персональных данных допускаются работники Оператора, в должностные обязанности которых входит обработка персональных данных.<br />\n5.5. Обработка персональных данных для каждой цели обработки, указанной в п. 2.3 Политики, осуществляется путем:<br />\n• получения персональных данных в устной и письменной форме непосредственно от субъектов персональных данных;<br />\n• внесения персональных данных в журналы, реестры и информационные системы Оператора;<br />\n• использования иных способов обработки персональных данных.<br />\n5.6. Не допускается раскрытие третьим лицам и распространение персональных данных без согласия субъекта персональных данных, если иное не предусмотрено федеральным законом. Согласие на обработку персональных данных, разрешенных субъектом персональных данных для распространения, оформляется отдельно от иных согласий субъекта персональных данных на обработку его персональных данных.<br />\nТребования к содержанию согласия на обработку персональных данных, разрешенных субъектом персональных данных для распространения, утверждены Приказом Роскомнадзора от 24.02.2021 № 18 «Об утверждении требований к содержанию согласия на обработку персональных данных, разрешенных субъектом персональных данных для распространения».<br />\n5.7. Передача персональных данных органам дознания и следствия, в Федеральную налоговую службу, Социальный фонд России и другие уполномоченные органы исполнительной власти и организации осуществляется в соответствии с требованиями законодательства Российской Федерации.<br />\n5.8. Оператор принимает необходимые правовые, организационные и технические меры для защиты персональных данных от неправомерного или случайного доступа к ним, уничтожения, изменения, блокирования, распространения и других несанкционированных действий, в том числе:<br />\n• определяет угрозы безопасности персональных данных при их обработке;<br />\n• принимает локальные нормативные акты и иные документы, регулирующие отношения в сфере обработки и защиты персональных данных;<br />\n• назначает лиц, ответственных за обеспечение безопасности персональных данных в структурных подразделениях и информационных системах Оператора;<br />\n• создает необходимые условия для работы с персональными данными;<br />\n• организует учет документов, содержащих персональные данные;<br />\n• организует работу с информационными системами, в которых обрабатываются персональные данные;<br />\n• хранит персональные данные в условиях, при которых обеспечивается их сохранность и исключается неправомерный доступ к ним;<br />\n• организует обучение работников Оператора, осуществляющих обработку персональных данных.<br />\n5.9. Оператор осуществляет хранение персональных данных в форме, позволяющей определить субъекта персональных данных, не дольше, чем этого требует каждая цель обработки персональных данных, если срок хранения персональных данных не установлен федеральным законом, договором.<br />\n5.9.1. Персональные данные на бумажных носителях хранятся у Оператора в течение сроков хранения документов, для которых эти сроки предусмотрены законодательством об архивном деле в РФ (Федеральный закон от 22.10.2004 № 125-ФЗ «Об архивном деле в Российской Федерации», Перечень типовых управленческих архивных документов, образующихся в процессе деятельности государственных органов, органов местного самоуправления и организаций, с указанием сроков их хранения (утв. Приказом Росархива от 20.12.2019 № 236 «Об утверждении Перечня типовых управленческих архивных документов, образующихся в процессе деятельности государственных органов, органов местного самоуправления и организаций, с указанием сроков их хранения»)).<br />\n5.9.2. Срок хранения персональных данных, обрабатываемых в информационных системах персональных данных, соответствует сроку хранения персональных данных на бумажных носителях.<br />\n5.10. Оператор прекращает обработку персональных данных в следующих случаях:<br />\n• выявлен факт их неправомерной обработки. Срок - в течение трех рабочих дней с даты выявления;<br />\n• достигнута цель их обработки;<br />\n• истек срок действия или отозвано согласие субъекта персональных данных на обработку указанных данных, когда по Закону обработка этих данных допускается только с согласия.<br />\n5.11. При достижении целей обработки персональных данных, а также в случае отзыва субъектом персональных данных согласия на их обработку Оператор прекращает обработку этих данных, если:<br />\n• иное не предусмотрено договором, стороной которого, выгодоприобретателем или поручителем, по которому является субъект персональных данных;<br />\n• Оператор не вправе осуществлять обработку без согласия субъекта персональных данных на основаниях, предусмотренных Законом или иными федеральными законами;<br />\n• иное не предусмотрено другим соглашением между Оператором и субъектом персональных данных.<br />\n5.12. При обращении субъекта персональных данных к Оператору с требованием о прекращении обработки персональных данных в срок, не превышающий 10 рабочих дней с даты получения Оператором соответствующего требования, обработка персональных данных прекращается, за исключением случаев, предусмотренных Законом. Указанный срок может быть продлен, но не более чем на пять рабочих дней. Для этого Оператору необходимо направить субъекту персональных данных мотивированное уведомление с указанием причин продления срока.<br />\n5.13. При сборе персональных данных, в том числе посредством информационно-телекоммуникационной сети «Интернет», Оператор обеспечивает запись, систематизацию, накопление, хранение, уточнение (обновление, изменение), извлечение персональных данных граждан Российской Федерации с использованием баз данных, находящихся на территории Российской Федерации, за исключением случаев, указанных в Законе о персональных данных.<br />\n5.14. Оператором используются следующие информационные системы:<br />\n• 1С: Бухгалтерия 3.0;<br />\n• 1С-Камин: Зарплата 5.0;<br />\n• Корпоративная почта.<br />\n&nbsp;<br />\n6. Актуализация, исправление, удаление, уничтожение персональных данных, ответы на запросы субъектов на доступ к персональным данным<br />\n6.1. Подтверждение факта обработки персональных данных Оператором, правовые основания и цели обработки персональных данных, а также иные сведения, указанные в ч. 7 ст. 14 Закона, предоставляются Оператором субъекту персональных данных или его представителю в течение 10 рабочих дней с момента обращения либо получения запроса субъекта персональных данных или его представителя. Данный срок может быть продлен, но не более чем на пять рабочих дней. Для этого Оператору следует направить субъекту персональных данных мотивированное уведомление с указанием причин продления срока предоставления запрашиваемой информации.<br />\nВ предоставляемые сведения не включаются персональные данные, относящиеся к другим субъектам персональных данных, за исключением случаев, когда имеются законные основания для раскрытия таких персональных данных.<br />\nЗапрос должен содержать:<br />\n• номер основного документа, удостоверяющего личность субъекта персональных данных или его представителя, сведения о дате выдачи указанного документа и выдавшем его органе;<br />\n• сведения, подтверждающие участие субъекта персональных данных в отношениях с Оператором (номер договора, дата заключения договора, условное словесное обозначение и (или) иные сведения), либо сведения, иным образом подтверждающие факт обработки персональных данных Оператором;<br />\n• подпись субъекта персональных данных или его представителя.<br />\nЗапрос может быть направлен в форме электронного документа и подписан электронной подписью в соответствии с законодательством Российской Федерации.<br />\nОператор предоставляет сведения, указанные в ч. 7 ст. 14 Закона, субъекту персональных данных или его представителю в той форме, в которой направлены соответствующие обращение либо запрос, если иное не указано в обращении или запросе.<br />\nЕсли в обращении (запросе) субъекта персональных данных не отражены в соответствии с требованиями Закона о персональных данных все необходимые сведения или субъект не обладает правами доступа к запрашиваемой информации, то ему направляется мотивированный отказ.<br />\nПраво субъекта персональных данных на доступ к его персональным данным может быть ограничено в соответствии с ч. 8 ст. 14 Закона, в том числе если доступ субъекта персональных данных к его персональным данным нарушает права и законные интересы третьих лиц.<br />\n6.2. В случае выявления неточных персональных данных при обращении субъекта персональных данных или его представителя либо по их запросу или по запросу Роскомнадзора Оператор осуществляет блокирование персональных данных, относящихся к этому субъекту персональных данных, с момента такого обращения или получения указанного запроса на период проверки, если блокирование персональных данных не нарушает права и законные интересы субъекта персональных данных или третьих лиц.<br />\nВ случае подтверждения факта неточности персональных данных Оператор на основании сведений, представленных субъектом персональных данных или его представителем либо Роскомнадзором, или иных необходимых документов уточняет персональные данные в течение семи рабочих дней со дня представления таких сведений и снимает блокирование персональных данных.<br />\n6.3. В случае выявления неправомерной обработки персональных данных при обращении (запросе) субъекта персональных данных или его представителя либо Роскомнадзора Оператор осуществляет блокирование неправомерно обрабатываемых персональных данных, относящихся к этому субъекту персональных данных, с момента такого обращения или получения запроса.<br />\n6.4. При выявлении Оператором, Роскомнадзором или иным заинтересованным лицом факта неправомерной или случайной передачи (предоставления, распространения) персональных данных (доступа к персональным данным), повлекшей нарушение прав субъектов персональных данных, Оператор:<br />\n• в течение 24 часов - уведомляет Роскомнадзор о произошедшем инциденте, предполагаемых причинах, повлекших нарушение прав субъектов персональных данных, предполагаемом вреде, нанесенном правам субъектов персональных данных, и принятых мерах по устранению последствий инцидента, а также предоставляет сведения о лице, уполномоченном Оператором на взаимодействие с Роскомнадзором по вопросам, связанным с инцидентом;<br />\n• в течение 72 часов - уведомляет Роскомнадзор о результатах внутреннего расследования выявленного инцидента и предоставляет сведения о лицах, действия которых стали его причиной (при наличии).<br />\n6.5. Порядок уничтожения персональных данных Оператором.<br />\n6.5.1. Условия и сроки уничтожения персональных данных Оператором:<br />\n• достижение цели обработки персональных данных либо утрата необходимости достигать эту цель - в течение 30 дней;<br />\n• достижение максимальных сроков хранения документов, содержащих персональные данные, - в течение 30 дней;<br />\n• предоставление субъектом персональных данных (его представителем) подтверждения того, что персональные данные получены незаконно или не являются необходимыми для заявленной цели обработки, - в течение семи рабочих дней;<br />\n• отзыв субъектом персональных данных согласия на обработку его персональных данных, если их сохранение для цели их обработки более не требуется, - в течение 30 дней.<br />\n6.5.2. При достижении цели обработки персональных данных, а также в случае отзыва субъектом персональных данных согласия на их обработку персональные данные подлежат уничтожению, если:<br />\n• иное не предусмотрено договором, стороной которого, выгодоприобретателем или поручителем, по которому является субъект персональных данных;<br />\n• Оператор не вправе осуществлять обработку без согласия субъекта персональных данных на основаниях, предусмотренных Законом о персональных данных или иными федеральными законами;<br />\n• иное не предусмотрено другим соглашением между Оператором и субъектом персональных данных.<br />\n6.5.3. Уничтожение персональных данных осуществляет комиссия, созданная приказом Руководителя Оператора.<br />\n6.5.4. Способы уничтожения персональных данных устанавливаются в локальных нормативных актах Оператора.<br />\n7. Заключительные положения<br />\n7.1. Политика утверждается Советом директоров АО «Мир цветов» и действует бессрочно, до момента вступления в силу новой редакции Политики.<br />\n7.2. В случае изменения законодательства Российской Федерации в области защиты персональных данных Оператор принимает новую редакцию Политики, с учетом изменений. До этого момента Политика действует в части, не противоречащей действующему законодательству Российской Федерации.<br />\n7.3. В целях связи с Оператором, могут быть использованы следующие контактные данные:<br />\nтел. 8 (8342) 24-57-24;<br />\ne-mail: info@mirtsvetov.ru;<br />\nпочтовый адрес: 431900, Мордовия Республика, Кадошкинский Район, Кадошкино Рабочий поселок, Гражданская Улица, дом 47.<br />\n<br />\n22.11.2024 г.","","","","13","0","1","0");
DROP TABLE IF EXISTS `mg_payment`;

CREATE TABLE `mg_payment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(191) NOT NULL DEFAULT '',
  `name` varchar(1024) NOT NULL,
  `public_name` varchar(1023) DEFAULT NULL,
  `activity` int(1) NOT NULL DEFAULT '0',
  `paramArray` text,
  `urlArray` varchar(1023) DEFAULT NULL,
  `rate` double NOT NULL DEFAULT '0',
  `sort` int(11) DEFAULT NULL,
  `permission` varchar(5) NOT NULL DEFAULT 'fiz',
  `plugin` varchar(255) DEFAULT NULL,
  `icon` varchar(511) DEFAULT NULL,
  `logs` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT 'Флаг, обозначающий поддерживает оплата логирование или нет',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1004 DEFAULT CHARSET=utf8mb4;


INSERT INTO `mg_payment` VALUES
("1","old#1","WebMoney","","1","{\"Номер кошелька\":\"\",\"Секретный ключ\":\"\",\"Тестовый режим\":\"ZmFsc2VoWSo2bms3ISEjMnFq\",\"Метод шифрования\":\"bWQ1aFkqNm5rNyEhIzJxag==\"}","{\"result URL:\":\"/payment?id=1&pay=result\",\"success URL:\":\"/payment?id=1&pay=success\",\"fail URL:\":\"/payment?id=1&pay=fail\"}","0","1","fiz","","","0"),
("3","old#3","Наложенный платеж","","0","{\"Примечание\":\"\"}","","0","3","fiz","","","0"),
("4","old#4","Наличные (курьеру)","","0","{\"Примечание\":\"\"}","","0","4","fiz","","","0"),
("5","old#5","ROBOKASSA","","0","{\"Логин\":\"\",\"пароль 1\":\"\",\"пароль 2\":\"\",\"Метод шифрования\":\"bWQ1aFkqNm5rNyEhIzJxag==\",\"Использовать онлайн кассу\":\"ZmFsc2VoWSo2bms3ISEjMnFq\",\"НДС, включенный в цену\":\"MjAlaFkqNm5rNyEhIzJxag==\",\"Обработка смены статуса при переходе на successUrl\":\"ZmFsc2VoWSo2bms3ISEjMnFq\"}","{\"result URL:\":\"/payment?id=5&pay=result\",\"success URL:\":\"/payment?id=5&pay=success\",\"fail URL:\":\"/payment?id=5&pay=fail\"}","0","5","fiz","","","0"),
("7","old#7","Оплата по реквизитам","","0","{\"Юридическое лицо\":\"\", \"ИНН\":\"\",\"КПП\":\"\", \"Адрес\":\"\", \"Банк получателя\":\"\", \"БИК\":\"\",\"Расчетный счет\":\"\",\"Кор. счет\":\"\"}","","0","7","yur","","","0"),
("8","old#8","Интеркасса","","0","{\"Идентификатор кассы\":\"\",\"Секретный ключ\":\"\",\"Тестовый режим\":\"ZmFsc2VoWSo2bms3ISEjMnFq\",\"Метод шифрования\":\"bWQ1aFkqNm5rNyEhIzJxag==\"}","{\"result URL:\":\"/payment?id=8&pay=result\",\"success URL:\":\"/payment?id=8&pay=success\",\"fail URL:\":\"/payment?id=8&pay=fail\"}","0","8","fiz","","","0"),
("9","old#9","PayAnyWay","","0","{\"Номер расширенного счета\":\"\",\"Код проверки целостности данных\":\"\",\"Тестовый режим\":\"ZmFsc2VoWSo2bms3ISEjMnFq\",\"Метод шифрования\":\"bWQ1aFkqNm5rNyEhIzJxag==\",\"НДС на товары\":\"MTEwNWhZKjZuazchISMycWo=\"}","{\"result URL:\":\"/payment?id=9&pay=result\",\"success URL:\":\"/payment?id=9&pay=success\",\"fail URL:\":\"/payment?id=9&pay=fail\"}","0","9","fiz","","","0"),
("10","old#10","PayMaster","","0","{\"ID магазина\":\"\",\"Секретный ключ\":\"\",\"Метод шифрования\":\"bWQ1aFkqNm5rNyEhIzJxag==\",\"Использовать онлайн кассу\":\"ZmFsc2VoWSo2bms3ISEjMnFq\",\"НДС, включенный в цену\":\"MjAlaFkqNm5rNyEhIzJxag==\"}","{\"result URL:\":\"/payment?id=10&pay=result\",\"success URL:\":\"/payment?id=10&pay=success\",\"fail URL:\":\"/payment?id=10&pay=fail\"}","0","10","fiz","","","0"),
("11","old#11","AlfaBank","","1","{\"Логин\":\"\",\"Пароль\":\"\",\"Адрес сервера\":\"\",\"Метод шифрования\":\"bWQ1aFkqNm5rNyEhIzJxag==\", \"Код валюты\":\"\", \"НДС на товары\":\"MGhZKjZuazchISMycWo=\", \"Использовать онлайн кассу\":\"ZmFsc2VoWSo2bms3ISEjMnFq\"}","{\"result URL:\":\"/payment?id=11&pay=result\",\"success URL:\":\"/payment?id=11&pay=success\",\"fail URL:\":\"/payment?id=11&pay=fail\"}","0","11","fiz","","","0"),
("14","old#14","Ю.Касса (HTTP)","","0","{\"Ссылка для отправки данных\":\"\",\"Идентификатор магазина\":\"\",\"Идентификатор витрины\":\"\",\"shopPassword\":\"\",\"Метод шифрования\":\"bWQ1aFkqNm5rNyEhIzJxag==\",\"Использовать онлайн кассу\":\"ZmFsc2VoWSo2bms3ISEjMnFq\",\"НДС, включенный в цену\":\"MjAlaFkqNm5rNyEhIzJxag==\"}","{\"result URL:\":\"/payment?id=14&pay=result\",\"success URL:\":\"/payment?id=14&pay=success\",\"fail URL:\":\"/payment?id=14&pay=fail\"}","0","12","fiz","","","0"),
("15","old#15","Приват24","","0","{\"ID мерчанта\":\"\",\"Пароль марчанта\":\"\"}","","0","13","fiz","","","0"),
("16","old#16","LiqPay","","0","{\"Публичный ключ\":\"\",\"Приватный ключ\":\"\",\"Тестовый режим\":\"\"}","","0","14","fiz","","","0"),
("17","old#17","Сбербанк","","1","{\"API Логин\":\"\",\"Пароль\":\"\",\"Адрес сервера\":\"\",\"Использовать онлайн кассу\":\"ZmFsc2VoWSo2bms3ISEjMnFq\",\"Система налогообложения\":\"MGhZKjZuazchISMycWo=\",\"НДС на товары\":\"M2hZKjZuazchISMycWo=\",\"НДС на доставку\":\"M2hZKjZuazchISMycWo=\",\"Код валюты\":\"\"}","{\"callback URL:\":\"/payment?id=17&pay=result\"}","0","15","fiz","","","0"),
("18","old#18","Тинькофф","","1","{\"Ключ терминала\":\"\",\"Секретный ключ\":\"\",\"Адрес сервера\":\"\",\"Использовать онлайн кассу\":\"ZmFsc2VoWSo2bms3ISEjMnFq\",\"Система налогообложения\":\"b3NuaFkqNm5rNyEhIzJxag==\",\"НДС на товары\":\"dmF0MjBoWSo2bms3ISEjMnFq\",\"НДС на доставку\":\"dmF0MjBoWSo2bms3ISEjMnFq\",\"Email продавца\":\"\"}","{\"result URL:\":\"/payment?id=18&pay=result\"}","0","16","fiz","","","0"),
("19","old#19","PayPal","","0","{\"Токен идентичности\":\"\",\"Email продавца\":\"\",\"Тестовый режим\":\"dHJ1ZWhZKjZuazchISMycWo=\"}","{\"result URL:\":\"/payment?id=19&pay=result\"}","0","19","fiz","","","0"),
("20","old#20","Comepay: интернет-эквайринг и прием платежей","","0","{\"Идентификатор магазина\":\"\",\"Номер магазина\":\"\",\"Пароль магазина\":\"\",\"Callback Password\":\"\",\"Время жизни счета в часах\":\"\",\"Тестовый режим\":\"ZmFsc2VoWSo2bms3ISEjMnFq\",\"Comepay URL\":\"aHR0cHM6Ly9hY3Rpb25zaG9wLmNvbWVwYXkucnVoWSo2bms3ISEjMnFq\",\"Comepay test URL\":\"aHR0cHM6Ly9tb25leXRlc3QuY29tZXBheS5ydTo0NDloWSo2bms3ISEjMnFq\",\"Разрешить печать чеков в ККТ\":\"ZmFsc2VoWSo2bms3ISEjMnFq\",\"НДС на товары\":\"M2hZKjZuazchISMycWo=\",\"НДС на доставку\":\"M2hZKjZuazchISMycWo=\",\"Признак способа расчёта\":\"NGhZKjZuazchISMycWo=\"}","{\"result URL:\":\"/payment?id=20&pay=result\",\"success URL:\":\"/payment?id=20&pay=success\",\"fail URL:\":\"/payment?id=20&pay=fail\"}","0","20","fiz","","","0"),
("21","old#21","Онлайн оплата (payKeeper)","","0","{\"Язык страницы оплаты\":\"\",\"ID Магазина\":\"=\",\"Секретный ключ\":\"=\",\"Система налогообложения\":\"bm9uZWhZKjZuazchISMycWo=\"}","{\"result URL:\":\"/payment?id=21&pay=result\",\"success URL:\":\"/payment?id=21&pay=success\",\"fail URL:\":\"/payment?id=21&pay=fail\"}","0","21","all","","","0"),
("22","old#22","CloudPayments","","0","{\"Public ID\":\"\",\"Секретный ключ\":\"\",\"Схема проведения платежа\":\"Y2hhcmdlaFkqNm5rNyEhIzJxag==\",\"Дизайн виджета\":\"Y2xhc3NpY2hZKjZuazchISMycWo=\",\"Язык виджета\":\"cnUtUlVoWSo2bms3ISEjMnFq\",\"Использовать онлайн кассу\":\"\",\"Инн\":\"\",\"Система налогообложения\":\"dHNfMGhZKjZuazchISMycWo=\",\"Ставка НДС\":\"dmF0XzIwaFkqNm5rNyEhIzJxag==\",\"Ставка НДС для доставки\":\"dmF0XzIwaFkqNm5rNyEhIzJxag==\",\"Способ расчета\":\"MWhZKjZuazchISMycWo=\",\"Предмет расчета\":\"MWhZKjZuazchISMycWo=\",\"Статус заказа для печати второго чека\":\"M2hZKjZuazchISMycWo=\"}","{\"Check URL:\":\"/payment?id=22&pay=result&action=check\",\"Pay URL:\":\"/payment?id=22&pay=result&action=pay\",\"Confirm URL:\":\"/payment?id=22&pay=result&action=confirm\",\"Fail URL:\":\"/payment?id=22&pay=result&action=fail\",\"Refund URL:\":\"/payment?id=22&pay=result&action=refund\",\"Cancel URL:\":\"/payment?id=22&pay=result&action=cancel\"}","0","22","fiz","","","0"),
("23","old#23","Заплатить по частям от Ю.Кассы","","0","","","0","23","fiz","","","0"),
("24","old#24","Ю.Касса (API)","","1","{\"shopid\":\"\",\"api_key\":\"\",\"Использовать онлайн кассу\":\"ZmFsc2VoWSo2bms3ISEjMnFq\",\"НДС, включенный в цену\":\"MjAlaFkqNm5rNyEhIzJxag==\"}","{\"Check URL:\":\"/payment?id=24\"}","0","24","fiz","","","0"),
("25","old#25","Apple Pay от Ю.Кассы","","0","{\"MerchantIdentifier\":\"\",\"MerchantName\":\"\",\"Password\":\"\",\"CertPath\":\"\",\"KeyPath\":\"\"}","","0","25","fiz","","","0"),
("26","old#26","FREE-KASSA","","0","{\"Язык страницы оплаты\":\"\", \"ID Магазина\":\"\", \"Секретный ключ1\":\"\", \"Секретный ключ2\":\"\", \"Валюта\":\"\"}","{\"URL оповещения:\":\"/payment?id=26&pay=result\",\"URL возврата в случае успеха:\":\"/payment?id=26&pay=success\",\"URL возврата в случае неудачи:\":\"/payment?id=26&pay=fail\"}","0","26","fiz","","","0"),
("27","old#27","Мегакасса","","0","{\"ID магазина\":\"\", \"Секретный ключ\":\"\"}","{\"result URL:\":\"/payment?id=27&pay=result\",\"success URL:\":\"/payment?id=27&pay=success\",\"fail URL:\":\"/payment?id=27&pay=fail\"}","0","27","fiz","","","0"),
("28","old#28","Qiwi (API)","","1","{\"Публичный ключ\":\"\", \"Секретный ключ\":\"\"}","{\"result URL:\":\"/payment?id=28&pay=result\"}","0","28","fiz","","","0"),
("29","old#29","intellectmoney","","0","{\"ID магазина\":\"\",\"Секретный ключ\":\"\",\"ИНН\":\"\",\"Использовать онлайн кассу\":\"ZmFsc2VoWSo2bms3ISEjMnFq\",\"Тестовый режим\":\"\",\"НДС на товары\":\"MmhZKjZuazchISMycWo=\",\"НДС на доставку\":\"NmhZKjZuazchISMycWo=\"}","{\"result URL:\":\"/payment?id=29&pay=result\"}","0","29","fiz","","","0"),
("30","old#30","beGateway","","0","{\"Shop ID\":\"\",\"Shop Secret Key\":\"\",\"Shop Public Key\":\"\",\"Payment Domain\":\"\",\"Тестовый режим\":\"dHJ1ZWhZKjZuazchISMycWo=\"}","{\"result URL:\":\"/payment?id=30&pay=result\",\"success URL:\":\"/payment?id=30&pay=success\",\"fail URL:\":\"/payment?id=30&pay=fail\"}","0","30","fiz","","","0"),
("31","old#31","Оплата по QR","","0","","","0","31","fiz","","","0"),
("1001","custom#1001","Наложенный платеж","Наложенный платеж","1","[{\"name\":\"description\",\"title\":\"Примечание\",\"type\":\"text\",\"value\":\"\"}]","","0","1001","fiz","","","0"),
("1002","custom#1002","Наличные (курьеру)","Наличные (курьеру)","1","[{\"name\":\"description\",\"title\":\"Примечание\",\"type\":\"text\",\"value\":\"\"}]","","0","1002","fiz","","","0"),
("1003","custom#1003","Оплата через менеджера","Оплата через менеджера","1","[{\"name\":\"description\",\"title\":\"Примечание\",\"type\":\"text\",\"value\":\"\"}]","","0","1003","yur","","","0");
DROP TABLE IF EXISTS `mg_plugins`;

CREATE TABLE `mg_plugins` (
  `folderName` varchar(249) NOT NULL,
  `active` tinyint(1) NOT NULL,
  `template` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


INSERT INTO `mg_plugins` VALUES
("back-ring","0",""),
("comments","1",""),
("daily-product","0",""),
("mg-gallery","1",""),
("p4-images","1","");
DROP TABLE IF EXISTS `mg_product`;

CREATE TABLE `mg_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sort` int(11) DEFAULT NULL,
  `cat_id` int(11) NOT NULL,
  `title` varchar(249) NOT NULL,
  `description` longtext,
  `price` double NOT NULL,
  `url` varchar(191) NOT NULL,
  `image_url` text,
  `code` varchar(191) NOT NULL,
  `count` float NOT NULL,
  `activity` tinyint(1) NOT NULL,
  `meta_title` text,
  `meta_keywords` text,
  `meta_desc` text,
  `old_price` varchar(249) DEFAULT NULL,
  `recommend` tinyint(4) NOT NULL DEFAULT '0',
  `new` tinyint(4) NOT NULL DEFAULT '0',
  `related` text,
  `inside_cat` text,
  `1c_id` varchar(191) NOT NULL DEFAULT '',
  `weight` double DEFAULT NULL,
  `link_electro` varchar(1024) DEFAULT NULL,
  `currency_iso` varchar(249) DEFAULT NULL,
  `price_course` double DEFAULT NULL,
  `image_title` text,
  `image_alt` text,
  `yml_sales_notes` text,
  `count_buy` int(11) NOT NULL DEFAULT '0',
  `system_set` int(11) DEFAULT NULL,
  `related_cat` text,
  `short_description` longtext,
  `last_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `unit` varchar(249) DEFAULT NULL,
  `weight_unit` varchar(10) DEFAULT NULL,
  `multiplicity` float NOT NULL DEFAULT '1',
  `storage_count` float DEFAULT '0',
  `opf_1` text NOT NULL,
  `opf_2` text NOT NULL,
  `opf_3` text NOT NULL,
  `opf_4` text NOT NULL,
  `opf_5` text NOT NULL,
  `opf_6` text NOT NULL,
  `opf_7` text NOT NULL,
  `opf_8` text NOT NULL,
  `opf_9` text NOT NULL,
  `opf_10` text NOT NULL,
  `opf_11` text NOT NULL,
  `opf_12` text NOT NULL,
  `opf_13` text NOT NULL,
  `opf_14` text NOT NULL,
  `opf_15` text NOT NULL,
  `opf_16` text NOT NULL,
  `opf_17` text NOT NULL,
  `opf_18` text NOT NULL,
  `opf_19` text NOT NULL,
  `opf_20` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `1c_id` (`1c_id`),
  KEY `id` (`id`),
  KEY `cat_id` (`cat_id`),
  KEY `url` (`url`),
  KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4;


INSERT INTO `mg_product` VALUES
("1","53","1","Red Naomi","Роза, ставшая эталоном одноголовых роз.<br />\nПервая роза, выращенная нами<br />\n<strong>50-80 см</strong>","0","red-naomi","47bdadc9ddd098f0d66ad403f8d69f5d_2024-10-26_20-18-17.jpeg","CN1","-1","1","Red Naomi","Red Naomi, Red, Naomi","{description}","","0","0","","","","0","","RUR","0","","","","0","1","","","2024-10-26 20:18:20","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("2","1","1","Avalanche","Роза, цвета утреннего тумана, окутавшего зеленую траву после обильного дождя<br />\n<strong>50-80 см</strong>","0","avalanche","avalanchenew.jpg","CN2","-1","1","Avalanche","Avalanche, Avalanche","{description}","","0","0","","","","0","","RUR","0","","","","0","1","","","2024-10-31 13:36:04","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("3","39","1","Aqua","Розовая классика, без которой не обойдется ни одно свадебное торжество<br />\n<strong>50-70 см</strong>","0","aqua","Aqua.jpg","CN3","-1","1","Aqua","Aqua, Aqua","{description}","","0","0","","","","0","","RUR","0","","","","0","1","","","2024-10-25 15:30:35","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("4","41","1","Annakarina","Аккуратно сложенная роза с лепестками кораллового оттенка<br />\n<strong>50-80 см</strong>","0","annakarina","Annakarina.jpg","CN4","-1","1","Annakarina","Annakarina, Annakarina","{description}","","0","0","","","","0","","RUR","0","","","","0","1","","","2024-10-25 15:30:35","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("5","14","1","Bubblegum","Садовая роза с насыщенной малиновой-розовой окраской и сладковатым ароматом<br />\n<strong>60-70 см</strong>","0","bubblegum","Bubblegum.jpg","CN5","-1","1","Bubblegum","Bubblegum, Bubblegum","{description}","","0","1","","","","0","","RUR","0","","","","0","1","","","2024-10-25 15:30:35","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("7","5","1","White Naomi","Популярный сорт белой розы с приятным ароматом<br />\n<strong>50-80 см</strong>","0","white-naomi","White-Naomi.jpg","CN7","-1","1","White Naomi","White Naomi, White, Naomi","{description}","","0","0","","","","0","","RUR","0","","","","0","1","","","2024-10-25 15:30:35","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("8","54","1","Jumilia","Роза с крупным и ярким бутоном. Вечная классика<br />\n<strong>50-80 см</strong>","0","jumilia","Jumilia.jpg","CN8","-1","1","Jumilia","Jumilia, Jumilia","{description}","","0","0","","","","0","","RUR","0","","","","0","1","","","2024-10-25 15:30:35","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("9","29","1","Zaina","Нежно розовое чудо с крупным красивом бутоном в нашей коллекции<br />\n60-70 см","0","zaina","Zaina-kopiya.jpg","CN9","-1","1","Zaina","Zaina, Zaina","{description}","","0","1","","","","0","","RUR","0","","","","0","1","","","2024-10-25 15:30:35","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("10","49","1","Xena","Роза цвета рассветной дымки над озером, идеальна для оформления интерьеров<br />\n<strong>50-70 см</strong>","0","xena","Xena.jpg","CN10","-1","1","Xena","Xena, Xena","{description}","","0","1","","","","0","","RUR","0","","","","0","1","","","2024-10-25 15:30:35","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("11","7","1","Ilios","Очень стойкая одноголовая роза цвета сочного лимона<br />\n<strong>50-70 см</strong>","0","ilios","Ilios.jpg","CN11","-1","1","Ilios","Ilios, Ilios","{description}","","0","0","","","","0","","RUR","0","","","","0","1","","","2024-10-25 15:30:35","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("12","16","1","Kimberly","Идеальная комбинация розовато-персикового оттенка и приятного аромата в одной розе<br />\n<strong>50-80 см</strong>","0","kimberly","Kimberly.jpg","CN12","-1","1","Kimberly","Kimberly, Kimberly","{description}","","0","0","","","","0","","RUR","0","","","","0","1","","","2024-10-25 15:30:35","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("13","17","1","Clarence","Стойкая роза с пламенным оттенком оранжевого<br />\n<strong>50-70 см</strong>","0","clarence","Clarence.jpg","CN13","-1","1","Clarence","Clarence, Clarence","{description}","","0","0","","","","0","","RUR","0","","","","0","1","","","2024-10-25 15:30:35","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("14","47","1","Maritim","Роза прохладного сиреневого цвета. Добавит частичку волшебства в любой букет<br />\n<strong>50-70 см</strong>","0","maritim","Maritim.jpg","CN14","-1","1","Maritim","Maritim, Maritim","{description}","","0","0","","","","0","","RUR","0","","","","0","1","","","2024-10-25 15:30:35","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("15","10","1","Miss Piggy","Роза с кокетливым названием, светло-розовая снаружи и персиковая внутри<br />\n<strong>50-70 см</strong>","0","miss-piggy","Miss-Piggy.jpg","CN15","-1","1","Miss Piggy","Miss Piggy, Miss, Piggy","{description}","","0","0","","","","0","","RUR","0","","","","0","1","","","2024-10-25 15:30:35","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("16","9","1","Penny lane","Ярко-желтая роза, вызывающая воспоминания о солнце, лете и тепле<br />\n<strong>50-80 см</strong>","0","penny-lane","Penny-lane.jpg","CN16","-1","1","Penny lane","Penny lane, Penny, lane","{description}","","0","0","","","","0","","RUR","0","","","","0","1","","","2024-10-25 15:30:35","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("17","18","1","Peach Avalanche","Кремовая одноголовая роза с классическим раскрытием<br />\n<strong>50-80 см</strong>","0","peach-avalanche","Peach-Avalanche-.jpg","CN17","-1","1","Peach Avalanche","Peach Avalanche, Peach, Avalanche","{description}","","0","0","","","","0","","RUR","0","","","","0","1","","","2024-10-25 15:30:35","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("18","43","1","Revival","Нежно розовая одноголовая роза с классическим раскрытием<br />\n<strong>50-80 см</strong>","0","revival","Revival.jpg","CN18","-1","1","Revival","Revival, Revival","{description}","","0","0","","","","0","","RUR","0","","","","0","1","","","2024-10-25 15:30:35","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("19","12","1","Saida","Волшебная роза кораллового оттенка с большим бутоном<br />\n<strong>50-70 см</strong>","0","saida","Saida.jpg","CN19","-1","1","Saida","Saida, Saida","{description}","","0","0","","","","0","","RUR","0","","","","0","1","","","2024-10-25 15:30:35","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("20","32","1","Sweet Avalanche","Великолепная роза, без которой ни обойдется ни один свадебный букет<br />\n<strong>50-80 см</strong>","0","sweet-avalanche","Sweet-Avalanche.jpg","CN20","-1","1","Sweet Avalanche","Sweet Avalanche, Sweet, Avalanche","{description}","","0","0","","","","0","","RUR","0","","","","0","1","","","2024-10-25 15:30:35","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("21","33","1","Sweet Revival","Бело-розовая роза, с крупным бутоном, похожая на детский леденец<br />\n<strong>50-80 см</strong>","0","sweet-revival","Sweet-Revival.jpg","CN21","-1","1","Sweet Revival","Sweet Revival, Sweet, Revival","{description}","","0","0","","","","0","","RUR","0","","","","0","1","","","2024-10-25 15:30:35","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("22","20","1","Talea","Классическая роза кремового цвета переходящего в нежно розовый к середине бутона<br />\n<strong>50-80 см</strong>","0","talea","Talea-(1)-kopiya.jpg","CN22","-1","1","Talea","Talea, Talea","{description}","","0","0","","","","0","","RUR","0","","","","0","1","","","2024-10-25 15:30:35","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("23","56","1","Shangri La","Загадочная малиново-красная роза с притягательным ароматом<br />\n<strong>50-80 см</strong>","0","shangri-la","Shangri-La.jpg","CN23","-1","1","Shangri La","Shangri La, Shangri, La","{description}","","0","0","","","","0","","RUR","0","","","","0","1","","","2024-10-25 15:30:35","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("24","57","1","El Toro","Роза, как яркое пламя, горящее на фоне зеленой листвы<br />\n<strong>40-70 см</strong>","0","el-toro","El-Toro.jpg","CN24","-1","1","El Toro","El Toro, El, Toro","{description}","","0","0","","","","0","","RUR","0","","","","0","1","","","2024-10-25 15:30:35","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("25","25","1","Espana","Двухцветная роза, цвета спелой вишни снаружи и солнечно-янтарная внутри<br />\n<strong>50-80 см</strong>","0","espana","Espana.jpg","CN25","-1","1","Espana","Espana, Espana","{description}","","0","0","","","","0","","RUR","0","","","","0","1","","","2024-10-25 15:30:35","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("26","27","1","Mandala","Новый фаворит одноголовой розы с крупным бутоном и великолепным раскрытием<br />\n<strong>50-80 см</strong>","0","mandala","Mandala.jpg","CN26","-1","1","Mandala","Mandala, Mandala","{description}","","0","1","","","","0","","RUR","0","","","","0","1","","","2024-10-25 15:30:35","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("27","59","2","Ivori Dedication","","0","ivori-dedication","","CN27","-1","0","Ivori Dedication","Ivori Dedication, Ivori, Dedication","{description}","","0","0","","","","0","","RUR","0","","","","0","1","","","2024-11-12 11:54:54","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("28","21","2","Apricot Lace","Невероятно стойкое кустовая роза - абрикосовое совершенство<br />\n<strong>50-70 см</strong>","0","apricot-lace","Apricot-Lace-kopiya-2.jpg","CN28","-1","1","Apricot Lace","Apricot Lace, Apricot, Lace","{description}","","0","0","","","","0","","RUR","0","","","","0","1","","","2024-10-25 15:30:35","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("29","44","2","Aerobic","Классическая кустовая роза нежно-розового цвета<br />\n<strong>50-70 см</strong>","0","aerobic","Aerobic-kopiya.jpg","CN29","-1","1","Aerobic","Aerobic, Aerobic","{description}","","0","0","","","","0","","RUR","0","","","","0","1","","","2024-10-25 15:30:35","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("30","34","2","Bombastic","Классика пионовидной кустовой розы пудрового оттенка<br />\n<strong>50-70 см</strong>","0","bombastic","Bombastic-kopiya.jpg","CN30","-1","1","Bombastic","Bombastic, Bombastic","{description}","","0","0","","","","0","","RUR","0","","","","0","1","","","2024-10-25 15:30:35","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("31","23","2","Birds Song","<p>\n	Новая эксклюзивная кустовая роза цвета топленого молока с серединкой, уходящей в мокко<br />\n	<strong>50-70 см</strong>\n</p>","0","birds-song","Bird-Song-.jpg","CN31","-1","1","Birds Song","Birds Song, Birds, Song","{description}","","0","1","","","","0","","RUR","0","","","","0","1","","","2024-10-25 15:30:35","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("32","30","2","Dedication","Роза - гроздь маленьких пионов бело-розового цвета на одной ветке<br />\n<strong>50-70 см</strong>","0","dedication","Dedication.jpg","CN32","-1","1","Dedication","Dedication, Dedication","{description}","","0","0","","","","0","","RUR","0","","","","0","1","","","2024-10-25 15:30:35","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("33","19","2","Josephine","Прекрасная белая кустовая роза, идеально подходящая для украшения свадеб<br />\n<strong>50-70 см</strong>","0","josephine","Josephina.jpg","CN33","-1","1","Josephine","Josephine, Josephine","{description}","","0","0","","","","0","","RUR","0","","","","0","1","","","2024-10-25 15:30:35","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("34","48","2","Lavender Bubbles","Роза необычного лавандового цвета с крупными бутонами идеальной формы<br />\n<strong>50-70 см</strong>","0","lavender-bubbles","Lavender-Bubbles--kopiya.jpg","CN34","-1","1","Lavender Bubbles","Lavender Bubbles, Lavender, Bubbles","{description}","","0","0","","","","0","","RUR","0","","","","0","1","","","2024-10-25 15:30:35","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("35","50","2","Lady Bombastic","Классика пионовидной кустовой розы пурпурного оттенка<br />\n<strong>50-70 см</strong>","0","lady-bombastic","Lady-Bombastic.jpg","CN35","-1","1","Lady Bombastic","Lady Bombastic, Lady, Bombastic","{description}","","0","0","","","","0","","RUR","0","","","","0","1","","","2024-10-25 15:30:35","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("36","2","2","Luna Trendsetter","Кустовая роза, как яркое весеннее солнце, освежит любую композицию<br />\n<strong>50-70 см</strong>","0","luna-trendsetter","Luna-Trendsetter--kopiya.jpg","CN36","-1","1","Luna Trendsetter","Luna Trendsetter, Luna, Trendsetter","{description}","","0","0","","","","0","","RUR","0","","","","0","1","","","2024-10-25 15:30:35","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("37","31","2","Madam Bombastic","Лидер продаж, классика пионовидной кустовой розы с крупным бутоном<br />\n<strong>50-70 см</strong>","0","madam-bombastic","Madam-Bombastic.jpg","CN37","-1","1","Madam Bombastic","Madam Bombastic, Madam, Bombastic","{description}","","1","0","","","","0","","RUR","0","","","","0","1","","","2024-10-25 15:30:35","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("38","40","2","Mansfield Park","Роза-бестселлер, элегантная кустовая роза перламутрового цвета<br />\n<strong>50-70 см</strong>","0","mansfield-park","Mansfield-Park.jpg","CN38","-1","1","Mansfield Park","Mansfield Park, Mansfield, Park","{description}","","1","0","","","","0","","RUR","0","","","","0","1","","","2024-10-25 15:30:35","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("39","36","2","Mansfield Pink Park","Роза-бестселлер, элегантная кустовая роза цвета сахарной ваты<br />\n<strong>50-70 см</strong>","0","mansfield-pink-park","Mansfield-Pink-Park.jpg","CN39","-1","1","Mansfield Pink Park","Mansfield Pink Park, Mansfield, Pink, Park","{description}","","0","0","","","","0","","RUR","0","","","","0","1","","","2024-10-25 15:30:35","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("40","52","2","Misty Bubbles","Самая таинственная кустовая роза в нашем ассортименте<br />\n<strong>50-70 см</strong>","0","misty-bubbles","Misty-Bubbles-kopiya.jpg","CN40","-1","1","Misty Bubbles","Misty Bubbles, Misty, Bubbles","{description}","","0","0","","","","0","","RUR","0","","","","0","1","","","2024-10-25 15:30:35","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("41","42","2","Pink Dimension","Кустовая роза цвета ярко-розовой неоновой вывески<br />\n<strong>50-70 см</strong>","0","pink-dimension","Pink-Dimension-kopiya.jpg","CN41","-1","1","Pink Dimension","Pink Dimension, Pink, Dimension","{description}","","0","0","","","","0","","RUR","0","","","","0","1","","","2024-10-25 15:30:35","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("42","11","2","Peach Dimension","Нежно-розовая кустовая роза с пионовидным раскрытием, новая в нашей коллекции<br />\n<strong>50-70 см</strong>","0","peach-dimension","Peach-Dimension-(1)-kopiya-2.jpg","CN42","-1","1","Peach Dimension","Peach Dimension, Peach, Dimension","{description}","","0","1","","","","0","","RUR","0","","","","0","1","","","2024-10-25 15:30:35","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("43","4","2","Peony Bubbles","Роскошная бледно желтая кустовая садовая роза, создающая атмосферу нежности и свежести<br />\n<strong>50-70 см</strong>","0","peony-bubbles","Peony-Bubbles-kopiya.jpg","CN43","-1","1","Peony Bubbles","Peony Bubbles, Peony, Bubbles","{description}","","0","0","","","","0","","RUR","0","","","","0","1","","","2024-10-25 15:30:35","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("44","6","2","Royal Park","Королевская роза кремового цвета, очень стойкая классическая садовая кустовая роза<br />\n<strong>50-70 см</strong>","0","royal-park","Royal-Park.jpg","CN44","-1","1","Royal Park","Royal Park, Royal, Park","{description}","","0","0","","","","0","","RUR","0","","","","0","1","","","2024-10-25 15:30:35","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("45","26","2","Royal Porcelina","Полностью оправдывающая свое название «фарфоровая» роза с невероятным ароматом<br />\n<strong>50-70 см</strong>","0","royal-porcelina","Royal-Porselina.jpg","CN45","-1","1","Royal Porcelina","Royal Porcelina, Royal, Porcelina","{description}","","0","0","","","","0","","RUR","0","","","","0","1","","","2024-10-25 15:30:35","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("46","35","2","Sweet Dimension","Нежно розовая по цвету и дерзкая по форме лепестков кустовая роза<br />\n<strong>50-70 см</strong>","0","sweet-dimension","Sweet-d.jpg","CN46","-1","1","Sweet Dimension","Sweet Dimension, Sweet, Dimension","{description}","","0","0","","","","0","","RUR","0","","","","0","1","","","2024-10-25 15:30:35","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("47","38","2","Silva Pink","Невероятно красивый сорт садовой кустовой розы с самыми крупными бутонами<br />\n<strong>50-70 см</strong>","0","silva-pink","Silva-Pink.jpg","CN47","-1","1","Silva Pink","Silva Pink, Silva, Pink","{description}","","0","0","","","","0","","RUR","0","","","","0","1","","","2024-10-25 15:30:35","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("48","55","2","Scarlet Dimension","Ярко-алая страстная кустовая роза, с невероятным ароматом<br />\n<strong>50-70 см</strong>","0","scarlet-dimension","DSC03313-kopiya.jpg","CN48","-1","1","Scarlet Dimension","Scarlet Dimension, Scarlet, Dimension","{description}","","0","0","","","","0","","RUR","0","","","","0","1","","","2024-10-25 15:30:35","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("49","46","2","Sofie","Элегантная светлая кустовая роза с большим бутоном<br />\n<strong>50-70 см</strong>","0","sofie","Sofi.jpg","CN49","-1","1","Sofie","Sofie, Sofie","{description}","","0","0","","","","0","","RUR","0","","","","0","1","","","2024-10-25 15:30:35","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("50","24","2","Tanja","Классическая кустовая роза с бутонами цвета заварного крема<br />\n<strong>40-70 см</strong>","0","tanja","Tanja-(1)-kopiya.jpg","CN50","-1","1","Tanja","Tanja, Tanja","{description}","","0","0","","","","0","","RUR","0","","","","0","1","","","2024-10-25 15:30:35","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("51","58","2","Fireworks","Ягодный десерт. Клубнично-красные штрихи, разбавленные молочными брызгами<br />\n<strong>50-70 см</strong>","0","fireworks","Fireworks-(1)-kopiya.jpg","CN51","-1","1","Fireworks","Fireworks, Fireworks","{description}","","0","0","","","","0","","RUR","0","","","","0","1","","","2024-10-25 15:30:35","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("52","28","2","Femke","Коралловая кустовая роза с пионовидным бутоном<br />\n<strong>50-70 см</strong>","0","femke","Femke-kopiya.jpg","CN52","-1","1","Femke","Femke, Femke","{description}","","0","0","","","","0","","RUR","0","","","","0","1","","","2024-10-25 15:30:35","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("53","3","3","Buttercup","Садовая роза с потрясающим раскрытием, теплого цвета меда или топленого масла<br />\n<strong>50-70 см</strong>","0","buttercup","Buttercup-.jpg","CN53","-1","1","Buttercup","Buttercup, Buttercup","{description}","","0","0","","","","0","","RUR","0","","","","0","1","","","2024-10-25 15:30:35","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("54","13","3","London Eye","Восхитительная садовая роза с пышным бутоном теплого кораллового оттенка<br />\n<strong>50-70 см</strong>","0","london-eye","London-Eye-(1)-kopiya.jpg","CN54","-1","1","London Eye","London Eye, London, Eye","{description}","","0","0","","","","0","","RUR","0","","","","0","1","","","2024-10-25 15:30:35","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("55","45","3","Montmartre","Стойкая садовая роза с винтажным фиолетовым оттенком<br />\n<strong>50-70 см</strong>","0","montmartre","Montmartre-kopiya.jpg","CN55","-1","1","Montmartre","Montmartre, Montmartre","{description}","","0","0","","","","0","","RUR","0","","","","0","1","","","2024-10-25 15:30:35","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("56","51","3","Notre Dame","Садовая роза, меняющая оттенок от кремово-коричневого до серебристо-лавандового, идеально вписывающаяся в любой интерьер<br />\n<strong>50-70 см</strong>","0","notre-dame","Notre-Dame-kopiya.jpg","CN56","-1","1","Notre Dame","Notre Dame, Notre, Dame","{description}","","0","1","","","","0","","RUR","0","","","","0","1","","","2024-10-25 15:30:35","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("57","22","3","Priscilla","Крепкая и сильная садовая роза с классическим чашевидным бутоном кремового цвета с солнечным отливом<br />\n<strong>50-70 см</strong>","0","priscilla","Priscilla.jpg","CN57","-1","1","Priscilla","Priscilla, Priscilla","{description}","","0","1","","","","0","","RUR","0","","","","0","1","","","2024-10-25 15:30:35","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("58","37","3","Regent`s Park","Первая садовая роза в нашем ассортименте, ярко розовая, с зеленой сердцевиной<br />\n<strong>50-70 см</strong>","0","regents-park","Regent’s-Park-kopiya.jpg","CN58","-1","1","Regent`s Park","Regent`s Park, Regent`s, Park","{description}","","0","0","","","","0","","RUR","0","","","","0","1","","","2024-10-25 15:30:35","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("59","15","3","Chiffon","Огромный бутон и мягкий розовый оттенок лепестков розы, делают ее абсолютным фаворитом свадебных композиций<br />\n<strong>50-70 см</strong>","0","chiffon","Chiffon-(2)-kopiya.jpg","CN59","-1","1","Chiffon","Chiffon, Chiffon","{description}","","0","0","","","","0","","RUR","0","","","","0","1","","","2024-10-25 15:30:35","","kg","1","0","","","","","","","","","","","","","","","","","","","",""),
("60","8","1","Beluga","Роза белоснежного оттенка, как олицетворение чистоты и свежести<br />\n<strong>50-80 см</strong>","0","beluga","beluganew.jpg","CN60","-1","1","Beluga","Beluga, Beluga","{description}","","0","0","","","","0","","RUR","0","","","","0","1","","","2024-10-31 13:36:51","","kg","1","0","","","","","","","","","","","","","","","","","","","","");
DROP TABLE IF EXISTS `mg_product_on_storage`;

CREATE TABLE `mg_product_on_storage` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `storage` varchar(191) NOT NULL,
  `product_id` int(11) NOT NULL,
  `variant_id` int(11) NOT NULL,
  `count` float NOT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `variant_id` (`variant_id`),
  KEY `storage` (`storage`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_product_opt_fields`;

CREATE TABLE `mg_product_opt_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text,
  `is_price` tinyint(1) DEFAULT '0',
  `sort` int(11) DEFAULT NULL,
  `active` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4;


INSERT INTO `mg_product_opt_fields` VALUES
("1","Типовое соглашение к1","1","1","0"),
("2","Типовое соглашение к2","1","1","0"),
("3","Типовое соглашение к3","1","2","0"),
("4","Типовое соглашение к4","1","3","0"),
("5","Типовое соглашение к5","1","4","0"),
("6","Типовое соглашение к6","1","5","0"),
("7","Типовое соглашение к7","1","6","0"),
("8","Типовое соглашение к8","1","7","0"),
("9","Типовое соглашение к9","1","8","0"),
("10","Типовое соглашение к10","1","9","0"),
("11","Типовое соглашение к11","1","10","0"),
("12","Типовое соглашение к12","1","11","0"),
("13","Типовое соглашение к13","1","12","0"),
("14","Типовое соглашение к14","1","13","0"),
("15","Типовое соглашение к15","1","14","0"),
("16","Типовое соглашение к16","1","15","0"),
("17","Типовое соглашение к17","1","16","0"),
("18","Типовое соглашение к18","1","17","0"),
("19","Типовое соглашение к19","1","18","0"),
("20","Типовое соглашение к20","1","19","0");
DROP TABLE IF EXISTS `mg_product_rating`;

CREATE TABLE `mg_product_rating` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Порядковый номер записи',
  `id_product` int(11) NOT NULL COMMENT 'ID товара',
  `rating` double NOT NULL COMMENT 'Оценка',
  `count` int(11) NOT NULL COMMENT 'Количество голосов',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_product_user_property`;

CREATE TABLE `mg_product_user_property` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `property_id` int(11) NOT NULL,
  `value` text NOT NULL,
  `product_margin` text NOT NULL COMMENT 'наценка продукта',
  `type_view` enum('checkbox','select','radiobutton','') NOT NULL DEFAULT 'select',
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `property_id` (`property_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Таблица пользовательских свойств продуктов';


DROP TABLE IF EXISTS `mg_product_user_property_data`;

CREATE TABLE `mg_product_user_property_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `prop_id` int(11) NOT NULL,
  `prop_data_id` int(11) NOT NULL DEFAULT '0',
  `product_id` int(11) NOT NULL,
  `name` text,
  `margin` text,
  `type_view` text CHARACTER SET utf8 NOT NULL,
  `active` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `prop_id` (`prop_id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=209 DEFAULT CHARSET=utf8mb4;


INSERT INTO `mg_product_user_property_data` VALUES
("1","1","439","2","/uploads/image-content/avalanche/Avalanche777.png","","","1"),
("2","2","440","2","/uploads/image-content/avalanche/crop777.png","","","1"),
("3","3","206","2","/uploads/image-content/avalanche/Avalanche.jpg","","","1"),
("4","4","435","2","/uploads/image-content/avalanche/avalanche1440.jpg","","","1"),
("5","1","454","5","/uploads/image-content/bubblegum/Bubblegum777.png","","","1"),
("6","2","8","5","/uploads/image-content/bubblegum/DSC02984копия.jpg","","","1"),
("7","3","9","5","/uploads/image-content/bubblegum/Bubblegum.jpg","","","1"),
("8","1","444","7","/uploads/image-content/white-naomi/WhiteNaomi777.png","","","1"),
("9","2","209","7","/uploads/image-content/white-naomi/crop.jpg","","","1"),
("10","3","438","7","/uploads/image-content/white-naomi/WhiteNaomi1.jpg","","","1"),
("11","1","470","9","/uploads/image-content/zaina/Zaina777.png","","","1"),
("12","2","14","9","/uploads/image-content/zaina/DSC04516копия.jpg","","","1"),
("13","3","15","9","/uploads/image-content/zaina/Zainaкопия.jpg","","","1"),
("14","1","447","11","/uploads/image-content/ilios/Ilios777.png","","","1"),
("15","2","18","11","/uploads/image-content/ilios/Каталогбезназвания24831копия.jpg","","","1"),
("16","3","19","11","/uploads/image-content/ilios/Ilios.jpg","","","1"),
("17","1","457","12","/uploads/image-content/kimberly/Kimberly777.png","","","1"),
("18","2","21","12","/uploads/image-content/kimberly/crop.jpg","","","1"),
("19","3","22","12","/uploads/image-content/kimberly/Kimberly.jpg","","","1"),
("20","1","458","13","/uploads/image-content/clarence/Clarence777.png","","","1"),
("21","2","24","13","/uploads/image-content/clarence/DSC02811копия.jpg","","","1"),
("22","3","25","13","/uploads/image-content/clarence/DSC02816копия.jpg","","","1"),
("23","1","450","15","/uploads/image-content/miss-piggy/MissPiggy777.png","","","1"),
("24","2","212","15","/uploads/image-content/miss-piggy/crop.jpg","","","1"),
("25","3","213","15","/uploads/image-content/miss-piggy/MissPiggy.jpg","","","1"),
("26","4","370","15","/uploads/image-content/miss-piggy/miss-piggy-1440.jpg","","","1"),
("27","1","449","16","/uploads/image-content/penny-lane/Pennylane777.png","","","1"),
("28","2","33","16","/uploads/image-content/penny-lane/crop.jpg","","","1"),
("29","3","34","16","/uploads/image-content/penny-lane/Pennylane.jpg","","","1"),
("30","4","35","16","/uploads/image-content/penny-lane/DSC01553копия.jpg","","","1"),
("31","1","459","17","/uploads/image-content/peach-avalanche/PeachAvalanche777.png","","","1"),
("32","2","37","17","/uploads/image-content/peach-avalanche/crop.jpg","","","1"),
("33","3","38","17","/uploads/image-content/peach-avalanche/PeachAvalanche.jpg","","","1"),
("34","1","452","19","/uploads/image-content/saida/Saida777.png","","","1"),
("35","2","40","19","/uploads/image-content/saida/crop.jpg","","","1"),
("36","3","41","19","/uploads/image-content/saida/Saida.jpg","","","1"),
("37","1","473","20","/uploads/image-content/sweet-avalanche/SweetAvalanche777.png","","","1"),
("38","2","43","20","/uploads/image-content/sweet-avalanche/DSC00164копия.jpg","","","1"),
("39","3","44","20","/uploads/image-content/sweet-avalanche/SweetAvalanche.jpg","","","1"),
("40","1","474","21","/uploads/image-content/sweet-revival/SweetRevival777.png","","","1"),
("41","2","46","21","/uploads/image-content/sweet-revival/DSC04555копия.jpg","","","1"),
("42","3","47","21","/uploads/image-content/sweet-revival/SweetRevival.jpg","","","1"),
("43","1","461","22","/uploads/image-content/tallea/Talea777.png","","","1"),
("44","2","49","22","/uploads/image-content/tallea/DSC02828копия.jpg","","","1"),
("45","3","50","22","/uploads/image-content/tallea/Talea(1)копия.jpg","","","1"),
("46","1","466","25","/uploads/image-content/espana/Espana777.png","","","1"),
("47","2","283","25","/uploads/image-content/espana/crop.jpg","","","1"),
("48","3","284","25","/uploads/image-content/espana/Espana.jpg","","","1"),
("49","4","367","25","/uploads/image-content/espana/esp-1440.jpg","","","1"),
("50","1","468","26","/uploads/image-content/mandala/Mand-Alla777.png","","","1"),
("51","2","280","26","/uploads/image-content/mandala/DSC04491(1)копия.jpg","","","1"),
("52","3","279","26","/uploads/image-content/mandala/Mandala.jpg","","","1"),
("53","1","462","28","/uploads/image-content/apricot-lace/ApricotLace777.png","","","1"),
("54","2","59","28","/uploads/image-content/apricot-lace/DSC03006копия.jpg","","","1"),
("55","3","60","28","/uploads/image-content/apricot-lace/ApricotLaceкопия2.jpg","","","1"),
("56","4","62","28","/uploads/image-content/apricot-lace/DSC01093копия(2).jpg","","","1"),
("57","1","475","30","/uploads/image-content/bombastic/Bombastic777.png","","","1"),
("58","2","64","30","/uploads/image-content/bombastic/DSC04634копия.jpg","","","1"),
("59","3","65","30","/uploads/image-content/bombastic/Bombasticкопия.jpg","","","1"),
("60","1","464","31","/uploads/image-content/bird-song/BirdSong777.png","","","1"),
("61","2","67","31","/uploads/image-content/bird-song/crop.jpg","","","1"),
("62","3","68","31","/uploads/image-content/bird-song/BirdSong.jpg","","","1"),
("63","4","69","31","/uploads/image-content/bird-song/DSC08273копия.jpg","","","1"),
("64","1","471","32","/uploads/image-content/dedication/Dedication777.png","","","1"),
("65","2","71","32","/uploads/image-content/dedication/DSC04582копия.jpg","","","1"),
("66","3","72","32","/uploads/image-content/dedication/Dedication.jpg","","","1"),
("67","1","460","33","/uploads/image-content/josephine/Josephina777.png","","","1"),
("68","2","74","33","/uploads/image-content/josephine/Каталогбезназвания2337копия.jpg","","","1"),
("69","3","75","33","/uploads/image-content/josephine/Josephina.jpg","","","1"),
("70","1","441","36","/uploads/image-content/luna-trendsetter/LunaTrendsetter777.png","","","1"),
("71","2","77","36","/uploads/image-content/luna-trendsetter/Каталогбезназвания2220копия.jpg","","","1"),
("72","3","78","36","/uploads/image-content/luna-trendsetter/LunaTrendsetterкопия.jpg","","","1"),
("73","1","472","37","/uploads/image-content/madam-bombastic/MadamBombastic777.png","","","1"),
("74","2","80","37","/uploads/image-content/madam-bombastic/DSC04614копия.jpg","","","1"),
("75","3","81","37","/uploads/image-content/madam-bombastic/MadamBombastic.jpg","","","1"),
("76","1","451","42","/uploads/image-content/peach-dimension/PeachDemension777.png","","","1"),
("77","2","290","42","/uploads/image-content/peach-dimension/crop.jpg","","","1"),
("78","3","291","42","/uploads/image-content/peach-dimension/PeachDimension(1)копия2.jpg","","","1"),
("79","1","443","43","/uploads/image-content/peony-bubbles/PeonyBubbles777.png","","","1"),
("80","2","86","43","/uploads/image-content/peony-bubbles/3.jpg","","","1"),
("81","3","87","43","/uploads/image-content/peony-bubbles/PeonyBubblesкопия.jpg","","","1"),
("82","4","437","43","/uploads/image-content/peony-bubbles/peonybubbles1440.jpg","","","1"),
("83","1","445","44","/uploads/image-content/royal-park/RoyalPark777.png","","","1"),
("84","2","90","44","/uploads/image-content/royal-park/crop.jpg","","","1"),
("85","3","91","44","/uploads/image-content/royal-park/RoyalPark.jpg","","","1"),
("86","4","446","44","/uploads/image-content/royal-park/насайт—копия.jpg","","","1"),
("87","1","467","45","/uploads/image-content/royal-porselina/RoyalPorselina777.png","","","1"),
("88","2","94","45","/uploads/image-content/royal-porselina/Каталогбезназвания23111копия.jpg","","","1"),
("89","3","95","45","/uploads/image-content/royal-porselina/RoyalPorselina.jpg","","","1"),
("90","1","465","50","/uploads/image-content/tanja/Tanja777.png","","","1"),
("91","2","97","50","/uploads/image-content/tanja/DSC02962копия.jpg","","","1"),
("92","3","98","50","/uploads/image-content/tanja/Tanja(1)копия.jpg","","","1"),
("93","1","469","52","/uploads/image-content/femke/Femke777.png","","","1"),
("94","2","100","52","/uploads/image-content/femke/DSC04650копия.jpg","","","1"),
("95","3","101","52","/uploads/image-content/femke/Femkeкопия.jpg","","","1"),
("96","1","442","53","/uploads/image-content/buttercup/Buttercup777.png","","","1"),
("97","2","103","53","/uploads/image-content/buttercup/Каталогбезназвания2358копия.jpg","","","1"),
("98","3","104","53","/uploads/image-content/buttercup/Каталогбезназвания2372копия.jpg","","","1"),
("99","4","436","53","/uploads/image-content/buttercup/buttercupnasite.jpg","","","1"),
("100","1","453","54","/uploads/image-content/london-eye/LondonEye777.png","","","1");
INSERT INTO `mg_product_user_property_data` VALUES
("101","2","107","54","/uploads/image-content/london-eye/crop.jpg","","","1"),
("102","3","108","54","/uploads/image-content/london-eye/LondonEye(1)копия.jpg","","","1"),
("103","4","368","54","/uploads/image-content/london-eye/london-eye-1440.jpg","","","1"),
("104","1","463","57","/uploads/image-content/priscilla/Priscilia777.png","","","1"),
("105","2","300","57","/uploads/image-content/priscilla/crop.jpg","","","1"),
("106","3","301","57","/uploads/image-content/priscilla/Priscilla.jpg","","","1"),
("107","4","302","57","/uploads/image-content/priscilla/DSC01074копия.jpg","","","1"),
("108","1","455","59","/uploads/image-content/chiffon/Chiffon777.png","","","1"),
("109","2","115","59","/uploads/image-content/chiffon/DSC03047копия.jpg","","","1"),
("110","3","116","59","/uploads/image-content/chiffon/Chiffon(2)копия.jpg","","","1"),
("111","4","456","59","/uploads/image-content/chiffon/DSC08122копия(1)копия777.png","","","1"),
("112","1","494","1","/uploads/image-content/red-naomi/RedNaomi777.png","","","1"),
("113","2","119","1","/uploads/image-content/red-naomi/DSC09933копия.jpg","","","1"),
("114","3","120","1","/uploads/image-content/red-naomi/RedNaomi(1)копия2.jpg","","","1"),
("115","1","480","3","/uploads/image-content/aqua/Aqua777.png","","","1"),
("116","2","122","3","/uploads/image-content/aqua/DSC00298копия.jpg","","","1"),
("117","3","123","3","/uploads/image-content/aqua/Aqua.jpg","","","1"),
("118","1","482","4","/uploads/image-content/annakarina/Annakarina777.png","","","1"),
("119","2","125","4","/uploads/image-content/annakarina/crop.jpg","","","1"),
("120","3","126","4","/uploads/image-content/annakarina/Annakarina.jpg","","","1"),
("121","1","495","8","/uploads/image-content/jumilia/Jumilia777.png","","","1"),
("122","2","128","8","/uploads/image-content/jumilia/DSC03421копия.jpg","","","1"),
("123","3","129","8","/uploads/image-content/jumilia/Jumilia.jpg","","","1"),
("124","1","490","10","/uploads/image-content/xena/Xena777.png","","","1"),
("125","2","131","10","/uploads/image-content/xena/DSC03554копия.jpg","","","1"),
("126","3","132","10","/uploads/image-content/xena/Xena.jpg","","","1"),
("127","1","488","14","/uploads/image-content/maritim/Maritim777.png","","","1"),
("128","2","134","14","/uploads/image-content/maritim/DSC03521копия.jpg","","","1"),
("129","3","135","14","/uploads/image-content/maritim/Maritim.jpg","","","1"),
("130","1","484","18","/uploads/image-content/revival/Revival777.png","","","1"),
("131","2","137","18","/uploads/image-content/revival/DSC00249копия.jpg","","","1"),
("132","3","138","18","/uploads/image-content/revival/Revival.jpg","","","1"),
("133","1","497","23","/uploads/image-content/shangri-la/ShangriLa777.png","","","1"),
("134","2","140","23","/uploads/image-content/shangri-la/DSC03383копия.jpg","","","1"),
("135","3","141","23","/uploads/image-content/shangri-la/ShangriLa.jpg","","","1"),
("136","1","498","24","/uploads/image-content/el-toro/ElToro777.png","","","1"),
("137","2","143","24","/uploads/image-content/el-toro/DSC03395копия.jpg","","","1"),
("138","3","144","24","/uploads/image-content/el-toro/ElToro.jpg","","","1"),
("139","1","485","29","/uploads/image-content/aerobic/Aerobic777.png","","","1"),
("140","2","146","29","/uploads/image-content/aerobic/DSC00028копия.jpg","","","1"),
("141","3","147","29","/uploads/image-content/aerobic/Aerobicкопия.jpg","","","1"),
("142","1","489","34","/uploads/image-content/lavender-bubbles/LavenderBubbles777.png","","","1"),
("143","2","149","34","/uploads/image-content/lavender-bubbles/DSC03721копия.jpg","","","1"),
("144","3","150","34","/uploads/image-content/lavender-bubbles/LavenderBubblesкопия.jpg","","","1"),
("145","4","151","34","/uploads/image-content/lavender-bubbles/DSC01453копия.jpg","","","1"),
("146","1","491","35","/uploads/image-content/lady-bombastic/LadyBombastic777.png","","","1"),
("147","2","153","35","/uploads/image-content/lady-bombastic/DSC09958копия.jpg","","","1"),
("148","3","154","35","/uploads/image-content/lady-bombastic/LadyBombastic.jpg","","","1"),
("149","1","481","38","/uploads/image-content/mansfield-park/MansfieldPark777.png","","","1"),
("150","2","156","38","/uploads/image-content/mansfield-park/DSC09898копия.jpg","","","1"),
("151","3","157","38","/uploads/image-content/mansfield-park/MansfieldPark.jpg","","","1"),
("152","1","477","39","/uploads/image-content/mansfield-pink-park/MansfieldPinkPark777.png","","","1"),
("153","2","159","39","/uploads/image-content/mansfield-pink-park/DSC09816копия.jpg","","","1"),
("154","3","160","39","/uploads/image-content/mansfield-pink-park/MansfieldPinkPark.jpg","","","1"),
("155","4","369","39","/uploads/image-content/mansfield-pink-park/mansfield-pink-park-1440.jpg","","","1"),
("156","1","493","40","/uploads/image-content/misty-bubbles/MistyBubbles777.png","","","1"),
("157","2","163","40","/uploads/image-content/misty-bubbles/DSC03735копия.jpg","","","1"),
("158","3","164","40","/uploads/image-content/misty-bubbles/MistyBubblesкопия.jpg","","","1"),
("159","1","483","41","/uploads/image-content/pink-dimension/PinkDemension777.png","","","1"),
("160","2","287","41","/uploads/image-content/pink-dimension/DSC00083копия.jpg","","","1"),
("161","3","288","41","/uploads/image-content/pink-dimension/PinkDimensionкопия.jpg","","","1"),
("162","1","479","47","/uploads/image-content/silva-pink/SilvaPink777.png","","","1"),
("163","2","169","47","/uploads/image-content/silva-pink/DSC00104копия.jpg","","","1"),
("164","3","170","47","/uploads/image-content/silva-pink/SilvaPink.jpg","","","1"),
("165","4","171","47","/uploads/image-content/silva-pink/DSC00784(1)копия.jpg","","","1"),
("166","1","496","48","/uploads/image-content/scarlet-dimension/ScarletDemension777.png","","","1"),
("167","2","297","48","/uploads/image-content/scarlet-dimension/DSC03314копия.jpg","","","1"),
("168","3","298","48","/uploads/image-content/scarlet-dimension/DSC03313копия.jpg","","","1"),
("169","1","487","49","/uploads/image-content/sofi/Sofi777.png","","","1"),
("170","2","176","49","/uploads/image-content/sofi/DSC03680копия.jpg","","","1"),
("171","3","177","49","/uploads/image-content/sofi/Sofi.jpg","","","1"),
("172","4","178","49","/uploads/image-content/sofi/DSC07756копия.jpg","","","1"),
("173","1","499","51","/uploads/image-content/fireworks/Fireworks777.png","","","1"),
("174","2","180","51","/uploads/image-content/fireworks/DSC03429копия.jpg","","","1"),
("175","3","181","51","/uploads/image-content/fireworks/Fireworks(1)копия.jpg","","","1"),
("176","1","486","55","/uploads/image-content/montmartre/Montmartre777.png","","","1"),
("177","2","183","55","/uploads/image-content/montmartre/DSC03586копия.jpg","","","1"),
("178","3","184","55","/uploads/image-content/montmartre/Montmartreкопия.jpg","","","1"),
("179","4","185","55","/uploads/image-content/montmartre/DSC03817копия.jpg","","","1"),
("180","1","492","56","/uploads/image-content/notre-dame/NotreDame777.png","","","1"),
("181","2","187","56","/uploads/image-content/notre-dame/DSC03621копия.jpg","","","1"),
("182","3","188","56","/uploads/image-content/notre-dame/NotreDameкопия.jpg","","","1"),
("183","4","189","56","/uploads/image-content/notre-dame/DSC08771.jpg","","","1"),
("184","1","478","58","/uploads/image-content/regents-park/Regent’sPark777.png","","","1"),
("185","2","191","58","/uploads/image-content/regents-park/DSC00327копия.jpg","","","1"),
("186","3","192","58","/uploads/image-content/regents-park/Regent’sParkкопия.jpg","","","1"),
("187","4","193","58","/uploads/image-content/regents-park/DSC09598копия(1)копия.jpg","","","1"),
("188","4","194","5","/uploads/image-content/bubblegum/DSC03267(1)копия(1)копия.jpg","","","1"),
("189","4","292","42","/uploads/image-content/peach-dimension/DSC00478копия.jpg","","","1"),
("190","4","306","45","/uploads/image-content/royal-porselina/royal-porselina-2.jpg","","","1"),
("191","4","197","32","/uploads/image-content/dedication/DSC04716копия.jpg","","","1"),
("192","4","198","52","/uploads/image-content/femke/DSC04749копия.jpg","","","1"),
("193","4","281","26","/uploads/image-content/mandala/DSC09819копия.jpg","","","1"),
("194","4","200","9","/uploads/image-content/zaina/DSC04745копия.jpg","","","1"),
("195","1","476","46","/uploads/image-content/sweet-dimension/SweetDemention777.png","","","1"),
("196","2","294","46","/uploads/image-content/sweet-dimension/DSC04680копия.jpg","","","1"),
("197","3","295","46","/uploads/image-content/sweet-dimension/Sweet-d.jpg","","","1"),
("198","1","448","60","/uploads/image-content/beluga/beluga-new777.png","","","1"),
("199","2","276","60","/uploads/image-content/beluga/crop.jpg","","","1"),
("200","3","277","60","/uploads/image-content/beluga/Beluga.jpg","","","1");
INSERT INTO `mg_product_user_property_data` VALUES
("201","4","366","29","/uploads/image-content/aerobic/aerobic-1440.jpg","","","1"),
("202","4","375","20","/uploads/image-content/sweet-avalanche/sweet-avalanche-1440.jpg","","","1"),
("203","4","305","38","/uploads/image-content/mansfield-park/mansfield-park-2.jpg","","","1"),
("204","4","372","1","/uploads/image-content/red-naomi/red-naomi-1440.jpg","","","1"),
("205","4","373","48","/uploads/image-content/scarlet-dimension/scarlet-d-1440.jpg","","","1"),
("206","4","374","23","/uploads/image-content/shangri-la/shangri-la-1440.jpg","","","1"),
("207","4","376","50","/uploads/image-content/tanja/tanja-1440.jpg","","","1"),
("208","4","377","10","/uploads/image-content/xena/xena-1440.jpg","","","1");
DROP TABLE IF EXISTS `mg_product_variant`;

CREATE TABLE `mg_product_variant` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `title_variant` varchar(249) NOT NULL,
  `image` varchar(249) DEFAULT NULL,
  `sort` int(11) DEFAULT NULL,
  `price` double NOT NULL,
  `old_price` varchar(249) NOT NULL,
  `count` float NOT NULL,
  `code` varchar(249) DEFAULT NULL,
  `activity` tinyint(1) NOT NULL,
  `weight` double NOT NULL,
  `currency_iso` varchar(249) DEFAULT NULL,
  `price_course` double DEFAULT NULL,
  `1c_id` varchar(249) DEFAULT NULL,
  `color` varchar(249) NOT NULL,
  `size` varchar(249) NOT NULL,
  `last_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `opf_1` text NOT NULL,
  `opf_2` text NOT NULL,
  `opf_3` text NOT NULL,
  `opf_4` text NOT NULL,
  `opf_5` text NOT NULL,
  `opf_6` text NOT NULL,
  `opf_7` text NOT NULL,
  `opf_8` text NOT NULL,
  `opf_9` text NOT NULL,
  `opf_10` text NOT NULL,
  `opf_11` text NOT NULL,
  `opf_12` text NOT NULL,
  `opf_13` text NOT NULL,
  `opf_14` text NOT NULL,
  `opf_15` text NOT NULL,
  `opf_16` text NOT NULL,
  `opf_17` text NOT NULL,
  `opf_18` text NOT NULL,
  `opf_19` text NOT NULL,
  `opf_20` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_property`;

CREATE TABLE `mg_property` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `type` varchar(249) NOT NULL,
  `default` text,
  `data` text,
  `all_category` tinyint(1) DEFAULT NULL,
  `activity` int(1) NOT NULL DEFAULT '0',
  `sort` int(11) DEFAULT NULL,
  `filter` tinyint(1) NOT NULL DEFAULT '0',
  `description` text,
  `type_filter` varchar(32) DEFAULT NULL,
  `1c_id` varchar(191) DEFAULT NULL,
  `plugin` varchar(249) DEFAULT NULL,
  `unit` varchar(32) DEFAULT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `name` (`name`),
  KEY `1c_id` (`1c_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;


INSERT INTO `mg_property` VALUES
("1","Фото 1","file","","","1","1","4","0","","checkbox","","","","1"),
("2","Фото 2","file","","","1","1","3","0","","checkbox","","","","1"),
("3","Фото 3","file","","","1","1","2","0","","checkbox","","","","1"),
("4","Фото 4","file","","","1","1","1","0","","checkbox","","","","1");
DROP TABLE IF EXISTS `mg_property_data`;

CREATE TABLE `mg_property_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `prop_id` int(11) NOT NULL,
  `name` varchar(249) NOT NULL,
  `margin` text NOT NULL,
  `sort` int(11) NOT NULL DEFAULT '1',
  `color` varchar(45) NOT NULL,
  `img` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `name` (`name`),
  KEY `prop_id` (`prop_id`)
) ENGINE=InnoDB AUTO_INCREMENT=500 DEFAULT CHARSET=utf8mb4;


INSERT INTO `mg_property_data` VALUES
("1","1","/uploads/image-content/Avalanche/rosa.png","","1","",""),
("2","2","/uploads/image-content/Avalanche/crop.jpg","","2","",""),
("3","3","/uploads/image-content/Avalanche/3.jpg","","3","",""),
("4","4","/uploads/image-content/Avalanche/насайт.jpg","","4","",""),
("5","1","/uploads/image-content/Avalanche/rosa-av.png","","5","",""),
("6","2","/uploads/image-content/Avalanche/crop.png","","6","",""),
("7","1","/uploads/image-content/bubblegum/rosa2.png","","7","",""),
("8","2","/uploads/image-content/bubblegum/DSC02984копия.jpg","","8","",""),
("9","3","/uploads/image-content/bubblegum/Bubblegum.jpg","","9","",""),
("10","1","/uploads/image-content/whitenaomi/rosa.png","","10","",""),
("11","2","/uploads/image-content/whitenaomi/crop.jpg","","11","",""),
("12","3","/uploads/image-content/whitenaomi/3.jpg","","12","",""),
("13","1","/uploads/image-content/zaina/DSC04517копия.png","","13","",""),
("14","2","/uploads/image-content/zaina/DSC04516копия.jpg","","14","",""),
("15","3","/uploads/image-content/zaina/Zainaкопия.jpg","","15","",""),
("16","3","/uploads/image-content/whitenaomi/WhiteNaomi.jpg","","16","",""),
("17","1","/uploads/image-content/ilios/Каталогбезназвания2477копия.png","","17","",""),
("18","2","/uploads/image-content/ilios/Каталогбезназвания24831копия.jpg","","18","",""),
("19","3","/uploads/image-content/ilios/Ilios.jpg","","19","",""),
("20","1","/uploads/image-content/kimberly/DSC02923копия.png","","20","",""),
("21","2","/uploads/image-content/kimberly/crop.jpg","","21","",""),
("22","3","/uploads/image-content/kimberly/Kimberly.jpg","","22","",""),
("23","1","/uploads/image-content/clarence/rosa.png","","23","",""),
("24","2","/uploads/image-content/clarence/DSC02811копия.jpg","","24","",""),
("25","3","/uploads/image-content/clarence/DSC02816копия.jpg","","25","",""),
("26","1","/uploads/image-content/misspiggy/DSC03027копия.png","","26","",""),
("27","2","/uploads/image-content/misspiggy/crop.jpg","","27","",""),
("28","3","/uploads/image-content/misspiggy/MissPiggy.jpg","","28","",""),
("29","4","/uploads/image-content/misspiggy/DSC01488копия.jpg","","29","",""),
("30","4","/uploads/image-content/misspiggy/DSC01488копия.png","","30","",""),
("31","4","/uploads/image-content/misspiggy/DSC01275копия.jpg","","31","",""),
("32","1","/uploads/image-content/penny-lane/roza.png","","32","",""),
("33","2","/uploads/image-content/penny-lane/crop.jpg","","33","",""),
("34","3","/uploads/image-content/penny-lane/Pennylane.jpg","","34","",""),
("35","4","/uploads/image-content/penny-lane/DSC01553копия.jpg","","35","",""),
("36","1","/uploads/image-content/peach-avalanche/rosa.png","","36","",""),
("37","2","/uploads/image-content/peach-avalanche/crop.jpg","","37","",""),
("38","3","/uploads/image-content/peach-avalanche/PeachAvalanche.jpg","","38","",""),
("39","1","/uploads/image-content/saida/rosa.png","","39","",""),
("40","2","/uploads/image-content/saida/crop.jpg","","40","",""),
("41","3","/uploads/image-content/saida/Saida.jpg","","41","",""),
("42","1","/uploads/image-content/sweet-avalanche/DSC00155копия.png","","42","",""),
("43","2","/uploads/image-content/sweet-avalanche/DSC00164копия.jpg","","43","",""),
("44","3","/uploads/image-content/sweet-avalanche/SweetAvalanche.jpg","","44","",""),
("45","1","/uploads/image-content/sweet-revival/DSC04544копия.png","","45","",""),
("46","2","/uploads/image-content/sweet-revival/DSC04555копия.jpg","","46","",""),
("47","3","/uploads/image-content/sweet-revival/SweetRevival.jpg","","47","",""),
("48","1","/uploads/image-content/tallea/DSC02863копия.png","","48","",""),
("49","2","/uploads/image-content/tallea/DSC02828копия.jpg","","49","",""),
("50","3","/uploads/image-content/tallea/Talea(1)копия.jpg","","50","",""),
("51","1","/uploads/image-content/espano/rosa.png","","51","",""),
("52","2","/uploads/image-content/espano/crop.jpg","","52","",""),
("53","3","/uploads/image-content/espano/Espano.jpg","","53","",""),
("54","4","/uploads/image-content/espano/DSC03119копия2.jpg","","54","",""),
("55","1","/uploads/image-content/mand-alla/DSC04494копия.png","","55","",""),
("56","2","/uploads/image-content/mand-alla/DSC04491(1)копия.jpg","","56","",""),
("57","3","/uploads/image-content/mand-alla/Mand-Alla.jpg","","57","",""),
("58","1","/uploads/image-content/apricot-lace/rosa.png","","58","",""),
("59","2","/uploads/image-content/apricot-lace/DSC03006копия.jpg","","59","",""),
("60","3","/uploads/image-content/apricot-lace/ApricotLaceкопия2.jpg","","60","",""),
("61","4","/uploads/image-content/apricot-lace/DSC03006копия.jpg","","61","",""),
("62","4","/uploads/image-content/apricot-lace/DSC01093копия(2).jpg","","62","",""),
("63","1","/uploads/image-content/bombastic/DSC04630копия.png","","63","",""),
("64","2","/uploads/image-content/bombastic/DSC04634копия.jpg","","64","",""),
("65","3","/uploads/image-content/bombastic/Bombasticкопия.jpg","","65","",""),
("66","1","/uploads/image-content/bird-song/rosa.png","","66","",""),
("67","2","/uploads/image-content/bird-song/crop.jpg","","67","",""),
("68","3","/uploads/image-content/bird-song/BirdSong.jpg","","68","",""),
("69","4","/uploads/image-content/bird-song/DSC08273копия.jpg","","69","",""),
("70","1","/uploads/image-content/dedication/DSC04576копия.png","","70","",""),
("71","2","/uploads/image-content/dedication/DSC04582копия.jpg","","71","",""),
("72","3","/uploads/image-content/dedication/Dedication.jpg","","72","",""),
("73","1","/uploads/image-content/josephine/Каталогбезназвания2343копия.png","","73","",""),
("74","2","/uploads/image-content/josephine/Каталогбезназвания2337копия.jpg","","74","",""),
("75","3","/uploads/image-content/josephine/Josephina.jpg","","75","",""),
("76","1","/uploads/image-content/luna-trendsetter/rosa.png","","76","",""),
("77","2","/uploads/image-content/luna-trendsetter/Каталогбезназвания2220копия.jpg","","77","",""),
("78","3","/uploads/image-content/luna-trendsetter/LunaTrendsetterкопия.jpg","","78","",""),
("79","1","/uploads/image-content/madam-bombastic/DSC04607копия.png","","79","",""),
("80","2","/uploads/image-content/madam-bombastic/DSC04614копия.jpg","","80","",""),
("81","3","/uploads/image-content/madam-bombastic/MadamBombastic.jpg","","81","",""),
("82","1","/uploads/image-content/peach-demension/rosa.png","","82","",""),
("83","2","/uploads/image-content/peach-demension/crop.jpg","","83","",""),
("84","3","/uploads/image-content/peach-demension/PeachDemension(1)копия2.jpg","","84","",""),
("85","1","/uploads/image-content/peony-bubbles/rosa.png","","85","",""),
("86","2","/uploads/image-content/peony-bubbles/3.jpg","","86","",""),
("87","3","/uploads/image-content/peony-bubbles/PeonyBubblesкопия.jpg","","87","",""),
("88","4","/uploads/image-content/peony-bubbles/ОБЛ1.jpg","","88","",""),
("89","1","/uploads/image-content/royal-park/rosa.png","","89","",""),
("90","2","/uploads/image-content/royal-park/crop.jpg","","90","",""),
("91","3","/uploads/image-content/royal-park/RoyalPark.jpg","","91","",""),
("92","4","/uploads/image-content/royal-park/насайт —копия.jpg","","92","",""),
("93","1","/uploads/image-content/royal-porselina/Каталогбезназвания23201копия.png","","93","",""),
("94","2","/uploads/image-content/royal-porselina/Каталогбезназвания23111копия.jpg","","94","",""),
("95","3","/uploads/image-content/royal-porselina/RoyalPorselina.jpg","","95","",""),
("96","1","/uploads/image-content/tanja/DSC02957копия.png","","96","",""),
("97","2","/uploads/image-content/tanja/DSC02962копия.jpg","","97","",""),
("98","3","/uploads/image-content/tanja/Tanja(1)копия.jpg","","98","",""),
("99","1","/uploads/image-content/femke/DSC04649копия.png","","99","",""),
("100","2","/uploads/image-content/femke/DSC04650копия.jpg","","100","","");
INSERT INTO `mg_property_data` VALUES
("101","3","/uploads/image-content/femke/Femkeкопия.jpg","","101","",""),
("102","1","/uploads/image-content/buttercup/Каталогбезназвания2348копия.png","","102","",""),
("103","2","/uploads/image-content/buttercup/Каталогбезназвания2358копия.jpg","","103","",""),
("104","3","/uploads/image-content/buttercup/Каталогбезназвания2372копия.jpg","","104","",""),
("105","4","/uploads/image-content/buttercup/насайт.jpg","","105","",""),
("106","1","/uploads/image-content/london-eye/rosa.png","","106","",""),
("107","2","/uploads/image-content/london-eye/crop.jpg","","107","",""),
("108","3","/uploads/image-content/london-eye/LondonEye(1)копия.jpg","","108","",""),
("109","4","/uploads/image-content/london-eye/DSC03267(1)копия.jpg","","109","",""),
("110","1","/uploads/image-content/priscilia/rosa.png","","110","",""),
("111","2","/uploads/image-content/priscilia/crop.jpg","","111","",""),
("112","3","/uploads/image-content/priscilia/Priscilia.jpg","","112","",""),
("113","4","/uploads/image-content/priscilia/DSC01074копия.jpg","","113","",""),
("114","1","/uploads/image-content/chiffon/DSC03044копия.png","","114","",""),
("115","2","/uploads/image-content/chiffon/DSC03047копия.jpg","","115","",""),
("116","3","/uploads/image-content/chiffon/Chiffon(2)копия.jpg","","116","",""),
("117","4","/uploads/image-content/chiffon/DSC08122копия(1)копия.png","","117","",""),
("118","1","/uploads/image-content/red-naomi/DSC09943копия.png","","118","",""),
("119","2","/uploads/image-content/red-naomi/DSC09933копия.jpg","","119","",""),
("120","3","/uploads/image-content/red-naomi/RedNaomi(1)копия2.jpg","","120","",""),
("121","1","/uploads/image-content/aqua/DSC00287копия.png","","121","",""),
("122","2","/uploads/image-content/aqua/DSC00298копия.jpg","","122","",""),
("123","3","/uploads/image-content/aqua/Aqua.jpg","","123","",""),
("124","1","/uploads/image-content/annakarina/DSC02933копия.png","","124","",""),
("125","2","/uploads/image-content/annakarina/crop.jpg","","125","",""),
("126","3","/uploads/image-content/annakarina/Annakarina.jpg","","126","",""),
("127","1","/uploads/image-content/jumilia/DSC03412копия.png","","127","",""),
("128","2","/uploads/image-content/jumilia/DSC03421копия.jpg","","128","",""),
("129","3","/uploads/image-content/jumilia/Jumilia.jpg","","129","",""),
("130","1","/uploads/image-content/xena/DSC03557копия.png","","130","",""),
("131","2","/uploads/image-content/xena/DSC03554копия.jpg","","131","",""),
("132","3","/uploads/image-content/xena/Xena.jpg","","132","",""),
("133","1","/uploads/image-content/maritim/DSC03503копия.png","","133","",""),
("134","2","/uploads/image-content/maritim/DSC03521копия.jpg","","134","",""),
("135","3","/uploads/image-content/maritim/Maritim.jpg","","135","",""),
("136","1","/uploads/image-content/revival/DSC00251копия.png","","136","",""),
("137","2","/uploads/image-content/revival/DSC00249копия.jpg","","137","",""),
("138","3","/uploads/image-content/revival/Revival.jpg","","138","",""),
("139","1","/uploads/image-content/shangri-la/DSC03367копия.png","","139","",""),
("140","2","/uploads/image-content/shangri-la/DSC03383копия.jpg","","140","",""),
("141","3","/uploads/image-content/shangri-la/ShangriLa.jpg","","141","",""),
("142","1","/uploads/image-content/el-toro/DSC03393копия.png","","142","",""),
("143","2","/uploads/image-content/el-toro/DSC03395копия.jpg","","143","",""),
("144","3","/uploads/image-content/el-toro/ElToro.jpg","","144","",""),
("145","1","/uploads/image-content/aerobic/DSC00013копия.png","","145","",""),
("146","2","/uploads/image-content/aerobic/DSC00028копия.jpg","","146","",""),
("147","3","/uploads/image-content/aerobic/Aerobicкопия.jpg","","147","",""),
("148","1","/uploads/image-content/lavender-bubbles/DSC03712копия.png","","148","",""),
("149","2","/uploads/image-content/lavender-bubbles/DSC03721копия.jpg","","149","",""),
("150","3","/uploads/image-content/lavender-bubbles/LavenderBubblesкопия.jpg","","150","",""),
("151","4","/uploads/image-content/lavender-bubbles/DSC01453копия.jpg","","151","",""),
("152","1","/uploads/image-content/lady-bombastic/DSC09960копия.png","","152","",""),
("153","2","/uploads/image-content/lady-bombastic/DSC09958копия.jpg","","153","",""),
("154","3","/uploads/image-content/lady-bombastic/LadyBombastic.jpg","","154","",""),
("155","1","/uploads/image-content/mansfield-park/DSC09905копия.png","","155","",""),
("156","2","/uploads/image-content/mansfield-park/DSC09898копия.jpg","","156","",""),
("157","3","/uploads/image-content/mansfield-park/MansfieldPark.jpg","","157","",""),
("158","1","/uploads/image-content/mansfield-pink-park/DSC09834копия.png","","158","",""),
("159","2","/uploads/image-content/mansfield-pink-park/DSC09816копия.jpg","","159","",""),
("160","3","/uploads/image-content/mansfield-pink-park/MansfieldPinkPark.jpg","","160","",""),
("161","4","/uploads/image-content/mansfield-pink-park/DSC09224копия.jpg","","161","",""),
("162","1","/uploads/image-content/misty-bubbles/DSC03730копия.png","","162","",""),
("163","2","/uploads/image-content/misty-bubbles/DSC03735копия.jpg","","163","",""),
("164","3","/uploads/image-content/misty-bubbles/MistyBubblesкопия.jpg","","164","",""),
("165","1","/uploads/image-content/pink-demension/DSC00068копия.png","","165","",""),
("166","2","/uploads/image-content/pink-demension/DSC00083копия.jpg","","166","",""),
("167","3","/uploads/image-content/pink-demension/PinkDemensionкопия.jpg","","167","",""),
("168","1","/uploads/image-content/silva-pink/DSC00100копия.png","","168","",""),
("169","2","/uploads/image-content/silva-pink/DSC00104копия.jpg","","169","",""),
("170","3","/uploads/image-content/silva-pink/SilvaPink.jpg","","170","",""),
("171","4","/uploads/image-content/silva-pink/DSC00784(1)копия.jpg","","171","",""),
("172","1","/uploads/image-content/scarlet-demension/DSC03313копия.png","","172","",""),
("173","2","/uploads/image-content/scarlet-demension/DSC03314копия.jpg","","173","",""),
("174","3","/uploads/image-content/scarlet-demension/DSC03313копия.jpg","","174","",""),
("175","1","/uploads/image-content/sofi/DSC03677(1)копия.png","","175","",""),
("176","2","/uploads/image-content/sofi/DSC03680копия.jpg","","176","",""),
("177","3","/uploads/image-content/sofi/Sofi.jpg","","177","",""),
("178","4","/uploads/image-content/sofi/DSC07756копия.jpg","","178","",""),
("179","1","/uploads/image-content/fireworks/DSC03428копия.png","","179","",""),
("180","2","/uploads/image-content/fireworks/DSC03429копия.jpg","","180","",""),
("181","3","/uploads/image-content/fireworks/Fireworks(1)копия.jpg","","181","",""),
("182","1","/uploads/image-content/montmartre/DSC03600копия.png","","182","",""),
("183","2","/uploads/image-content/montmartre/DSC03586копия.jpg","","183","",""),
("184","3","/uploads/image-content/montmartre/Montmartreкопия.jpg","","184","",""),
("185","4","/uploads/image-content/montmartre/DSC03817копия.jpg","","185","",""),
("186","1","/uploads/image-content/notre-dame/DSC03626копия.png","","186","",""),
("187","2","/uploads/image-content/notre-dame/DSC03621копия.jpg","","187","",""),
("188","3","/uploads/image-content/notre-dame/NotreDameкопия.jpg","","188","",""),
("189","4","/uploads/image-content/notre-dame/DSC08771.jpg","","189","",""),
("190","1","/uploads/image-content/regents-park/DSC00309копия.png","","190","",""),
("191","2","/uploads/image-content/regents-park/DSC00327копия.jpg","","191","",""),
("192","3","/uploads/image-content/regents-park/Regent’sParkкопия.jpg","","192","",""),
("193","4","/uploads/image-content/regents-park/DSC09598копия(1)копия.jpg","","193","",""),
("194","4","/uploads/image-content/bubblegum/DSC03267(1)копия(1)копия.jpg","","194","",""),
("195","4","/uploads/image-content/peach-demension/DSC00478копия.jpg","","195","",""),
("196","4","/uploads/image-content/royal-porselina/насайт.jpg","","196","",""),
("197","4","/uploads/image-content/dedication/DSC04716копия.jpg","","197","",""),
("198","4","/uploads/image-content/femke/DSC04749копия.jpg","","198","",""),
("199","4","/uploads/image-content/mand-alla/DSC09819копия.jpg","","199","",""),
("200","4","/uploads/image-content/zaina/DSC04745копия.jpg","","200","","");
INSERT INTO `mg_property_data` VALUES
("201","1","/uploads/image-content/sweet-demention/DSC04670копия.png","","201","",""),
("202","2","/uploads/image-content/sweet-demention/DSC04680копия.jpg","","202","",""),
("203","3","/uploads/image-content/sweet-demention/SweetDemention(1)копия.jpg","","203","",""),
("204","1","/uploads/image-content/avalanche/rosa.png","","204","",""),
("205","2","/uploads/image-content/avalanche/crop.png","","205","",""),
("206","3","/uploads/image-content/avalanche/Avalanche.jpg","","206","",""),
("207","4","/uploads/image-content/avalanche/насайт.jpg","","207","",""),
("208","1","/uploads/image-content/white-naomi/rosa.png","","208","",""),
("209","2","/uploads/image-content/white-naomi/crop.jpg","","209","",""),
("210","3","/uploads/image-content/white-naomi/WhiteNaomi.jpg","","210","",""),
("211","1","/uploads/image-content/miss-piggy/DSC03027копия.png","","211","",""),
("212","2","/uploads/image-content/miss-piggy/crop.jpg","","212","",""),
("213","3","/uploads/image-content/miss-piggy/MissPiggy.jpg","","213","",""),
("214","4","/uploads/image-content/miss-piggy/DSC01488копия.jpg","","214","",""),
("215","1","/uploads/image-content/red-naomi/rednaomi-1.png","","215","",""),
("216","1","/uploads/image-content/red-naomi/avalanche-1.png","","216","",""),
("217","1","/uploads/image-content/aqua/aqua-1.png","","217","",""),
("218","1","/uploads/image-content/avalanche/avalanche-1.png","","218","",""),
("219","1","/uploads/image-content/annakarina/annakarina-1.png","","219","",""),
("220","1","/uploads/image-content/bubblegum/bubblegum-1.png","","220","",""),
("221","1","/uploads/image-content/white-naomi/white-naomi-1.png","","221","",""),
("222","1","/uploads/image-content/jumilia/jumilia-1.png","","222","",""),
("223","1","/uploads/image-content/zaina/zaina-1.png","","223","",""),
("224","1","/uploads/image-content/xena/xena-1.png","","224","",""),
("225","1","/uploads/image-content/ilios/ilios-1.png","","225","",""),
("226","1","/uploads/image-content/kimberly/kimberly-1.png","","226","",""),
("227","1","/uploads/image-content/clarence/clarence-1.png","","227","",""),
("228","1","/uploads/image-content/maritim/maritim-1.png","","228","",""),
("229","1","/uploads/image-content/miss-piggy/miss-piggy-1.png","","229","",""),
("230","1","/uploads/image-content/penny-lane/pennylane-1.png","","230","",""),
("231","1","/uploads/image-content/peach-avalanche/peach-avalanche-1.png","","231","",""),
("232","1","/uploads/image-content/revival/revival-1.png","","232","",""),
("233","1","/uploads/image-content/saida/saida-1.png","","233","",""),
("234","1","/uploads/image-content/sweet-avalanche/sweet-avalanche-1.png","","234","",""),
("235","1","/uploads/image-content/sweet-revival/sweet-revival-1.png","","235","",""),
("236","1","/uploads/image-content/tallea/talea-1.png","","236","",""),
("237","1","/uploads/image-content/shangri-la/shangri-la-1.png","","237","",""),
("238","1","/uploads/image-content/el-toro/el-toro-1.png","","238","",""),
("239","1","/uploads/image-content/espano/espano-1.png","","239","",""),
("240","1","/uploads/image-content/mand-alla/mand-alla-1.png","","240","",""),
("241","1","/uploads/image-content/apricot-lace/apricot-lace-1.png","","241","",""),
("242","1","/uploads/image-content/aerobic/aerobic-1.png","","242","",""),
("243","1","/uploads/image-content/bombastic/bombastic-1.png","","243","",""),
("244","1","/uploads/image-content/bird-song/bird-song-1.png","","244","",""),
("245","1","/uploads/image-content/dedication/dedication-1.png","","245","",""),
("246","1","/uploads/image-content/josephine/josephina-1.png","","246","",""),
("247","1","/uploads/image-content/lavender-bubbles/lavender-bubbles-1.png","","247","",""),
("248","1","/uploads/image-content/lady-bombastic/lady-bombastic-1.png","","248","",""),
("249","1","/uploads/image-content/luna-trendsetter/luna-trendsetter-1.png","","249","",""),
("250","1","/uploads/image-content/madam-bombastic/madam-bombastic-1.png","","250","",""),
("251","1","/uploads/image-content/mansfield-park/mansfield-park-1.png","","251","",""),
("252","1","/uploads/image-content/mansfield-pink-park/mansfield-pink-park-1.png","","252","",""),
("253","1","/uploads/image-content/misty-bubbles/misty-bubbles-1.png","","253","",""),
("254","1","/uploads/image-content/pink-demension/pink-demension-1.png","","254","",""),
("255","1","/uploads/image-content/peach-demension/peach-demension-1.png","","255","",""),
("256","1","/uploads/image-content/peony-bubbles/peony-bubbles-1.png","","256","",""),
("257","1","/uploads/image-content/royal-park/royal-park-1.png","","257","",""),
("258","1","/uploads/image-content/royal-porselina/royal-porselina-1.png","","258","",""),
("259","1","/uploads/image-content/scarlet-demension/sweet-demention-1.png","","259","",""),
("260","1","/uploads/image-content/scarlet-demension/sweet-d-1.png","","260","",""),
("261","1","/uploads/image-content/silva-pink/silva-pink-1.png","","261","",""),
("262","1","/uploads/image-content/scarlet-demension/scarlet-d-1.png","","262","",""),
("263","1","/uploads/image-content/sweet-demention/sweet-d-1.png","","263","",""),
("264","1","/uploads/image-content/sofi/sofi-1.png","","264","",""),
("265","1","/uploads/image-content/tanja/tanja-1.png","","265","",""),
("266","1","/uploads/image-content/fireworks/fireworks-1.png","","266","",""),
("267","1","/uploads/image-content/femke/femke-1.png","","267","",""),
("268","1","/uploads/image-content/buttercup/buttercup-1.png","","268","",""),
("269","1","/uploads/image-content/london-eye/londoneye-1.png","","269","",""),
("270","1","/uploads/image-content/montmartre/montmartre-1.png","","270","",""),
("271","1","/uploads/image-content/notre-dame/notre-dame-1.png","","271","",""),
("272","1","/uploads/image-content/priscilia/prisc-1.png","","272","",""),
("273","1","/uploads/image-content/regents-park/regents-park-1.png","","273","",""),
("274","1","/uploads/image-content/chiffon/chiffon-1.png","","274","",""),
("275","1","/uploads/image-content/beluga/beluga-1.png","","275","",""),
("276","2","/uploads/image-content/beluga/crop.jpg","","276","",""),
("277","3","/uploads/image-content/beluga/Beluga.jpg","","277","",""),
("278","1","/uploads/image-content/mandala/mandala-1.png","","278","",""),
("279","3","/uploads/image-content/mandala/Mandala.jpg","","279","",""),
("280","2","/uploads/image-content/mandala/DSC04491(1)копия.jpg","","280","",""),
("281","4","/uploads/image-content/mandala/DSC09819копия.jpg","","281","",""),
("282","1","/uploads/image-content/espana/espana-1.png","","282","",""),
("283","2","/uploads/image-content/espana/crop.jpg","","283","",""),
("284","3","/uploads/image-content/espana/Espana.jpg","","284","",""),
("285","4","/uploads/image-content/espana/DSC03119копия2.jpg","","285","",""),
("286","1","/uploads/image-content/pink-dimension/pink-dimension-1.png","","286","",""),
("287","2","/uploads/image-content/pink-dimension/DSC00083копия.jpg","","287","",""),
("288","3","/uploads/image-content/pink-dimension/PinkDimensionкопия.jpg","","288","",""),
("289","1","/uploads/image-content/peach-dimension/peach-dimension-1.png","","289","",""),
("290","2","/uploads/image-content/peach-dimension/crop.jpg","","290","",""),
("291","3","/uploads/image-content/peach-dimension/PeachDimension(1)копия2.jpg","","291","",""),
("292","4","/uploads/image-content/peach-dimension/DSC00478копия.jpg","","292","",""),
("293","1","/uploads/image-content/sweet-dimension/sweet-d-1.png","","293","",""),
("294","2","/uploads/image-content/sweet-dimension/DSC04680копия.jpg","","294","",""),
("295","3","/uploads/image-content/sweet-dimension/Sweet-d.jpg","","295","",""),
("296","1","/uploads/image-content/scarlet-dimension/scarlet-d-1.png","","296","",""),
("297","2","/uploads/image-content/scarlet-dimension/DSC03314копия.jpg","","297","",""),
("298","3","/uploads/image-content/scarlet-dimension/DSC03313копия.jpg","","298","",""),
("299","1","/uploads/image-content/priscilla/prisc-1.png","","299","",""),
("300","2","/uploads/image-content/priscilla/crop.jpg","","300","","");
INSERT INTO `mg_property_data` VALUES
("301","3","/uploads/image-content/priscilla/Priscilla.jpg","","301","",""),
("302","4","/uploads/image-content/priscilla/DSC01074копия.jpg","","302","",""),
("303","4","/uploads/image-content/aerobic/aerobic-2.jpg","","303","",""),
("304","4","/uploads/image-content/sweet-avalanche/sweet-avalanche-2.jpg","","304","",""),
("305","4","/uploads/image-content/mansfield-park/mansfield-park-2.jpg","","305","",""),
("306","4","/uploads/image-content/royal-porselina/royal-porselina-2.jpg","","306","",""),
("307","1","/uploads/image-content/beluga/beluga-new.png","","307","",""),
("308","1","/uploads/image-content/avalanche/avalanche-new.png","","308","",""),
("309","1","/uploads/image-content/buttercup/buttercup-new.png","","309","",""),
("310","1","/uploads/image-content/aerobic/aerobic-new.png","","310","",""),
("311","1","/uploads/image-content/annakarina/annakarina-new.png","","311","",""),
("312","1","/uploads/image-content/apricot-lace/apricot-lace-new.png","","312","",""),
("313","1","/uploads/image-content/aqua/aqua-new.png","","313","",""),
("314","1","/uploads/image-content/bird-song/bird-song-new.png","","314","",""),
("315","1","/uploads/image-content/bombastic/bombastic-new.png","","315","",""),
("316","1","/uploads/image-content/bubblegum/bubblegum-new.png","","316","",""),
("317","1","/uploads/image-content/chiffon/chiffon-new.png","","317","",""),
("318","1","/uploads/image-content/clarence/clarence-new.png","","318","",""),
("319","1","/uploads/image-content/dedication/dedication-new.png","","319","",""),
("320","1","/uploads/image-content/el-toro/el-toro-new.png","","320","",""),
("321","1","/uploads/image-content/espana/espana-new.png","","321","",""),
("322","1","/uploads/image-content/femke/femke-new.png","","322","",""),
("323","1","/uploads/image-content/fireworks/fireworks-new.png","","323","",""),
("324","1","/uploads/image-content/ilios/ilios-new.png","","324","",""),
("325","1","/uploads/image-content/josephine/josephine-new.png","","325","",""),
("326","1","/uploads/image-content/jumilia/jumilia-new.png","","326","",""),
("327","1","/uploads/image-content/kimberly/kimberly-new.png","","327","",""),
("328","1","/uploads/image-content/lady-bombastic/lady-bombastic-new.png","","328","",""),
("329","1","/uploads/image-content/lavender-bubbles/lavender-bubbles-new.png","","329","",""),
("330","1","/uploads/image-content/london-eye/london-eye-new.png","","330","",""),
("331","1","/uploads/image-content/luna-trendsetter/luna-trendsetter-new.png","","331","",""),
("332","1","/uploads/image-content/madam-bombastic/madam-bombastic-new.png","","332","",""),
("333","1","/uploads/image-content/mandala/mandalla-new.png","","333","",""),
("334","1","/uploads/image-content/mansfield-park/mansfield-park-new.png","","334","",""),
("335","1","/uploads/image-content/mansfield-pink-park/mansfield-pink-park-new.png","","335","",""),
("336","1","/uploads/image-content/maritim/maritim-new.png","","336","",""),
("337","1","/uploads/image-content/miss-piggy/miss-piggy-new.png","","337","",""),
("338","1","/uploads/image-content/misty-bubbles/misty-bubbles-new.png","","338","",""),
("339","1","/uploads/image-content/montmartre/montmartre-new.png","","339","",""),
("340","1","/uploads/image-content/notre-dame/notre-dame-new.png","","340","",""),
("341","1","/uploads/image-content/peach-avalanche/peach-avalanche-new.png","","341","",""),
("342","1","/uploads/image-content/peach-dimension/peach-d-new.png","","342","",""),
("343","1","/uploads/image-content/penny-lane/penny-lane-new.png","","343","",""),
("344","1","/uploads/image-content/peony-bubbles/peony-bubbles-new.png","","344","",""),
("345","1","/uploads/image-content/pink-dimension/pink-d-new.png","","345","",""),
("346","1","/uploads/image-content/priscilla/priscilla-new.png","","346","",""),
("347","1","/uploads/image-content/red-naomi/red-naomi-new.png","","347","",""),
("348","1","/uploads/image-content/regents-park/regents-park-new.png","","348","",""),
("349","1","/uploads/image-content/revival/revival-new.png","","349","",""),
("350","1","/uploads/image-content/royal-park/royal-park-new.png","","350","",""),
("351","1","/uploads/image-content/royal-porselina/royal-porcelina-new.png","","351","",""),
("352","1","/uploads/image-content/saida/saida-new.png","","352","",""),
("353","1","/uploads/image-content/scarlet-dimension/scarlet-d-new.png","","353","",""),
("354","1","/uploads/image-content/shangri-la/shangri-la-new.png","","354","",""),
("355","1","/uploads/image-content/silva-pink/silva-pink-new.png","","355","",""),
("356","1","/uploads/image-content/sofi/sofie-new.png","","356","",""),
("357","1","/uploads/image-content/sweet-avalanche/sweet-avalanche-new.png","","357","",""),
("358","1","/uploads/image-content/sweet-dimension/sweet-d-new.png","","358","",""),
("359","1","/uploads/image-content/sweet-revival/sweet-revival-new.png","","359","",""),
("360","1","/uploads/image-content/tallea/talea-new.png","","360","",""),
("361","1","/uploads/image-content/tanja/tanja-new.png","","361","",""),
("362","1","/uploads/image-content/white-naomi/white-naomi-new.png","","362","",""),
("363","1","/uploads/image-content/xena/xena-new.png","","363","",""),
("364","1","/uploads/image-content/zaina/zaina-new.png","","364","",""),
("365","4","/uploads/image-content/avalanche/avalanche-1440.jpg","","365","",""),
("366","4","/uploads/image-content/aerobic/aerobic-1440.jpg","","366","",""),
("367","4","/uploads/image-content/espana/esp-1440.jpg","","367","",""),
("368","4","/uploads/image-content/london-eye/london-eye-1440.jpg","","368","",""),
("369","4","/uploads/image-content/mansfield-pink-park/mansfield-pink-park-1440.jpg","","369","",""),
("370","4","/uploads/image-content/miss-piggy/miss-piggy-1440.jpg","","370","",""),
("371","4","/uploads/image-content/peony-bubbles/peony-bubbles-1440.jpg","","371","",""),
("372","4","/uploads/image-content/red-naomi/red-naomi-1440.jpg","","372","",""),
("373","4","/uploads/image-content/scarlet-dimension/scarlet-d-1440.jpg","","373","",""),
("374","4","/uploads/image-content/shangri-la/shangri-la-1440.jpg","","374","",""),
("375","4","/uploads/image-content/sweet-avalanche/sweet-avalanche-1440.jpg","","375","",""),
("376","4","/uploads/image-content/tanja/tanja-1440.jpg","","376","",""),
("377","4","/uploads/image-content/xena/xena-1440.jpg","","377","",""),
("378","1","/uploads/image-content/aerobic/Aerobic.png","","378","",""),
("379","1","/uploads/image-content/annakarina/Annakarina.png","","379","",""),
("380","1","/uploads/image-content/apricot-lace/ApricotLace.png","","380","",""),
("381","1","/uploads/image-content/aqua/Aqua.png","","381","",""),
("382","1","/uploads/image-content/avalanche/Avalanche.png","","382","",""),
("383","1","/uploads/image-content/bird-song/BirdSong.png","","383","",""),
("384","1","/uploads/image-content/bombastic/Bombastic.png","","384","",""),
("385","1","/uploads/image-content/bubblegum/Bubblegum.png","","385","",""),
("386","1","/uploads/image-content/buttercup/Buttercup.png","","386","",""),
("387","1","/uploads/image-content/chiffon/Chiffon.png","","387","",""),
("388","1","/uploads/image-content/clarence/Clarence.png","","388","",""),
("389","1","/uploads/image-content/dedication/Dedication.png","","389","",""),
("390","1","/uploads/image-content/el-toro/ElToro.png","","390","",""),
("391","1","/uploads/image-content/espana/Espana.png","","391","",""),
("392","1","/uploads/image-content/femke/Femke.png","","392","",""),
("393","1","/uploads/image-content/fireworks/Fireworks.png","","393","",""),
("394","1","/uploads/image-content/ilios/Ilios.png","","394","",""),
("395","1","/uploads/image-content/josephine/Josephina.png","","395","",""),
("396","1","/uploads/image-content/jumilia/Jumilia.png","","396","",""),
("397","1","/uploads/image-content/kimberly/Kimberly.png","","397","",""),
("398","1","/uploads/image-content/lady-bombastic/LadyBombastic.png","","398","",""),
("399","1","/uploads/image-content/lavender-bubbles/LavenderBubbles.png","","399","",""),
("400","1","/uploads/image-content/london-eye/LondonEye.png","","400","","");
INSERT INTO `mg_property_data` VALUES
("401","1","/uploads/image-content/luna-trendsetter/LunaTrendsetter.png","","401","",""),
("402","1","/uploads/image-content/madam-bombastic/MadamBombastic.png","","402","",""),
("403","1","/uploads/image-content/mandala/Mand-Alla.png","","403","",""),
("404","1","/uploads/image-content/mansfield-park/MansfieldPark.png","","404","",""),
("405","1","/uploads/image-content/mansfield-pink-park/MansfieldPinkPark.png","","405","",""),
("406","1","/uploads/image-content/maritim/Maritim.png","","406","",""),
("407","1","/uploads/image-content/miss-piggy/MissPiggy.png","","407","",""),
("408","1","/uploads/image-content/misty-bubbles/MistyBubbles.png","","408","",""),
("409","1","/uploads/image-content/montmartre/Montmartre.png","","409","",""),
("410","1","/uploads/image-content/notre-dame/NotreDame.png","","410","",""),
("411","1","/uploads/image-content/peach-avalanche/PeachAvalanche.png","","411","",""),
("412","1","/uploads/image-content/peach-dimension/PeachDemension.png","","412","",""),
("413","1","/uploads/image-content/penny-lane/Pennylane.png","","413","",""),
("414","1","/uploads/image-content/peony-bubbles/PeonyBubbles.png","","414","",""),
("415","1","/uploads/image-content/pink-dimension/PinkDemension.png","","415","",""),
("416","1","/uploads/image-content/priscilla/Priscilia.png","","416","",""),
("417","1","/uploads/image-content/red-naomi/RedNaomi.png","","417","",""),
("418","1","/uploads/image-content/regents-park/Regent’sPark.png","","418","",""),
("419","1","/uploads/image-content/revival/Revival.png","","419","",""),
("420","1","/uploads/image-content/royal-park/RoyalPark.png","","420","",""),
("421","1","/uploads/image-content/royal-porselina/RoyalPorselina.png","","421","",""),
("422","1","/uploads/image-content/saida/Saida.png","","422","",""),
("423","1","/uploads/image-content/scarlet-dimension/ScarletDemension.png","","423","",""),
("424","1","/uploads/image-content/shangri-la/ShangriLa.png","","424","",""),
("425","1","/uploads/image-content/silva-pink/SilvaPink.png","","425","",""),
("426","1","/uploads/image-content/sofi/Sofi.png","","426","",""),
("427","1","/uploads/image-content/sweet-avalanche/SweetAvalanche.png","","427","",""),
("428","1","/uploads/image-content/sweet-dimension/SweetDemention.png","","428","",""),
("429","1","/uploads/image-content/sweet-revival/SweetRevival.png","","429","",""),
("430","1","/uploads/image-content/tallea/Talea.png","","430","",""),
("431","1","/uploads/image-content/tanja/Tanja.png","","431","",""),
("432","1","/uploads/image-content/white-naomi/WhiteNaomi.png","","432","",""),
("433","1","/uploads/image-content/xena/Xena.png","","433","",""),
("434","1","/uploads/image-content/zaina/Zaina.png","","434","",""),
("435","4","/uploads/image-content/avalanche/avalanche1440.jpg","","435","",""),
("436","4","/uploads/image-content/buttercup/buttercupnasite.jpg","","436","",""),
("437","4","/uploads/image-content/peony-bubbles/peonybubbles1440.jpg","","437","",""),
("438","3","/uploads/image-content/white-naomi/WhiteNaomi1.jpg","","438","",""),
("439","1","/uploads/image-content/avalanche/Avalanche777.png","","439","",""),
("440","2","/uploads/image-content/avalanche/crop777.png","","440","",""),
("441","1","/uploads/image-content/luna-trendsetter/LunaTrendsetter777.png","","441","",""),
("442","1","/uploads/image-content/buttercup/Buttercup777.png","","442","",""),
("443","1","/uploads/image-content/peony-bubbles/PeonyBubbles777.png","","443","",""),
("444","1","/uploads/image-content/white-naomi/WhiteNaomi777.png","","444","",""),
("445","1","/uploads/image-content/royal-park/RoyalPark777.png","","445","",""),
("446","4","/uploads/image-content/royal-park/насайт—копия.jpg","","446","",""),
("447","1","/uploads/image-content/ilios/Ilios777.png","","447","",""),
("448","1","/uploads/image-content/beluga/beluga-new777.png","","448","",""),
("449","1","/uploads/image-content/penny-lane/Pennylane777.png","","449","",""),
("450","1","/uploads/image-content/miss-piggy/MissPiggy777.png","","450","",""),
("451","1","/uploads/image-content/peach-dimension/PeachDemension777.png","","451","",""),
("452","1","/uploads/image-content/saida/Saida777.png","","452","",""),
("453","1","/uploads/image-content/london-eye/LondonEye777.png","","453","",""),
("454","1","/uploads/image-content/bubblegum/Bubblegum777.png","","454","",""),
("455","1","/uploads/image-content/chiffon/Chiffon777.png","","455","",""),
("456","4","/uploads/image-content/chiffon/DSC08122копия(1)копия777.png","","456","",""),
("457","1","/uploads/image-content/kimberly/Kimberly777.png","","457","",""),
("458","1","/uploads/image-content/clarence/Clarence777.png","","458","",""),
("459","1","/uploads/image-content/peach-avalanche/PeachAvalanche777.png","","459","",""),
("460","1","/uploads/image-content/josephine/Josephina777.png","","460","",""),
("461","1","/uploads/image-content/tallea/Talea777.png","","461","",""),
("462","1","/uploads/image-content/apricot-lace/ApricotLace777.png","","462","",""),
("463","1","/uploads/image-content/priscilla/Priscilia777.png","","463","",""),
("464","1","/uploads/image-content/bird-song/BirdSong777.png","","464","",""),
("465","1","/uploads/image-content/tanja/Tanja777.png","","465","",""),
("466","1","/uploads/image-content/espana/Espana777.png","","466","",""),
("467","1","/uploads/image-content/royal-porselina/RoyalPorselina777.png","","467","",""),
("468","1","/uploads/image-content/mandala/Mand-Alla777.png","","468","",""),
("469","1","/uploads/image-content/femke/Femke777.png","","469","",""),
("470","1","/uploads/image-content/zaina/Zaina777.png","","470","",""),
("471","1","/uploads/image-content/dedication/Dedication777.png","","471","",""),
("472","1","/uploads/image-content/madam-bombastic/MadamBombastic777.png","","472","",""),
("473","1","/uploads/image-content/sweet-avalanche/SweetAvalanche777.png","","473","",""),
("474","1","/uploads/image-content/sweet-revival/SweetRevival777.png","","474","",""),
("475","1","/uploads/image-content/bombastic/Bombastic777.png","","475","",""),
("476","1","/uploads/image-content/sweet-dimension/SweetDemention777.png","","476","",""),
("477","1","/uploads/image-content/mansfield-pink-park/MansfieldPinkPark777.png","","477","",""),
("478","1","/uploads/image-content/regents-park/Regent’sPark777.png","","478","",""),
("479","1","/uploads/image-content/silva-pink/SilvaPink777.png","","479","",""),
("480","1","/uploads/image-content/aqua/Aqua777.png","","480","",""),
("481","1","/uploads/image-content/mansfield-park/MansfieldPark777.png","","481","",""),
("482","1","/uploads/image-content/annakarina/Annakarina777.png","","482","",""),
("483","1","/uploads/image-content/pink-dimension/PinkDemension777.png","","483","",""),
("484","1","/uploads/image-content/revival/Revival777.png","","484","",""),
("485","1","/uploads/image-content/aerobic/Aerobic777.png","","485","",""),
("486","1","/uploads/image-content/montmartre/Montmartre777.png","","486","",""),
("487","1","/uploads/image-content/sofi/Sofi777.png","","487","",""),
("488","1","/uploads/image-content/maritim/Maritim777.png","","488","",""),
("489","1","/uploads/image-content/lavender-bubbles/LavenderBubbles777.png","","489","",""),
("490","1","/uploads/image-content/xena/Xena777.png","","490","",""),
("491","1","/uploads/image-content/lady-bombastic/LadyBombastic777.png","","491","",""),
("492","1","/uploads/image-content/notre-dame/NotreDame777.png","","492","",""),
("493","1","/uploads/image-content/misty-bubbles/MistyBubbles777.png","","493","",""),
("494","1","/uploads/image-content/red-naomi/RedNaomi777.png","","494","",""),
("495","1","/uploads/image-content/jumilia/Jumilia777.png","","495","",""),
("496","1","/uploads/image-content/scarlet-dimension/ScarletDemension777.png","","496","",""),
("497","1","/uploads/image-content/shangri-la/ShangriLa777.png","","497","",""),
("498","1","/uploads/image-content/el-toro/ElToro777.png","","498","",""),
("499","1","/uploads/image-content/fireworks/Fireworks777.png","","499","","");
DROP TABLE IF EXISTS `mg_property_group`;

CREATE TABLE `mg_property_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(249) NOT NULL,
  `sort` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_sessions`;

CREATE TABLE `mg_sessions` (
  `session_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `session_expires` int(11) unsigned NOT NULL DEFAULT '0',
  `session_data` longtext,
  PRIMARY KEY (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_site-block-editor`;

CREATE TABLE `mg_site-block-editor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `comment` text NOT NULL,
  `type` varchar(249) NOT NULL,
  `content` text NOT NULL,
  `width` text NOT NULL,
  `height` text NOT NULL,
  `alt` text NOT NULL,
  `title` text NOT NULL,
  `href` text NOT NULL,
  `class` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_trigger-guarantee`;

CREATE TABLE `mg_trigger-guarantee` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Порядковый номер',
  `title` text NOT NULL COMMENT 'Загаловок',
  `settings` text NOT NULL COMMENT 'Настройки',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_trigger-guarantee-elements`;

CREATE TABLE `mg_trigger-guarantee-elements` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Порядковый номер',
  `parent` int(11) NOT NULL COMMENT 'id блока',
  `text` text NOT NULL COMMENT 'Текст триггера',
  `icon` text NOT NULL COMMENT 'Иконка или url картинки',
  `sort` int(11) NOT NULL COMMENT 'Сортировка',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_url_canonical`;

CREATE TABLE `mg_url_canonical` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url_page` text NOT NULL,
  `url_canonical` text NOT NULL,
  `activity` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_url_redirect`;

CREATE TABLE `mg_url_redirect` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url_old` text NOT NULL,
  `url_new` text NOT NULL,
  `code` int(3) NOT NULL,
  `activity` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_url_rewrite`;

CREATE TABLE `mg_url_rewrite` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` text,
  `short_url` varchar(249) NOT NULL,
  `titeCategory` varchar(249) DEFAULT NULL,
  `cat_desc` longtext NOT NULL,
  `meta_title` text,
  `meta_keywords` text,
  `meta_desc` text NOT NULL,
  `activity` tinyint(1) NOT NULL DEFAULT '1',
  `cat_desc_seo` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;


INSERT INTO `mg_url_rewrite` VALUES
("1","/catalog?cat_id=&amp;applyFilter=1&amp;new=1","latest","Новинки","","Новинки","Новинки","","1","");
DROP TABLE IF EXISTS `mg_user`;

CREATE TABLE `mg_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `owner` int(11) NOT NULL DEFAULT '0',
  `email` varchar(191) DEFAULT NULL,
  `pass` varchar(249) DEFAULT NULL,
  `role` int(11) DEFAULT NULL,
  `name` varchar(249) DEFAULT NULL,
  `sname` varchar(249) DEFAULT NULL,
  `pname` varchar(249) DEFAULT NULL,
  `address` text,
  `address_index` text,
  `address_country` text,
  `address_region` text,
  `address_city` text,
  `address_street` text,
  `address_house` text,
  `address_flat` text,
  `phone` varchar(249) DEFAULT NULL,
  `last_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `date_add` timestamp NULL DEFAULT NULL,
  `blocked` int(1) NOT NULL DEFAULT '0',
  `restore` varchar(249) DEFAULT NULL,
  `activity` int(1) DEFAULT '0',
  `inn` text,
  `kpp` text,
  `nameyur` text,
  `adress` text,
  `bank` text,
  `bik` text,
  `ks` text,
  `rs` text,
  `birthday` text,
  `ip` text,
  `op` text COMMENT 'Дополнительные поля',
  `fails` tinytext,
  `login_email` varchar(191) DEFAULT NULL,
  `login_phone` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `login_email_2` (`login_email`),
  KEY `email` (`email`),
  KEY `login_email` (`login_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;


INSERT INTO `mg_user` VALUES
("1","0","tech@belka.one","$2y$10$c9aUxt.lCYlEqZ4nDi.RTe7PA/CAYSkcfzy6VVsIVXf6.GEorX5gK","1","Администратор","","","","","","","","","","","+7 (111) 111 11-11","2024-10-26 19:24:19","2024-10-26 19:24:19","0","","1","","","","","","","","","","","","","tech@belka.one","");
DROP TABLE IF EXISTS `mg_user_group`;

CREATE TABLE `mg_user_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `can_drop` tinyint(1) NOT NULL DEFAULT '1',
  `name` varchar(249) NOT NULL DEFAULT '0',
  `admin_zone` tinyint(1) NOT NULL DEFAULT '0',
  `product` tinyint(1) NOT NULL DEFAULT '0',
  `page` tinyint(1) NOT NULL DEFAULT '0',
  `category` tinyint(1) NOT NULL DEFAULT '0',
  `order` tinyint(1) DEFAULT '0',
  `user` tinyint(1) NOT NULL DEFAULT '0',
  `plugin` tinyint(1) NOT NULL DEFAULT '0',
  `setting` tinyint(1) NOT NULL DEFAULT '0',
  `wholesales` tinyint(1) NOT NULL DEFAULT '0',
  `order_status` text COMMENT 'доступные статусы заказов',
  `ignore_owners` tinyint(4) DEFAULT '0' COMMENT 'игнорировать ответственных',
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4;


INSERT INTO `mg_user_group` VALUES
("-1","0","Гость (Не авторизован)","0","0","0","0","0","0","0","0","0","","0"),
("1","0","Администратор","1","2","2","2","2","2","2","2","1","","0"),
("2","0","Пользователь","0","0","0","0","0","0","0","0","0","","0"),
("3","0","Менеджер","1","2","0","1","2","0","2","0","0","","0"),
("4","0","Модератор","1","1","2","0","0","0","2","0","0","","0"),
("5","1","Типовое соглашение к1","0","0","0","0","0","0","0","0","1","","0"),
("6","1","Новая группа","0","0","0","0","0","0","0","0","0","","0"),
("7","1","Типовое соглашение к2","0","0","0","0","0","0","0","0","2","","0"),
("8","1","Типовое соглашение к3","0","0","0","0","0","0","0","0","3","","0"),
("9","1","Типовое соглашение к4","0","0","0","0","0","0","0","0","4","","0"),
("10","1","Типовое соглашение к5","0","0","0","0","0","0","0","0","5","","0"),
("11","1","Типовое соглашение к6","0","0","0","0","0","0","0","0","6","","0"),
("12","1","Типовое соглашение к7","0","0","0","0","0","0","0","0","7","","0"),
("13","1","Типовое соглашение к8","0","0","0","0","0","0","0","0","8","","0"),
("14","1","Типовое соглашение к9","0","0","0","0","0","0","0","0","9","","0"),
("15","1","Типовое соглашение к10","0","0","0","0","0","0","0","0","10","","0"),
("16","1","Типовое соглашение к11","0","0","0","0","0","0","0","0","11","","0"),
("17","1","Типовое соглашение к12","0","0","0","0","0","0","0","0","12","","0"),
("18","1","Типовое соглашение к13","0","0","0","0","0","0","0","0","13","","0"),
("19","1","Типовое соглашение к14","0","0","0","0","0","0","0","0","14","","0"),
("20","1","Типовое соглашение к15","0","0","0","0","0","0","0","0","15","","0"),
("21","1","Типовое соглашение к16","0","0","0","0","0","0","0","0","16","","0"),
("22","1","Типовое соглашение к17","0","0","0","0","0","0","0","0","17","","0"),
("23","1","Типовое соглашение к18","0","0","0","0","0","0","0","0","18","","0"),
("24","1","Типовое соглашение к19","0","0","0","0","0","0","0","0","19","","0"),
("25","1","Типовое соглашение к20","0","0","0","0","0","0","0","0","20","","0");
DROP TABLE IF EXISTS `mg_user_logins`;

CREATE TABLE `mg_user_logins` (
  `created_at` bigint(20) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `access` tinytext,
  `last_used` int(11) DEFAULT NULL,
  `fails` tinytext,
  UNIQUE KEY `created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


INSERT INTO `mg_user_logins` VALUES
("17299598672767","1","$2y$10$R/J2aHQ7KEAhYs/2FHGmRebNhb38WeHEQU8pBxnRc87XWQF2JV54.","1731400453",""),
("17322780580023","1","$2y$10$2VF.H4yO4Tc2NnZDkoJT1e/3zwbN2InJV.RNeWSK8xE/LZ4gSsXwO","1733313511","");
DROP TABLE IF EXISTS `mg_user_opt_fields`;

CREATE TABLE `mg_user_opt_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(249) NOT NULL,
  `type` varchar(249) NOT NULL,
  `vars` text,
  `sort` int(11) DEFAULT NULL,
  `placeholder` text,
  `active` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_user_opt_fields_content`;

CREATE TABLE `mg_user_opt_fields_content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `field_id` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  `value` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_vk-export`;

CREATE TABLE `mg_vk-export` (
  `moguta_id` int(11) NOT NULL,
  `vk_id` varchar(249) NOT NULL,
  `moguta_img` varchar(249) NOT NULL,
  `vk_img` varchar(249) NOT NULL,
  PRIMARY KEY (`moguta_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_wholesales_sys`;

CREATE TABLE `mg_wholesales_sys` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `variant_id` int(11) NOT NULL,
  `count` float NOT NULL,
  `price` double NOT NULL DEFAULT '0',
  `group` int(11) DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `variant_id` (`variant_id`),
  KEY `count` (`count`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_write_lock`;

CREATE TABLE `mg_write_lock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `table` varchar(249) NOT NULL,
  `entity_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `time_block` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `mg_yandexmarket`;

CREATE TABLE `mg_yandexmarket` (
  `name` varchar(191) NOT NULL,
  `settings` longtext NOT NULL,
  `edited` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

